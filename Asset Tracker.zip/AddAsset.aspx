﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="AddAsset.aspx.cs" Inherits="Assets_Tracker.AddAsset" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title>Add Asset - IT Assets Management System</title>
    <link rel="stylesheet"
        href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" />
    <style>
                * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Arial, sans-serif;
        }

        body {
            background: #f3f6fb;
            color: #1e293b;
        }

        /* ============MAIN LAYOUT============== */

        .dashboard-container {
            display: flex;
            min-height: 100vh;
        }


        /* ============SIDEBAR=============== */

        .sidebar {
            width: 280px;
            min-height: 100vh;
            background: linear-gradient(180deg, #075c52 0%, #12314c 100%);
            color: white;
            display: flex;
            flex-direction: column;
            position: fixed;
            left: 0;
            top: 0;
        }

        .logo {
            height: 165px;
            display: flex;
            align-items: center;
            gap: 15px;
            padding: 25px;
            border-bottom: 1px solid rgba(255,255,255,0.12);
        }

        .logo-icon {
            width: 58px;
            height: 58px;
            border: 2px solid rgba(255,255,255,0.7);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 28px;
        }

        .logo-text {
            font-size: 20px;
            font-weight: 700;
            line-height: 1.2;
        }

        .logo-text span {
            display: block;
            font-size: 18px;
            font-weight: 400;
            margin-top: 5px;
        }

        .navigation {
            padding: 20px 12px;
        }

        .nav-item {
            display: flex;
            align-items: center;
            gap: 20px;
            color: #e5e7eb;
            text-decoration: none;
            padding: 18px 25px;
            margin-bottom: 8px;
            border-radius: 10px;
            font-size: 17px;
            font-weight: 500;
            transition: 0.3s;
        }

        .nav-item i {
            font-size: 24px;
        }

        .nav-item:hover {
            background: rgba(255,255,255,0.08);
        }

        .nav-item.active {
            background: linear-gradient(135deg, #3679d8, #1d5fc5);
            box-shadow: 0 8px 20px rgba(30,96,200,0.35);
        }

        .logout {
            margin-top: auto;
            padding: 20px 12px;
            border-top: 1px solid rgba(255,255,255,0.12);
        }


        /* =============MAIN CONTENT=============== */

        .main-content {
            margin-left: 280px;
            width: calc(100% - 280px);
            min-height: 100vh;
        }


        /* =============TOPBAR============== */

        .topbar {
            height: 85px;
            background: white;
            border-bottom: 1px solid #e2e8f0;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 40px;
        }

        .topbar-left {
            display: flex;
            align-items: center;
            gap: 30px;
        }

        .menu-button {
            font-size: 28px;
            color: #334155;
        }

        .page-title {
            font-size: 28px;
            font-weight: 700;
            color: #1e293b;
        }

        .topbar-right {
            display: flex;
            align-items: center;
            gap: 30px;
        }

        .notifications {
            position: relative;
            font-size: 23px;
            color: #334155;
        }

        .notification-badge {
            position: absolute;
            width: 10px;
            height: 10px;
            background: #ef4444;
            border-radius: 50%;
            top: -3px;
            right: -5px;
        }

        .profile {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .profile-icon {
            width: 55px;
            height: 55px;
            border-radius: 50%;
            background: #eef3fb;
            color: #2563c9;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 25px;
        }

        .profile-info {
            display: flex;
            flex-direction: column;
        }

        .profile-info strong {
            font-size: 16px;
        }

        .profile-info span {
            font-size: 14px;
            color: #64748b;
            margin-top: 3px;
        }


        /* ==========CONTENT============== */

        .content {
            padding: 35px 40px;
        }

        .page-header {
            margin-bottom: 25px;
        }

        .page-header h1 {
            font-size: 34px;
            color: #1e293b;
            margin-bottom: 8px;
        }

        .page-header p {
            color: #64748b;
            font-size: 17px;
        }


        /* ============FORM CARD=============== */

        .form-card {
            background: white;
            border: 1px solid #dbe3ee;
            border-radius: 15px;
            box-shadow: 0 5px 20px rgba(15,23,42,0.06);
            overflow: hidden;
        }

        .form-card-header {
            padding: 25px;
            display: flex;
            align-items: center;
            gap: 18px;
            border-bottom: 1px solid #e2e8f0;
        }

        .form-card-icon {
            width: 70px;
            height: 70px;
            border-radius: 14px;
            background: #e8f0fc;
            color: #2563c9;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 34px;
        }

        .form-card-header h2 {
            font-size: 26px;
            color: #1e293b;
        }


        /* ============FORM=============== */

        .form-body {
            padding: 30px 25px;
        }

        .form-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 25px 35px;
        }

        .form-group {
            display: flex;
            flex-direction: column;
        }

        .form-group.full-width {
            grid-column: span 2;
        }

        .form-group label {
            font-size: 16px;
            font-weight: 600;
            margin-bottom: 10px;
            color: #334155;
        }

        .input-container {
            display: flex;
            align-items: center;
            border: 1px solid #cbd5e1;
            border-radius: 9px;
            overflow: hidden;
            height: 55px;
            background: #fff;
            transition: 0.3s;
        }

        .input-container:focus-within {
            border-color: #2563c9;
            box-shadow: 0 0 0 3px rgba(37,99,201,0.10);
        }

        .input-icon {
            width: 58px;
            height: 100%;
            display: flex;
            align-items: center;
            justify-content: center;
            border-right: 1px solid #e2e8f0;
            color: #64748b;
            font-size: 20px;
        }

        .form-input,
        .form-select {
            border: none;
            outline: none;
            width: 100%;
            height: 100%;
            padding: 0 15px;
            font-size: 15px;
            color: #334155;
            background: transparent;
        }

        .textarea-container {
            display: flex;
            border: 1px solid #cbd5e1;
            border-radius: 9px;
            overflow: hidden;
            min-height: 110px;
        }

        .textarea-container .input-icon {
            height: auto;
            min-height: 110px;
            align-items: flex-start;
            padding-top: 18px;
        }

        .form-textarea {
            border: none;
            outline: none;
            width: 100%;
            min-height: 110px;
            padding: 15px;
            font-size: 15px;
            resize: vertical;
        }


        /* ============BUTTONS=============== */

        .form-actions {
            display: flex;
            justify-content: flex-end;
            gap: 15px;
            margin-top: 30px;
            padding-top: 25px;
            border-top: 1px solid #e2e8f0;
        }

        .btn {
            border: none;
            padding: 15px 28px;
            border-radius: 9px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            transition: 0.3s;
        }

        .btn-cancel {
            background: #f1f5f9;
            color: #475569;
        }

        .btn-cancel:hover {
            background: #e2e8f0;
        }

        .btn-save {
            background: linear-gradient(135deg, #3679d8, #1d5fc5);
            color: white;
            box-shadow: 0 5px 15px rgba(37,99,201,0.25);
        }

        .btn-save:hover {
            transform: translateY(-2px);
        }


        /* =============FOOTER=============== */

        .footer {
            text-align: center;
            padding: 30px;
            color: #64748b;
            font-size: 14px;
        }


        /* ===========RESPONSIVE============== */

        @media(max-width: 1000px) {

            .sidebar {
                width: 230px;
            }

            .main-content {
                margin-left: 230px;
                width: calc(100% - 230px);
            }

            .form-grid {
                grid-template-columns: 1fr;
            }

            .form-group.full-width {
                grid-column: span 1;
            }

        }
    </style>
</head>
<body>
    <form id="form1" runat="server">
        <div class="dashboard-container">
            <!--=========SIDEBAR=======-->
            <aside class="sidebar">
                <div class="logo">
                    <div class="logo-icon">
                        <i class="bi bi-display"></i>
                    </div>
                    <div class="logo-text">
                        IT Assets Management
                        <span>System</span>
                    </div>
                </div>
                <nav class="navigation">
                    <a href="Dashboard.aspx" class="nav-item">
                        <i class="bi bi-grid"></i>Dashboard
                    </a>
                    <a href="Users.aspx" class="nav-item">
                        <i class="bi bi-person"></i>Users
                    </a>
                    <a href="Assets.aspx" class="nav-item">
                        <i class="bi bi-laptop"></i>Asset
                    </a>
                    <a href="AssetAssignments.aspx" class="nav-item">
                        <i class="bi bi-person-check"></i>Asset Assignments
                    </a>
                    <a href="Returns.aspx" class="nav-item">
                        <i class="bi bi-arrow-return-left"></i>Returns
                    </a>
                    <a href="Documents.aspx" class="nav-item">
                        <i class="bi bi-file-earmark-text"></i>Documents
                    </a>
                    <a href="Reports.aspx" class="nav-item">
                        <i class="bi bi-bar-chart"></i>Reports
                    </a>
                    <a href="AuditLogs.aspx" class="nav-item">
                        <i class="bi bi-shield-check"></i>
                    </a>

                </nav>
                <div class="logout">
                    <a href="Login.aspx" class="nav-item">
                        <i class="bi bi-box-arrow-left"></i>
                    </a>
                </div>
            </aside>
            <!--===========MAIN CONTENT==========-->
            <div class="main-content">
                <!--TOPBAR-->
                <header class="topbar">
                    <div class="topbar-left">
                        <div class="menu-button">
                            <i class="bi bi-list"></i>
                        </div>
                        <div class="page-title">
                            Add Asset
                        </div>
                    </div>
                    <div class="topbar-right">
                        <div class="profile">
                            <div class="profile-icon">
                                <i class="bi bi-person-fill"></i>
                            </div>
                            <div class="profile-info">
                                <strong>
                                    <asp:Label
                                        ID="lblAdminName"
                                        runat="server"
                                        Text="Administrator"></asp:Label>
                                </strong>
                                <span>
                                    <asp:Label
                                        ID="lblAdminRole"
                                        runat="server"
                                        Text="IT Administrator"></asp:Label>
                                </span>
                            </div>
                            <i class="bi bi-chevron-down"></i>
                        </div>
                    </div>
                </header>
                <!--==============Content==========-->
                <section class="content">
                    <div class="page-header">
                        <h1>Add New Asset</h1>
                        <p>Enter asset information to register it in the system</p>
                    </div>
                    <!--Message-->
                    <asp:Label
                        ID="lblMessage"
                        runat="server"
                        Visible="false" />
                    <!--=======FORM CARD======-->
                    <div class="form-card">
                        <div class="form-card-header">
                            <div class="form-card-icon">
                                <i class="bi bi-laptop"></i>
                            </div>
                            <h2>Asset Information</h2>
                        </div>
                        <!--Body-->
                        <div class="form-body">
                            <div class="form-grid">
                                <!--AssetTag-->
                                <div class="form-group">
                                    <label>Asset Tag*</label>
                                    <div class="input-container">
                                        <div class="input-icon">
                                            <i class="bi bi-tag"></i>
                                        </div>
                                        <asp:TextBox
                                            ID="txtAssetTag"
                                            runat="server"
                                            CssClass="form-input"
                                            placeholder="Enter asset Tag"></asp:TextBox>
                                    </div>
                                </div>
                                <!--Asset Type-->
                                <div class="form-group">
                                    <label>Asset Type*</label>
                                    <div class="input-container">
                                        <div class="input-icon">
                                            <i class="bi bi-list"></i>
                                        </div>
                                        <asp:DropDownList
                                            ID="ddlAssetType"
                                            runat="server"
                                            CssClass="form-select">
                                            <asp:ListItem Text="Select asset type" Value=""></asp:ListItem>
                                            <asp:ListItem Text="Laptop" Value="Laptop"></asp:ListItem>
                                            <asp:ListItem Text="Desktop" Value="Desktop"></asp:ListItem>
                                            <asp:ListItem Text="Monitor" Value="Monitor"></asp:ListItem>
                                            <asp:ListItem Text="Printer" Value="Printer"></asp:ListItem>
                                            <asp:ListItem Text="Tablet" Value="Tablet"></asp:ListItem>
                                            <asp:ListItem Text="Mobile Phone" Value="Mobile Phone"></asp:ListItem>
                                            <asp:ListItem Text="Other" Value="Other"></asp:ListItem>
                                        </asp:DropDownList>
                                    </div>
                                </div>
                                <!--make-->
                                <div class="form-group">
                                    <label>Make*</label>
                                    <div class="input-container">
                                        <div class="input-icon">
                                            <i class="bi bi-building"></i>
                                        </div>
                                        <asp:TextBox
                                            ID="txtMake"
                                            runat="server"
                                            CssClass="form-input"
                                            placeholder="Enter make" />
                                    </div>
                                </div>
                                <!--Model-->
                                <div class="form-group">
                                    <label>Model*</label>
                                    <div class="input-container">
                                        <div class="input-icon">
                                            <i class="bi bi-cpu"></i>
                                        </div>
                                        <asp:TextBox
                                            ID="txtModel"
                                            runat="server"
                                            CssClass="form-input"
                                            placeholder="Enter model" />
                                    </div>
                                </div>
                                <!--SERIAL NUMBER-->
                                <div class="form-group">
                                    <label>Serial Number*</label>
                                    <div class="input-container">
                                        <div class="input-icon">
                                            <i class="bi bi-upc"></i>
                                        </div>
                                        <asp:TextBox
                                            ID="txtSerialNumber"
                                            runat="server"
                                            CssClass="form-input"
                                            placeholder="Enter serial number" />
                                    </div>
                                </div>
                                <!--condition-->
                                <div class="form-group">
                                    <label>Condition*</label>
                                    <div class="input-container">
                                        <div class="input-icon">
                                            <i class="bi bi-check-circle"></i>
                                        </div>
                                        <asp:DropDownList
                                            ID="ddlCondition"
                                            runat="server"
                                            CssClass="form-select">
                                            <asp:ListItem Text="Select condition" Value=""></asp:ListItem>
                                            <asp:ListItem Text="Excellent" Value="Excellent"></asp:ListItem>
                                            <asp:ListItem Text="Good" Value="Good"></asp:ListItem>
                                            <asp:ListItem Text="Fair" Value="Fair"></asp:ListItem>
                                            <asp:ListItem Text="Poor" Value="Poor"></asp:ListItem>
                                            <asp:ListItem Text="Under Maintenance" Value="Under Maintenance"></asp:ListItem>
                                            <asp:ListItem Text="Retired" Value="Retired"></asp:ListItem>
                                        </asp:DropDownList>
                                    </div>
                                </div>
                                <!--Warranty-->
                                <div class="form-group">
                                    <label>Warranty Expiration</label>
                                    <div class="input-container">
                                        <div class="input-icon">
                                            <i class="bi bi-calendar-check"></i>
                                        </div>
                                        <asp:TextBox
                                            ID="txtWarrantyExpiration"
                                            runat="server"
                                            CssClass="form-input"
                                            TextMode="Date"></asp:TextBox>
                                    </div>
                                </div>
                                <!--Received Date-->
                                <div class="form-group">
                                    <label>Received Date</label>
                                    <div class="input-container">
                                        <div class="input-icon">
                                            <i class="bi bi-calendar-date"></i>
                                        </div>
                                        <asp:TextBox
                                            ID="txtReceivedDate"
                                            runat="server"
                                            CssClass="form-input"
                                            TextMode="Date"></asp:TextBox>
                                    </div>
                                </div>
                                <!-- Description -->
                                <div class="form-group full-width">
                                  <label>Description</label>
                                  <div class="input-container">
                                       <div class="input-icon textarea-icon">
                                             <i class="bi bi-file-earmark-text"></i>
                                      </div>
                                  <asp:TextBox 
                                       ID="txtDescription" 
                                       runat="server" 
                                       CssClass="form-input form-textarea" 
                                       TextMode="MultiLine" 
                                       Rows="3" 
                                       ></asp:TextBox>
                                    </div>
                                </div>
                                <!--Buttons-->
                                <div class="form-actions">
                                    <asp:Button
                                        ID="btnCancel"
                                        runat="server"
                                        Text="← Cancel"
                                        CssClass="btn btn-cancel"
                                        CausesValidation="false"
                                        OnClick="btnCancel_Click"/>
                                    <asp:Button
                                        ID="btnSaveAsset"
                                        runat="server"
                                        Text="💾 Save Asset"
                                        CssClass="btn btn-save"
                                        OnClick="btnSaveAsset_Click"/>
                                </div>
                            </div>
                        </div>
                        <!--Footer-->
                        <footer class="footer">
                            &copy; 2026 IT Assets Management System. All rights reserved by S.N Nkuna.
                        </footer>
                    </div>
                </section>
            </div>
        </div>
    </form>
</body>
</html>