﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="AssetDetails.aspx.cs" Inherits="Assets_Tracker.AssetDetails" %>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title>Asset Details - IT Asset Management System</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" />
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }
        body {
            font-family: Arial, Helvetica, sans-serif;
            background: #f4f6fb;
            color: #1f2937;
        }
        .sidebar {
            position: fixed;
            left: 0;
            top: 0;
            width: 250px;
            height: 100vh;
            background: linear-gradient(180deg, #0f5c4d, #123a5c);
            color: white;
            padding: 22px 15px;
            z-index: 1000;
        }
        .logo {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 5px 10px 25px 10px;
            font-size: 19px;
            font-weight: bold;
        }
        .logo i {
            font-size: 25px;
        }
        .nav-menu {
            list-style: none;
            margin-top: 15px;
        }
        .nav-menu li {
            margin-bottom: 6px;
        }
        .nav-menu a {
            display: flex;
            align-items: center;
            gap: 13px;
            color: white;
            text-decoration: none;
            padding: 12px 14px;
            border-radius: 8px;
            font-size: 14px;
            transition: 0.2s;
        }
        .nav-menu a:hover {
            background: rgba(255, 255, 255, 0.12);
        }
        .nav-menu a.active {
            background: linear-gradient(90deg, #2563c7, #3f7bd7);
        }
        .nav-menu i {
            font-size: 17px;
            width: 20px;
        }
        .main {
            margin-left: 250px;
            min-height: 100vh;
        }
        .topbar {
            height: 70px;
            background: white;
            border-bottom: 1px solid #e5e7eb;
            display: flex;
            justify-content: flex-end;
            align-items: center;
            padding: 0 30px;
        }
        .admin-info {
            display: flex;
            align-items: center;
            gap: 12px;
        }
        .admin-icon {
            width: 42px;
            height: 42px;
            border-radius: 50%;
            background: #eaf2ff;
            color: #2563c7;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
        }
        .admin-text {
            display: flex;
            flex-direction: column;
            align-items: flex-end;
        }
        .admin-name {
            font-weight: bold;
            font-size: 14px;
        }
        .admin-role {
            color: #6b7280;
            font-size: 12px;
            margin-top: 2px;
        }
        .content {
            padding: 30px;
        }
        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
        }
        .page-title h1 {
            font-size: 27px;
            color: #1f2937;
            margin-bottom: 7px;
        }
        .page-title p {
            color: #6b7280;
            font-size: 14px;
        }
        .header-buttons {
            display: flex;
            gap: 10px;
        }
        .btn {
            border: none;
            border-radius: 7px;
            padding: 11px 17px;
            font-size: 14px;
            cursor: pointer;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            font-weight: 600;
        }
        .btn-primary {
            background: #2563c7;
            color: white;
        }
        .btn-primary:hover {
            background: #1e4fa5;
        }
        .btn-secondary {
            background: white;
            color: #374151;
            border: 1px solid #d1d5db;
        }
        .btn-secondary:hover {
            background: #f9fafb;
        }
        .message {
            padding: 13px 16px;
            border-radius: 7px;
            margin-bottom: 20px;
            font-size: 14px;
            display: block;
        }
        .success-message {
            background: #ecfdf5;
            color: #047857;
            border: 1px solid #a7f3d0;
        }
        .error-message {
            background: #fef2f2;
            color: #b91c1c;
            border: 1px solid #fecaca;
        }
        .details-card {
            background: white;
            border-radius: 12px;
            border: 1px solid #e5e7eb;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.04);
            margin-bottom: 22px;
            overflow: hidden;
        }
        .card-header {
            padding: 20px 24px;
            border-bottom: 1px solid #e5e7eb;
            display: flex;
            align-items: center;
            gap: 14px;
        }
        .asset-icon {
            width: 48px;
            height: 48px;
            background: #eaf2ff;
            color: #2563c7;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 23px;
        }
        .card-header-text h2 {
            font-size: 19px;
            margin-bottom: 4px;
        }
        .card-header-text p {
            color: #6b7280;
            font-size: 13px;
        }
        .details-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 0;
        }
        .detail-item {
            padding: 18px 24px;
            border-bottom: 1px solid #edf0f4;
        }
        .detail-item:nth-child(odd) {
            border-right: 1px solid #edf0f4;
        }
        .detail-label {
            color: #6b7280;
            font-size: 12px;
            font-weight: 600;
            text-transform: uppercase;
            margin-bottom: 7px;
        }
        .detail-value {
            color: #1f2937;
            font-size: 15px;
            font-weight: 500;
        }
        .asset-tag {
            color: #2563c7;
            font-weight: bold;
        }
        .condition {
            display: inline-block;
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
        }
        .allocation-section {
            padding: 24px;
        }
        .allocation-title {
            font-size: 17px;
            font-weight: bold;
            margin-bottom: 18px;
            color: #1f2937;
        }
        .allocation-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 15px;
        }
        .allocation-box {
            background: #f8fafc;
            border: 1px solid #e5e7eb;
            border-radius: 8px;
            padding: 15px;
        }
        .allocation-box .label {
            display: block;
            color: #6b7280;
            font-size: 12px;
            margin-bottom: 6px;
        }
        .allocation-box .value {
            font-size: 14px;
            font-weight: 600;
            color: #1f2937;
        }
        .status-active {
            color: #047857;
        }
        .status-returned {
            color: #6b7280;
        }
        .no-allocation {
            padding: 20px;
            background: #f8fafc;
            border-radius: 8px;
            color: #6b7280;
            font-size: 14px;
            text-align: center;
        }
        .action-card {
            background: white;
            border: 1px solid #e5e7eb;
            border-radius: 12px;
            padding: 20px 24px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .action-text h3 {
            font-size: 16px;
            margin-bottom: 5px;
        }
        .action-text p {
            color: #6b7280;
            font-size: 13px;
        }
        .action-buttons {
            display: flex;
            gap: 10px;
        }
        @media (max-width: 900px) {
            .sidebar {
                width: 220px;
            }
            .main {
                margin-left: 220px;
            }
            .allocation-grid {
                grid-template-columns: 1fr;
            }
        }
        @media (max-width: 700px) {
            .sidebar {
                position: relative;
                width: 100%;
                height: auto;
            }
            .main {
                margin-left: 0;
            }
            .details-grid {
                grid-template-columns: 1fr;
            }
            .detail-item:nth-child(odd) {
                border-right: none;
            }
            .page-header {
                flex-direction: column;
                align-items: flex-start;
                gap: 15px;
            }
            .action-card {
                flex-direction: column;
                align-items: flex-start;
                gap: 15px;
            }
        }
    </style>
</head>
<body>
    <form id="form1" runat="server">
        <!-- SIDEBAR -->
        <div class="sidebar">
            <div class="logo">
                <i class="bi bi-pc-display"></i>
                <span>IT Assets Management System</span>
            </div>
            <ul class="nav-menu">
                <li>
                           <a href="Dashboard.aspx">
                        <i class="bi bi-grid"></i>
                        <span>Dashboard</span>
                    </a>
                </li>
                <li>
                    <a href="Users.aspx">
                        <i class="bi bi-people"></i>
                        <span>Employees</span>
                    </a>
                </li>
                <li>
                    <a href="Assets.aspx">
                        <i class="bi bi-laptop"></i>
                        <span>Assets</span>
                    </a>
                </li>
                <li>
                    <a href="AssetAssignments.aspx">
                        <i class="bi bi-person-check"></i>
                        <span>Assignments</span>
                    </a>
                </li>
                <li>
                    <a href="Returns.aspx" class="active">
                        <i class="bi bi-arrow-return-left"></i>
                        <span>Returns</span>
                    </a>
                </li>
                <li>
                    <a href="Documents.aspx">
                        <i class="bi bi-file-earmark-text"></i>
                        <span>Documents</span>
                    </a>
                </li>
                <li>
                    <a href="Reports.aspx">
                        <i class="bi bi-bar-chart"></i>
                        <span>Reports</span>
                    </a>
                </li>
                <li>
                    <a href="AuditLogs.aspx">
                        <i class="bi bi-shield-check"></i>
                        <span>Audit Logs</span>
                    </a>
                </li>
            </ul>
        </div>
        <!-- MAIN -->
        <div class="main">
            <!-- TOPBAR -->
            <div class="topbar">
                <div class="admin-info">
                    <div class="admin-icon">
                        <i class="bi bi-person-circle"></i>
                    </div>
                    <div class="admin-text">
                        <asp:Label ID="lblAdminName" runat="server" CssClass="admin-name"></asp:Label>
                        <asp:Label ID="lblAdminRole" runat="server" CssClass="admin-role"></asp:Label>
                    </div>
                </div>
            </div>
            <!-- CONTENT -->
            <div class="content">
                <!-- PAGE HEADER -->
                <div class="page-header">
                    <div class="page-title">
                        <h1>Asset Details</h1>
                        <p>View complete information about this IT asset.</p>
                    </div>
                    <div class="header-buttons">
                        <asp:Button ID="btnBack" runat="server" Text="Back to Assets" CssClass="btn btn-secondary" OnClick="btnBack_Click" />
                        <asp:Button ID="btnEditAsset" runat="server" Text="Edit Asset" CssClass="btn btn-primary" OnClick="btnEditAsset_Click" />
                    </div>
                </div>
                <!-- MESSAGE -->
                <asp:Label ID="lblMessage" runat="server" CssClass="message"></asp:Label>
                <!-- ASSET INFORMATION -->
                <div class="details-card">
                    <div class="card-header">
                        <div class="asset-icon">
                            <i class="bi bi-laptop"></i>
                        </div>
                        <div class="card-header-text">
                            <h2><asp:Label ID="lblAssetTagHeader" runat="server"></asp:Label></h2>
                            <p><asp:Label ID="lblAssetTypeHeader" runat="server"></asp:Label></p>
                        </div>
                    </div>
                    <div class="details-grid">
                        <div class="detail-item">
                            <div class="detail-label">Asset Tag</div>
                            <div class="detail-value asset-tag"><asp:Label ID="lblAssetTag" runat="server"></asp:Label></div>
                        </div>
                        <div class="detail-item">
                            <div class="detail-label">Serial Number</div>
                            <div class="detail-value"><asp:Label ID="lblSerialNumber" runat="server"></asp:Label></div>
                        </div>
                        <div class="detail-item">
                            <div class="detail-label">Asset Type</div>
                            <div class="detail-value"><asp:Label ID="lblAssetType" runat="server"></asp:Label></div>
                        </div>
                        <div class="detail-item">
                            <div class="detail-label">Make</div>
                            <div class="detail-value"><asp:Label ID="lblMake" runat="server"></asp:Label></div>
                        </div>
                        <div class="detail-item">
                            <div class="detail-label">Model</div>
                            <div class="detail-value"><asp:Label ID="lblModel" runat="server"></asp:Label></div>
                        </div>
                        <div class="detail-item">
                            <div class="detail-label">Condition</div>
                            <div class="detail-value"><asp:Label ID="lblCondition" runat="server" CssClass="condition"></asp:Label></div>
                        </div>
                        <div class="detail-item">
                            <div class="detail-label">Warranty Expiration Date</div>
                            <div class="detail-value"><asp:Label ID="lblWarrantyExpirationDate" runat="server"></asp:Label></div>
                        </div>
                        <div class="detail-item">
                            <div class="detail-label">Receive Date</div>
                            <div class="detail-value"><asp:Label ID="lblReceiveDate" runat="server"></asp:Label></div>
                        </div>
                    </div>
                </div>
                <!-- CURRENT ALLOCATION -->
                <div class="details-card">
                    <div class="card-header">
                        <div class="asset-icon">
                            <i class="bi bi-person-check"></i>
                        </div>
                        <div class="card-header-text">
                            <h2>Current Allocation</h2>
                            <p>Employee currently using this asset.</p>
                        </div>
                    </div>
                    <div class="allocation-section">
                        <asp:Panel ID="pnlCurrentAllocation" runat="server">
                            <div class="allocation-grid">
                                <div class="allocation-box">
                                    <span class="label">Employee Number</span>
                                    <span class="value"><asp:Label ID="lblEmployeeNumber" runat="server"></asp:Label></span>
                                </div>
                                <div class="allocation-box">
                                    <span class="label">Employee Name</span>
                                    <span class="value"><asp:Label ID="lblEmployeeName" runat="server"></asp:Label></span>
                                </div>
                                <div class="allocation-box">
                                    <span class="label">Allocation Date</span>
                                    <span class="value"><asp:Label ID="lblAllocationDate" runat="server"></asp:Label></span>
                                </div>
                                <div class="allocation-box">
                                    <span class="label">Status</span>
                                    <span class="value status-active"><asp:Label ID="lblAllocationStatus" runat="server"></asp:Label></span>
                                </div>
                                <div class="allocation-box">
                                    <span class="label">Condition at Issue</span>
                                    <span class="value"><asp:Label ID="lblConditionAtIssue" runat="server"></asp:Label></span>
                                </div>
                                <div class="allocation-box">
                                    <span class="label">Notes</span>
                                    <span class="value"><asp:Label ID="lblAllocationNotes" runat="server"></asp:Label></span>
                                </div>
                            </div>
                        </asp:Panel>
                        <asp:Panel ID="pnlNoAllocation" runat="server" CssClass="no-allocation" Visible="false">
                            <i class="bi bi-info-circle"></i>
                            This asset is currently available and is not assigned to an employee.
                        </asp:Panel>
                    </div>
                </div>
                <!-- ACTIONS -->
                <div class="action-card">
                    <div class="action-text">
                        <h3>Asset Actions</h3>
                        <p>Update the asset information or return to the asset list.</p>
                    </div>
                    <div class="action-buttons">
                        <asp:Button ID="btnBackBottom" runat="server" Text="Back" CssClass="btn btn-secondary" OnClick="btnBack_Click" />
                        <asp:Button ID="btnEditAssetBottom" runat="server" Text="Edit Asset" CssClass="btn btn-primary" OnClick="btnEditAsset_Click" />
                    </div>
                </div>
            </div>
        </div>
    </form>
</body>
</html>