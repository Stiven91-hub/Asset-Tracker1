﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="ImportData.aspx.cs" Inherits="Assets_Tracker.ImportData" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title>Import Data - IT Assets Management System</title>

    <link rel="stylesheet"
        href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap.min.css" />

    <style>

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, Helvetica, sans-serif;
        }

        body {
            background: #f4f7fb;
            color: #24364b;
        }

        /* ================= SIDEBAR ================= */

        .dashboard-container {
            display: flex;
            min-height: 100vh;
        }

        .sidebar {
            width: 265px;
            background: linear-gradient(180deg, #075b50, #12395f);
            color: white;
            display: flex;
            flex-direction: column;
            position: fixed;
            height: 100vh;
            left: 0;
            top: 0;
        }

        .logo {
            display: flex;
            align-items: center;
            gap: 15px;
            padding: 22px 20px;
            border-bottom: 1px solid rgba(255,255,255,0.12);
        }

        .logo-icon {
            width: 48px;
            height: 48px;
            border: 2px solid rgba(255,255,255,0.8);
            border-radius: 12px;
            display: flex;
            justify-content: center;
            align-items: center;
            font-size: 25px;
        }

        .logo-text {
            font-size: 18px;
            font-weight: bold;
            line-height: 1.3;
        }

        .logo-text span {
            display: block;
            font-weight: normal;
            opacity: 0.9;
        }

        .navigation {
            padding: 20px 10px;
            flex: 1;
        }

        .nav-item {
            display: flex;
            align-items: center;
            gap: 16px;
            padding: 16px 18px;
            margin-bottom: 8px;
            color: #e9f2f2;
            text-decoration: none;
            border-radius: 10px;
            font-size: 16px;
            font-weight: 500;
            transition: 0.3s;
        }

        .nav-item:hover {
            background: rgba(255,255,255,0.1);
        }

        .nav-item.active {
            background: linear-gradient(90deg, #2366c7, #3c7de0);
            color: white;
            box-shadow: 0 6px 15px rgba(0,0,0,0.15);
        }

        .nav-item i {
            font-size: 20px;
        }

        .logout {
            padding: 15px 10px;
            border-top: 1px solid rgba(255,255,255,0.12);
        }

        /* ================= MAIN CONTENT ================= */

        .main-content {
            margin-left: 265px;
            width: calc(100% - 265px);
            min-height: 100vh;
        }

        /* ================= TOPBAR ================= */

        .topbar {
            height: 80px;
            background: white;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0 40px;
            border-bottom: 1px solid #dfe5ec;
        }

        .topbar-left {
            display: flex;
            align-items: center;
            gap: 25px;
        }

        .menu-button {
            font-size: 25px;
            cursor: pointer;
        }

        .page-title {
            font-size: 26px;
            font-weight: bold;
        }

        .topbar-right {
            display: flex;
            align-items: center;
            gap: 30px;
        }

        .notifications {
            position: relative;
            font-size: 22px;
        }

        .notification-badge {
            width: 9px;
            height: 9px;
            background: red;
            border-radius: 50%;
            position: absolute;
            right: -3px;
            top: -2px;
        }

        .profile {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .profile-icon {
            width: 48px;
            height: 48px;
            background: #e9eef7;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #245bb2;
            font-size: 22px;
        }

        .profile-info {
            display: flex;
            flex-direction: column;
        }

        .profile-info span {
            font-size: 13px;
            color: #68778b;
            margin-top: 3px;
        }

        /* ================= CONTENT ================= */

        .content {
            padding: 40px;
        }

        .page-header {
            margin-bottom: 30px;
        }

        .page-header h1 {
            font-size: 30px;
            margin-bottom: 8px;
        }

        .page-header p {
            color: #68778b;
            font-size: 16px;
        }

        /* ================= IMPORT OPTIONS ================= */

        .import-options {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 22px;
            margin-bottom: 30px;
        }

        .option-card {
            background: white;
            border: 1px solid #dce3eb;
            border-radius: 14px;
            padding: 25px;
            cursor: pointer;
            transition: 0.3s;
        }

        .option-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 10px 25px rgba(0,0,0,0.08);
        }

        .option-card.active {
            border: 2px solid #2f6fd0;
            background: #f6f9ff;
        }

        .option-icon {
            width: 55px;
            height: 55px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 27px;
            margin-bottom: 18px;
        }

        .users-icon {
            background: #e8f0ff;
            color: #2463c6;
        }

        .assets-icon {
            background: #e8f6f3;
            color: #0b8c75;
        }

        .assignments-icon {
            background: #fff3e4;
            color: #e38a13;
        }

        .option-card h3 {
            margin-bottom: 8px;
            font-size: 19px;
        }

        .option-card p {
            color: #718096;
            font-size: 14px;
            line-height: 1.5;
        }

        /* ================= IMPORT PANEL ================= */

        .import-panel {
            background: white;
            border: 1px solid #dce3eb;
            border-radius: 14px;
            padding: 30px;
            margin-bottom: 25px;
        }

        .panel-header {
            margin-bottom: 25px;
        }

        .panel-header h2 {
            font-size: 22px;
            margin-bottom: 7px;
        }

        .panel-header p {
            color: #718096;
        }

        /* ================= FORM ================= */

        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 25px;
            margin-bottom: 25px;
        }

        .form-group {
            display: flex;
            flex-direction: column;
        }

        .form-group label {
            font-weight: 600;
            margin-bottom: 9px;
        }

        .select-input {
            width: 100%;
            padding: 13px 15px;
            border: 1px solid #d5dde6;
            border-radius: 8px;
            font-size: 15px;
            outline: none;
        }

        .select-input:focus {
            border-color: #2f6fd0;
        }

        /* ================= FILE UPLOAD ================= */

        .upload-area {
            border: 2px dashed #b9c7d8;
            border-radius: 12px;
            padding: 45px 20px;
            text-align: center;
            background: #fafcff;
            margin-bottom: 25px;
        }

        .upload-icon {
            font-size: 50px;
            color: #2f6fd0;
            margin-bottom: 15px;
        }

        .upload-area h3 {
            margin-bottom: 10px;
        }

        .upload-area p {
            color: #718096;
            margin-bottom: 20px;
        }

        .file-upload {
            display: inline-block;
            background: #eef3fb;
            color: #2f6fd0;
            padding: 12px 20px;
            border-radius: 8px;
            cursor: pointer;
            font-weight: 600;
        }

        .file-upload input {
            display: none;
        }

        /* ================= INFORMATION ================= */

        .info-box {
            background: #eef6ff;
            border-left: 4px solid #2f6fd0;
            padding: 18px;
            border-radius: 8px;
            margin-bottom: 25px;
            display: flex;
            gap: 14px;
        }

        .info-box i {
            font-size: 22px;
            color: #2f6fd0;
        }

        .info-box p {
            color: #4b6178;
            font-size: 14px;
            line-height: 1.6;
        }

        /* ================= BUTTONS ================= */

        .button-group {
            display: flex;
            justify-content: flex-end;
            gap: 15px;
        }

        .btn-cancel {
            background: white;
            border: 1px solid #ccd6e0;
            padding: 13px 25px;
            border-radius: 8px;
            cursor: pointer;
            font-size: 15px;
        }

        .btn-import {
            background: linear-gradient(90deg, #2f6fd0, #2360b8);
            border: none;
            color: white;
            padding: 13px 28px;
            border-radius: 8px;
            cursor: pointer;
            font-size: 15px;
            font-weight: 600;
        }

        .btn-import:hover {
            opacity: 0.9;
        }

        /* ================= SUPPORTED FILES ================= */

        .supported-files {
            background: white;
            border: 1px solid #dce3eb;
            border-radius: 14px;
            padding: 25px;
        }

        .supported-files h3 {
            margin-bottom: 20px;
        }

        .file-types {
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
        }

        .file-type {
            padding: 10px 16px;
            border-radius: 8px;
            background: #f4f7fb;
            color: #526273;
            font-size: 14px;
        }

        .file-type i {
            margin-right: 7px;
        }

        .excel {
            color: #1d8f4e;
        }

        .csv {
            color: #e38a13;
        }

        .word {
            color: #2f6fd0;
        }

        .powerpoint {
            color: #e25b3f;
        }

        /* ================= FOOTER ================= */

        .footer {
            text-align: center;
            color: #7a8797;
            padding: 30px;
            font-size: 14px;
        }

        @media(max-width: 1100px) {
            .import-options {
                grid-template-columns: 1fr;
            }

            .form-row {
                grid-template-columns: 1fr;
            }
        }

    </style>
</head>

<body>

<form id="form1" runat="server">
    <div class="dashboard-container">

        <!-- ================= SIDEBAR ================= -->

        <aside class="sidebar">
            <div class="logo">
                <div class="logo-icon">
                    <i class="bi bi-display"></i>
                </div>

                <div class="logo-text">
                    IT Assets Management
                    <span>System</span>
                </div>
            </div>

            <nav class="navigation">
                <a href="Dashboard.aspx" class="nav-item">
                    <i class="bi bi-grid"></i>
                    Dashboard
                </a>

                <a href="Users.aspx" class="nav-item">
                    <i class="bi bi-person"></i>
                    Users
                </a>

                <a href="Assets.aspx" class="nav-item">
                    <i class="bi bi-laptop"></i>
                    Assets
                </a>

                <a href="AssetAssignments.aspx" class="nav-item">
                    <i class="bi bi-person-check"></i>
                    Asset Assignments
                </a>

                <a href="Returns.aspx" class="nav-item">
                    <i class="bi bi-arrow-return-left"></i>
                    Returns
                </a>

                <a href="Documents.aspx" class="nav-item">
                    <i class="bi bi-file-earmark-text"></i>
                    Documents
                </a>

                <a href="ImportData.aspx" class="nav-item active">
                    <i class="bi bi-upload"></i>
                    Import Data
                </a>

                <a href="Reports.aspx" class="nav-item">
                    <i class="bi bi-bar-chart"></i>
                    Reports
                </a>

                <a href="AuditLogs.aspx" class="nav-item">
                    <i class="bi bi-shield-check"></i>
                    Audit Logs
                </a>
            </nav>

            <div class="logout">
                <a href="Login.aspx" class="nav-item">
                    <i class="bi bi-box-arrow-left"></i>
                    Logout
                </a>
            </div>
        </aside>

        <!-- ================= MAIN CONTENT ================= -->

        <main class="main-content">

            <!-- TOPBAR -->

            <header class="topbar">
                <div class="topbar-left">
                    <div class="menu-button">
                        <i class="bi bi-list"></i>
                    </div>

                    <div class="page-title">
                        Import Data
                    </div>
                </div>

                <div class="topbar-right">
                    <div class="profile">
                        <div class="profile-icon">
                            <i class="bi bi-person-fill"></i>
                        </div>

                        <div class="profile-info">
                            <strong>
                                <asp:Label ID="lblAdminName" runat="server">
                                    Administrator
                                </asp:Label>
                            </strong>

                            <span>
                                <asp:Label ID="lblAdminRole" runat="server">
                                    IT Administrator
                                </asp:Label>
                            </span>
                        </div>

                        <i class="bi bi-chevron-down"></i>
                    </div>
                </div>
            </header>

            <!-- ================= PAGE CONTENT ================= -->

            <section class="content">

                <!-- PAGE HEADER -->

                <div class="page-header">
                    <h1>Import Database Data</h1>
                    <p>
                        Import users, assets and asset assignment records into the system.
                    </p>
                </div>

                <!-- ================= IMPORT TYPE ================= -->

                <div class="import-options">

                    <!-- USERS -->

                    <div class="option-card active">
                        <div class="option-icon users-icon">
                            <i class="bi bi-people"></i>
                        </div>
                        <h3>Import Users</h3>
                        <p>
                            Upload employee or user information directly into the Users database.
                        </p>
                    </div>

                    <!-- ASSETS -->

                    <div class="option-card">
                        <div class="option-icon assets-icon">
                            <i class="bi bi-laptop"></i>
                        </div>
                        <h3>Import Assets</h3>
                        <p>
                            Upload laptops, monitors, desktops and other IT asset records.
                        </p>
                    </div>

                    <!-- ASSIGNMENTS -->

                    <div class="option-card">
                        <div class="option-icon assignments-icon">
                            <i class="bi bi-person-check"></i>
                        </div>
                        <h3>Import Assignments</h3>
                        <p>
                            Upload asset allocation and assignment records.
                        </p>
                    </div>

                </div>

                <!-- ================= IMPORT PANEL ================= -->

                <div class="import-panel">

                    <div class="panel-header">
                        <h2>Upload Import File</h2>
                        <p>
                            Select the database section and upload your file.
                        </p>
                    </div>

                    <!-- FORM ROW -->

                    <div class="form-row">

                        <div class="form-group">
                            <label>Import Category</label>
                            <asp:DropDownList
                                ID="ddlImportCategory"
                                runat="server"
                                CssClass="select-input">
                                <asp:ListItem Value="">-- Select Category --</asp:ListItem>
                                <asp:ListItem Value="Users">Users / Employees</asp:ListItem>
                                <asp:ListItem Value="Assets">Assets</asp:ListItem>
                                <asp:ListItem Value="Assignments">Asset Assignments</asp:ListItem>
                            </asp:DropDownList>
                        </div>

                        <div class="form-group">
                            <label>File Type</label>
                            <asp:DropDownList
                                ID="ddlFileType"
                                runat="server"
                                CssClass="select-input">
                                <asp:ListItem Value="">-- Select File Type --</asp:ListItem>
                                <asp:ListItem Value="Excel">Excel (.xlsx)</asp:ListItem>
                                <asp:ListItem Value="CSV">CSV (.csv)</asp:ListItem>
                                <asp:ListItem Value="Word">Word (.docx)</asp:ListItem>
                                <asp:ListItem Value="PowerPoint">PowerPoint (.pptx)</asp:ListItem>
                            </asp:DropDownList>
                        </div>

                    </div>

                    <!-- FILE UPLOAD -->

                    <div class="upload-area">
                        <div class="upload-icon">
                            <i class="bi bi-cloud-arrow-up"></i>
                        </div>

                        <h3>Choose a file to upload</h3>

                        <p>
                            Drag and drop your file here or browse your computer.
                        </p>

                        <label class="file-upload">
                            <i class="bi bi-folder2-open"></i>
                            Browse File
                            <asp:FileUpload
                                ID="fileUpload"
                                runat="server"
                                accept=".xlsx,.xls,.csv,.docx,.pptx" />
                        </label>

                        <br /><br />

                        <asp:Label
                            ID="lblFileName"
                            runat="server"
                            ForeColor="#2f6fd0">
                        </asp:Label>
                    </div>

                    <!-- INFORMATION -->

                    <div class="info-box">
                        <i class="bi bi-info-circle"></i>
                        <p>
                            For database imports, Excel and CSV files are recommended.
                            Make sure your spreadsheet columns match the database fields
                            before importing. Word and PowerPoint files can be uploaded
                            as documents but cannot automatically populate database tables.
                        </p>
                    </div>

                    <!-- MESSAGE -->

                    <asp:Label
                        ID="lblMessage"
                        runat="server"
                        Font-Bold="true">
                    </asp:Label>

                    <!-- BUTTONS -->

                    <div class="button-group">
                        <asp:Button
                            ID="btnCancel"
                            runat="server"
                            Text="Cancel"
                            CssClass="btn-cancel"
                            CausesValidation="false" />

                        <asp:Button
                            ID="btnImport"
                            runat="server"
                            Text="Import Data"
                            CssClass="btn-import"
                            OnClick="btnImport_Click" />
                    </div>

                </div>

                <!-- ================= SUPPORTED FILES ================= -->

                <div class="supported-files">
                    <h3>Supported File Formats</h3>

                    <div class="file-types">
                        <div class="file-type">
                            <i class="bi bi-file-earmark-excel excel"></i>
                            Excel (.xlsx)
                        </div>

                        <div class="file-type">
                            <i class="bi bi-filetype-csv csv"></i>
                            CSV (.csv)
                        </div>

                        <div class="file-type">
                            <i class="bi bi-file-earmark-word word"></i>
                            Word (.docx)
                        </div>

                        <div class="file-type">
                            <i class="bi bi-file-earmark-slides powerpoint"></i>
                            PowerPoint (.pptx)
                        </div>
                    </div>
                </div>

                <!-- FOOTER -->

                <footer class="footer">
                    &copy; 2026 IT Assets Management System. All rights reserved by S.N Nkuna.
                </footer>

            </section>

        </main>

    </div>
</form>

</body>
</html>