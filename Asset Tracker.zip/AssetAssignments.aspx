﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="AssetAssignments.aspx.cs" Inherits="Assets_Tracker.AssetAssignments" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title>Asset Assignments - IT Assets Management System</title>

    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" />

    <style>
        :root {
            --primary-color: #2878ed;
            --primary-hover: #1d63cb;
            --bg-body: #f4f7fb;
            --sidebar-gradient: linear-gradient(180deg, #006b4f 0%, #063b5c 100%);
            --text-main: #0f172a;
            --text-muted: #64748b;
            --border-color: #e2e8f0;
            --card-radius: 11px;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Arial, Helvetica, sans-serif;
        }

        body {
            background: var(--bg-body);
            color: var(--text-main);
        }

        /* ================= MAIN CONTAINER ================= */

        .dashboard-container {
            display: flex;
            min-height: 100vh;
        }

        /* ================= SIDEBAR ================= */

        .sidebar {
            width: 260px;
            background: var(--sidebar-gradient);
            color: white;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            flex-shrink: 0;
        }

        /* LOGO */

        .logo {
            height: 80px;
            display: flex;
            align-items: center;
            padding: 20px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.12);
        }

        .logo-icon {
            width: 42px;
            height: 42px;
            border: 2px solid white;
            color: white;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 21px;
            margin-right: 12px;
        }

        .logo-text {
            font-size: 15px;
            font-weight: bold;
            color: white;
        }

        .logo-text span {
            display: block;
            font-weight: normal;
            color: rgba(255, 255, 255, 0.85);
            margin-top: 3px;
            font-size: 13px;
        }

        /* NAVIGATION */

        .navigation {
            padding: 20px 12px;
            flex: 1;
        }

        .nav-item {
            display: flex;
            align-items: center;
            gap: 14px;
            padding: 12px 18px;
            margin-bottom: 6px;
            text-decoration: none;
            color: rgba(255, 255, 255, 0.9);
            border-radius: 7px;
            font-size: 14px;
            transition: all 0.2s ease;
        }

        .nav-item i {
            font-size: 18px;
            width: 20px;
            text-align: center;
        }

        .nav-item:hover {
            background: rgba(255, 255, 255, 0.12);
            color: white;
        }

        .nav-item.active {
            background: var(--primary-color);
            color: white;
            font-weight: 600;
            box-shadow: 0 3px 8px rgba(0, 0, 0, 0.15);
        }

        /* LOGOUT */

        .logout {
            padding: 15px 12px;
            border-top: 1px solid rgba(255, 255, 255, 0.12);
        }

        /* ================= MAIN CONTENT ================= */

        .main-content {
            flex: 1;
            min-width: 0;
            display: flex;
            flex-direction: column;
        }

        /* ================= TOPBAR ================= */

        .topbar {
            height: 80px;
            background: white;
            border-bottom: 1px solid var(--border-color);
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 35px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.02);
        }

        .topbar-left {
            display: flex;
            align-items: center;
            gap: 25px;
        }

        .menu-button {
            font-size: 24px;
            color: var(--text-main);
            cursor: pointer;
        }

        .page-title {
            font-size: 22px;
            font-weight: bold;
        }

        /* TOP RIGHT */

        .topbar-right {
            display: flex;
            align-items: center;
            gap: 25px;
        }

        /* NOTIFICATION */

        .notifications {
            position: relative;
            font-size: 22px;
            color: var(--text-main);
            cursor: pointer;
        }

        .notification-badge {
            position: absolute;
            top: -2px;
            right: -2px;
            width: 8px;
            height: 8px;
            background: #ef4444;
            border-radius: 50%;
        }

        /* PROFILE */

        .profile {
            display: flex;
            align-items: center;
            gap: 10px;
            cursor: pointer;
        }

        .profile-icon {
            width: 42px;
            height: 42px;
            background: #edf3ff;
            color: #1456c5;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
        }

        .profile-info strong {
            display: block;
            font-size: 14px;
        }

        .profile-info span {
            display: block;
            color: var(--text-muted);
            font-size: 12px;
            margin-top: 2px;
        }

        /* ================= CONTENT ================= */

        .content {
            padding: 35px;
            flex: 1;
        }

        /* PAGE HEADER */

        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
        }

        .heading h1 {
            font-size: 28px;
            margin-bottom: 4px;
            font-weight: 700;
        }

        .heading p {
            color: var(--text-muted);
            font-size: 14px;
        }

        /* ISSUE BUTTON */

        .add-button {
            background: var(--primary-color);
            color: white;
            text-decoration: none;
            border: none;
            border-radius: 8px;
            padding: 12px 20px;
            font-size: 14px;
            font-weight: bold;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: background 0.2s ease;
        }

        .add-button:hover {
            background: var(--primary-hover);
        }

        /* ================= STATISTICS ================= */

        .assignment-stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 20px;
            margin-bottom: 28px;
        }

        .stat-card {
            background: white;
            border: 1px solid #e1e7ef;
            border-radius: var(--card-radius);
            padding: 20px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.02);
            transition: transform 0.2s ease;
        }

        .stat-card:hover {
            transform: translateY(-2px);
        }

        .stat-icon {
            width: 48px;
            height: 48px;
            border-radius: 11px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 22px;
            margin-bottom: 13px;
        }

        .stat-card.total .stat-icon { background: #e6efff; color: #1769e0; }
        .stat-card.assigned .stat-icon { background: #e0f8eb; color: #009b54; }
        .stat-card.returned .stat-icon { background: #fff0d7; color: #e98b00; }
        .stat-card.pending .stat-icon { background: #ffe5e8; color: #dc3038; }

        .stat-card p {
            color: var(--text-muted);
            font-size: 13px;
            font-weight: 600;
            margin-bottom: 5px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .stat-card h2 {
            font-size: 26px;
            color: var(--text-main);
            font-weight: 700;
        }

        /* ================= ASSIGNMENT PANEL ================= */

        .panel {
            background: white;
            border: 1px solid #e0e6ef;
            border-radius: var(--card-radius);
            overflow: hidden;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.02);
        }

        .panel-header {
            padding: 20px 25px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid var(--border-color);
            background: #ffffff;
        }

        .panel-title {
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 16px;
            font-weight: bold;
        }

        .panel-title i {
            color: #1769e0;
            font-size: 20px;
        }

        /* ================= SEARCH ================= */

        .search-container {
            display: flex;
            gap: 10px;
        }

        .search-box {
            position: relative;
            width: 280px;
        }

        .search-box i {
            position: absolute;
            left: 12px;
            top: 50%;
            transform: translateY(-50%);
            color: #94a3b8;
            font-size: 16px;
        }

        .search-input {
            width: 100%;
            height: 40px;
            border: 1px solid #cbd5e1;
            border-radius: 7px;
            padding: 0 12px 0 36px;
            font-size: 13px;
            color: #334155;
            outline: none;
            transition: border-color 0.2s ease;
        }

        .search-input:focus {
            border-color: var(--primary-color);
        }

        .search-button {
            height: 40px;
            background: var(--primary-color);
            color: white;
            border: none;
            border-radius: 7px;
            padding: 0 20px;
            font-weight: bold;
            font-size: 13px;
            cursor: pointer;
            transition: background 0.2s ease;
        }

        .search-button:hover {
            background: var(--primary-hover);
        }

        /* ================= TABLE ================= */

        .table-wrapper {
            width: 100%;
            overflow-x: auto;
        }

        .assignment-table {
            width: 100%;
            border-collapse: collapse;
            text-align: left;
        }

        .assignment-table th {
            background: #f8fafc;
            color: #53657c;
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            font-weight: bold;
            padding: 16px;
            border-bottom: 1px solid var(--border-color);
        }

        .assignment-table td {
            padding: 15px 16px;
            border-bottom: 1px solid #edf1f5;
            font-size: 13px;
            color: #334155;
            vertical-align: middle;
        }

        .assignment-table tbody tr:hover {
            background: #fafcff;
        }

        /* ================= EMPLOYEE & ASSET INFO ================= */

        .employee-info, .asset-info {
            display: flex;
            align-items: center;
            gap: 11px;
        }

        .employee-icon, .asset-icon {
            width: 38px;
            height: 38px;
            border-radius: 50%;
            background: #edf3ff;
            color: #1769e0;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 18px;
            flex-shrink: 0;
        }

        .asset-icon {
            border-radius: 8px;
            background: #eaf2ff;
        }

        .employee-name {
            display: block;
            font-weight: bold;
            color: var(--text-main);
            margin-bottom: 2px;
        }

        .employee-number, .asset-model {
            display: block;
            color: var(--text-muted);
            font-size: 11px;
        }

        .asset-tag {
            display: block;
            color: #1769e0;
            font-weight: bold;
            margin-bottom: 2px;
        }

        /* ================= BADGES ================= */

        .type-badge {
            background: #f1f5f9;
            color: #475569;
            padding: 5px 10px;
            border-radius: 6px;
            font-size: 11px;
            font-weight: bold;
        }

        .status-badge {
            display: inline-block;
            padding: 5px 11px;
            border-radius: 6px;
            font-size: 11px;
            font-weight: bold;
        }

        .status-assigned { background: #dcfce7; color: #15803d; }
        .status-returned { background: #fff0d5; color: #c66a00; }

        /* ================= ACTIONS ================= */

        .actions {
            display: flex;
            gap: 7px;
        }

        .action-button {
            width: 32px;
            height: 32px;
            border-radius: 6px;
            display: flex;
            align-items: center;
            justify-content: center;
            text-decoration: none;
            font-size: 15px;
            transition: opacity 0.2s ease, transform 0.1s ease;
        }

        .view-button { background: #e8f0ff; color: #1769e0; }
        .edit-button { background: #fff1d9; color: #df8200; }
        .return-button { background: #e0f7e9; color: #159447; }

        .action-button:hover {
            opacity: 0.8;
            transform: scale(1.05);
        }

        /* ================= TABLE FOOTER ================= */

        .table-footer {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 25px;
            color: var(--text-muted);
            font-size: 13px;
            border-top: 1px solid var(--border-color);
        }

        .pagination {
            display: flex;
            gap: 6px;
        }

        .page-button {
            width: 34px;
            height: 34px;
            border: 1px solid #dbe2ea;
            background: white;
            border-radius: 6px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #475569;
            text-decoration: none;
            font-size: 12px;
            transition: all 0.2s ease;
        }

        .page-button.active {
            background: var(--primary-color);
            color: white;
            border-color: var(--primary-color);
        }

        .page-button:hover:not(.active) {
            background: #f1f5f9;
        }

        /* ================= FOOTER ================= */

        .footer {
            text-align: center;
            color: var(--text-muted);
            font-size: 12px;
            margin-top: 25px;
            padding-bottom: 20px;
        }

        /* ================= RESPONSIVE ================= */

        @media (max-width: 1024px) {
            .sidebar { width: 220px; }
            .assignment-stats { grid-template-columns: repeat(2, 1fr); }
        }

        @media (max-width: 768px) {
            .sidebar { display: none; }
            .assignment-stats { grid-template-columns: 1fr; }
            .content { padding: 20px; }
            .topbar { padding: 0 20px; }
            .page-header, .panel-header {
                flex-direction: column;
                align-items: flex-start;
                gap: 15px;
            }
            .search-container { width: 100%; }
            .search-box { width: 100%; }
        }
    </style>
</head>

<body>
    <form id="form1" runat="server">
        <div class="dashboard-container">

            <!-- ================= SIDEBAR ================= -->
            <aside class="sidebar">
                <div class="logo">
                    <div class="logo-icon">
                        <i class="bi bi-display"></i>
                    </div>
                    <div class="logo-text">
                        IT Assets Management
                        <span>System</span>
                    </div>
                </div>

                <!-- NAVIGATION -->
                <nav class="navigation">
                    <a href="Dashboard.aspx" class="nav-item">
                        <i class="bi bi-grid"></i> Dashboard
                    </a>
                    <a href="Users.aspx" class="nav-item">
                        <i class="bi bi-person"></i> Users
                    </a>
                    <a href="Assets.aspx" class="nav-item">
                        <i class="bi bi-laptop"></i> Assets
                    </a>
                    <a href="AssetAssignments.aspx" class="nav-item active">
                        <i class="bi bi-person-check"></i> Asset Assignments
                    </a>
                    <a href="Returns.aspx" class="nav-item">
                        <i class="bi bi-arrow-left-square"></i> Returns
                    </a>
                    <a href="Documents.aspx" class="nav-item">
                        <i class="bi bi-file-earmark-text"></i> Documents
                    </a>
                    <a href="Reports.aspx" class="nav-item">
                        <i class="bi bi-bar-chart"></i> Reports
                    </a>
                    <a href="AuditLogs.aspx" class="nav-item">
                        <i class="bi bi-shield-check"></i> Audit Logs
                    </a>
                    <a href="ImportData.aspx" class="nav-item">
                        <i class="bi bi-upload"></i> Import Data
                    </a>
                </nav>

                <!-- LOGOUT -->
                <div class="logout">
                    <a href="Login.aspx" class="nav-item">
                        <i class="bi bi-box-arrow-left"></i> Logout
                    </a>
                </div>
            </aside>

            <!-- ================= MAIN CONTENT ================= -->
            <main class="main-content">

                <!-- TOP BAR -->
                <header class="topbar">
                    <div class="topbar-left">
                        <div class="menu-button">
                            <i class="bi bi-list"></i>
                        </div>
                        <div class="page-title">Asset Assignments</div>
                    </div>

                    <div class="topbar-right">
                        <div class="profile">
                            <div class="profile-icon">
                                <i class="bi bi-person-fill"></i>
                            </div>
                            <div class="profile-info">
                                <strong>
                                    <asp:Label ID="lblAdminName" runat="server" Text="Administrator"></asp:Label>
                                </strong>
                                <span>
                                    <asp:Label ID="lblAdminRole" runat="server" Text="IT Administrator"></asp:Label>
                                </span>
                            </div>
                            <i class="bi bi-chevron-down" style="font-size: 12px; color: var(--text-muted);"></i>
                        </div>
                    </div>
                </header>

                <!-- PAGE CONTENT -->
                <section class="content">

                    <!-- PAGE HEADER -->
                    <div class="page-header">
                        <div class="heading">
                            <h1>Asset Assignments</h1>
                            <p>Manage and track IT assets assigned to employees.</p>
                        </div>
                        <a href="AddAssignment.aspx" class="add-button">
                            <i class="bi bi-person-plus"></i> Issue New Asset
                        </a>
                    </div>

                    <!-- STATISTICS -->
                    <div class="assignment-stats">
                        <div class="stat-card total">
                            <div class="stat-icon">
                                <i class="bi bi-clipboard-data"></i>
                            </div>
                            <p>Total Assignments</p>
                            <h2>
                                <asp:Label ID="lblTotalAssignments" runat="server" Text="0"></asp:Label>
                            </h2>
                        </div>

                        <div class="stat-card assigned">
                            <div class="stat-icon">
                                <i class="bi bi-person-check"></i>
                            </div>
                            <p>Currently Assigned</p>
                            <h2>
                                <asp:Label ID="lblAssigned" runat="server" Text="0"></asp:Label>
                            </h2>
                        </div>

                        <div class="stat-card returned">
                            <div class="stat-icon">
                                <i class="bi bi-arrow-return-left"></i>
                            </div>
                            <p>Returned Assets</p>
                            <h2>
                                <asp:Label ID="lblReturned" runat="server" Text="0"></asp:Label>
                            </h2>
                        </div>

                        <div class="stat-card pending">
                            <div class="stat-icon">
                                <i class="bi bi-exclamation-circle"></i>
                            </div>
                            <p>Pending Returns</p>
                            <h2>
                                <asp:Label ID="lblPending" runat="server" Text="0"></asp:Label>
                            </h2>
                        </div>
                    </div>

                    <!-- ASSIGNMENT PANEL -->
                    <div class="panel">

                        <!-- PANEL HEADER -->
                        <div class="panel-header">
                            <div class="panel-title">
                                <i class="bi bi-clipboard-check"></i> Assignment History
                            </div>

                            <div class="search-container">
                                <div class="search-box">
                                    <i class="bi bi-search"></i>
                                    <asp:TextBox ID="txtSearch" runat="server" CssClass="search-input" Placeholder="Search assignments..."></asp:TextBox>
                                </div>
                                <asp:Button ID="btnSearch" runat="server" Text="Search" CssClass="search-button" OnClick="btnSearch_Click" />
                            </div>
                        </div>

                        <!-- TABLE -->
                        <div class="table-wrapper">
                            <table class="assignment-table">
                                <thead>
                                    <tr>
                                        <th>Employee</th>
                                        <th>Asset</th>
                                        <th>Asset Type</th>
                                        <th>Date Assigned</th>
                                        <th>Return Date</th>
                                        <th>Status</th>
                                        <th>Condition</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <asp:Repeater ID="rptAssignments" runat="server">
                                        <ItemTemplate>
                                            <tr>
                                                <td>
                                                    <div class="employee-info">
                                                        <div class="employee-icon">
                                                            <i class="bi bi-person"></i>
                                                        </div>
                                                        <div>
                                                            <span class="employee-name"><%# Eval("EmployeeName") %></span>
                                                            <span class="employee-number"><%# Eval("EmployeeNumber") %></span>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="asset-info">
                                                        <div class="asset-icon">
                                                            <i class="bi bi-laptop"></i>
                                                        </div>
                                                        <div>
                                                            <span class="asset-tag"><%# Eval("AssetTag") %></span>
                                                            <span class="asset-model"><%# Eval("Make") %> <%# Eval("Model") %></span>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td>
                                                    <span class="type-badge"><%# Eval("AssetType") %></span>
                                                </td>
                                                <td>
                                                    <%# Convert.ToDateTime(Eval("AllocationDate")).ToString("dd MMM yyyy") %>
                                                </td>
                                                <td>
                                                    <%# Eval("ReturnDate") == DBNull.Value ? "-" : Convert.ToDateTime(Eval("ReturnDate")).ToString("dd MMM yyyy") %>
                                                </td>
                                                <td>
                                                    <span class="status-badge <%# Eval("Status").ToString() == "Assigned" ? "status-assigned" : "status-returned" %>">
                                                        <%# Eval("Status") %>
                                                    </span>
                                                </td>
                                                <td>
                                                    <%# Eval("ConditionAtIssue") %>
                                                </td>
                                                <td>
                                                    <div class="actions">
                                                        <a href="AssignmentDetails.aspx?id=<%# Eval("AllocationID") %>" class="action-button view-button" title="View Assignment">
                                                            <i class="bi bi-eye"></i>
                                                        </a>
                                                        <a href="EditAssignment.aspx?id=<%# Eval("AllocationID") %>" class="action-button edit-button" title="Edit Assignment">
                                                            <i class="bi bi-pencil-square"></i>
                                                        </a>
                                                        <a href="ReturnAsset.aspx?id=<%# Eval("AllocationID") %>" class="action-button return-button" title="Return Asset">
                                                            <i class="bi bi-arrow-return-left"></i>
                                                        </a>
                                                    </div>
                                                </td>
                                            </tr>
                                        </ItemTemplate>
                                    </asp:Repeater>
                                </tbody>
                            </table>
                        </div>

                        <!-- TABLE FOOTER -->
                        <div class="table-footer">
                            <div>
                                Showing <asp:Label ID="lblShowing" runat="server" Text="0"></asp:Label> assignments
                            </div>
                            <div class="pagination">
                                <a href="#" class="page-button"><i class="bi bi-chevron-double-left"></i></a>
                                <a href="#" class="page-button"><i class="bi bi-chevron-left"></i></a>
                                <a href="#" class="page-button active">1</a>
                                <a href="#" class="page-button">2</a>
                                <a href="#" class="page-button">3</a>
                                <a href="#" class="page-button"><i class="bi bi-chevron-right"></i></a>
                                <a href="#" class="page-button"><i class="bi bi-chevron-double-right"></i></a>
                            </div>
                        </div>
                    </div>

                    <footer class="footer">
                        &copy; 2026 IT Assets Management System. All rights reserved by S.N Nkuna.
                    </footer>

                </section>
            </main>
        </div>
    </form>
</body>
</html>