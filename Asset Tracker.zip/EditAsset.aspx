﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="EditAsset.aspx.cs" Inherits="Assets_Tracker.EditAsset" %>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title>Edit Asset - IT Asset Management System</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" />
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }
        body {
            font-family: Arial, Helvetica, sans-serif;
            background: #f4f6fb;
            color: #1f2937;
        }
        .sidebar {
            position: fixed;
            left: 0;
            top: 0;
            width: 250px;
            height: 100vh;
            background: linear-gradient(180deg, #0f5c4d, #123a5c);
            color: white;
            padding: 22px 15px;
            z-index: 1000;
        }
        .logo {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 5px 10px 25px 10px;
            font-size: 19px;
            font-weight: bold;
        }
        .logo i {
            font-size: 25px;
        }
        .nav-menu {
            list-style: none;
            margin-top: 15px;
        }
        .nav-menu li {
            margin-bottom: 6px;
        }
        .nav-menu a {
            display: flex;
            align-items: center;
            gap: 13px;
            color: white;
            text-decoration: none;
            padding: 12px 14px;
            border-radius: 8px;
            font-size: 14px;
            transition: 0.2s;
        }
        .nav-menu a:hover {
            background: rgba(255, 255, 255, 0.12);
        }
        .nav-menu a.active {
            background: linear-gradient(90deg, #2563c7, #3f7bd7);
        }
        .nav-menu i {
            font-size: 17px;
            width: 20px;
        }
        .main {
            margin-left: 250px;
            min-height: 100vh;
        }
        .topbar {
            height: 70px;
            background: white;
            border-bottom: 1px solid #e5e7eb;
            display: flex;
            justify-content: flex-end;
            align-items: center;
            padding: 0 30px;
        }
        .admin-info {
            display: flex;
            align-items: center;
            gap: 12px;
        }
        .admin-icon {
            width: 42px;
            height: 42px;
            border-radius: 50%;
            background: #eaf2ff;
            color: #2563c7;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
        }
        .admin-text {
            display: flex;
            flex-direction: column;
            align-items: flex-end;
        }
        .admin-name {
            font-weight: bold;
            font-size: 14px;
        }
        .admin-role {
            color: #6b7280;
            font-size: 12px;
            margin-top: 2px;
        }
        .content {
            padding: 30px;
            max-width: 1100px;
        }
        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
        }
        .page-title h1 {
            font-size: 27px;
            color: #1f2937;
            margin-bottom: 7px;
        }
        .page-title p {
            color: #6b7280;
            font-size: 14px;
        }
        .header-icon {
            width: 50px;
            height: 50px;
            background: #eaf2ff;
            color: #2563c7;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
        }
        .form-card {
            background: white;
            border-radius: 12px;
            border: 1px solid #e5e7eb;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.04);
            padding: 28px;
        }
        .form-section {
            margin-bottom: 28px;
        }
        .section-title {
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 17px;
            font-weight: bold;
            color: #1f2937;
            padding-bottom: 12px;
            border-bottom: 1px solid #e5e7eb;
            margin-bottom: 20px;
        }
        .section-title i {
            color: #2563c7;
            font-size: 19px;
        }
        .form-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 20px;
        }
        .form-group {
            display: flex;
            flex-direction: column;
        }
        .form-group.full-width {
            grid-column: 1 / -1;
        }
        .form-label {
            font-size: 13px;
            font-weight: 600;
            color: #374151;
            margin-bottom: 7px;
        }
        .required {
            color: #dc2626;
        }
        .form-control {
            width: 100%;
            height: 43px;
            border: 1px solid #d1d5db;
            border-radius: 7px;
            padding: 0 12px;
            font-size: 14px;
            color: #1f2937;
            background: white;
            outline: none;
            transition: 0.2s;
        }
        textarea.form-control {
            height: 90px;
            padding-top: 10px;
            resize: vertical;
        }
        .form-control:focus {
            border-color: #2563c7;
            box-shadow: 0 0 0 3px rgba(37, 99, 199, 0.10);
        }
        .form-control[readonly] {
            background: #f3f4f6;
            color: #6b7280;
            cursor: not-allowed;
        }
        .help-text {
            color: #6b7280;
            font-size: 11px;
            margin-top: 5px;
        }
        .message {
            display: block;
            padding: 13px 16px;
            border-radius: 7px;
            margin-bottom: 20px;
            font-size: 14px;
        }
        .success-message {
            background: #ecfdf5;
            color: #047857;
            border: 1px solid #a7f3d0;
        }
        .error-message {
            background: #fef2f2;
            color: #b91c1c;
            border: 1px solid #fecaca;
        }
        .form-actions {
            display: flex;
            justify-content: flex-end;
            gap: 10px;
            border-top: 1px solid #e5e7eb;
            padding-top: 22px;
            margin-top: 10px;
        }
        .btn {
            border: none;
            border-radius: 7px;
            padding: 11px 20px;
            font-size: 14px;
            cursor: pointer;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            font-weight: 600;
        }
        .btn-primary {
            background: #2563c7;
            color: white;
        }
        .btn-primary:hover {
            background: #1e4fa5;
        }
        .btn-secondary {
            background: white;
            color: #374151;
            border: 1px solid #d1d5db;
        }
        .btn-secondary:hover {
            background: #f9fafb;
        }
        .asset-tag-info {
            background: #f0f7ff;
            border: 1px solid #cfe0f7;
            border-radius: 8px;
            padding: 14px 16px;
            margin-bottom: 22px;
            display: flex;
            align-items: center;
            gap: 10px;
            color: #1e40af;
            font-size: 13px;
        }
        .asset-tag-info i {
            font-size: 18px;
        }
        @media (max-width: 800px) {
            .sidebar {
                width: 220px;
            }
            .main {
                margin-left: 220px;
            }
            .form-grid {
                grid-template-columns: 1fr;
            }
            .form-group.full-width {
                grid-column: auto;
            }
        }
        @media (max-width: 650px) {
            .sidebar {
                position: relative;
                width: 100%;
                height: auto;
            }
            .main {
                margin-left: 0;
            }
            .content {
                padding: 20px;
            }
            .page-header {
                flex-direction: column;
                align-items: flex-start;
                gap: 15px;
            }
            .form-card {
                padding: 20px;
            }
            .form-actions {
                flex-direction: column;
            }
            .form-actions .btn {
                width: 100%;
            }
        }
    </style>
</head>
<body>
    <form id="form1" runat="server">
        <!-- SIDEBAR -->
        <div class="sidebar">
            <div class="logo">
                <i class="bi bi-pc-display"></i>
                <span>IT Assets Management System</span>
            </div>
            <ul class="nav-menu">
                <li>
                    <a href="Dashboard.aspx">
                        <i class="bi bi-speedometer2"></i>
                        <span>Dashboard</span>
                    </a>
                </li>
                <li>
                    <a href="Users.aspx">
                        <i class="bi bi-people"></i>
                        <span>Employees</span>
                    </a>
                </li>
                <li>
                    <a href="Assets.aspx" class="active">
                        <i class="bi bi-laptop"></i>
                        <span>Assets</span>
                    </a>
                </li>
                <li>
                    <a href="AssetAssignments.aspx">
                        <i class="bi bi-arrow-left-right"></i>
                        <span>Asset Assignments</span>
                    </a>
                </li>
                <li>
                    <a href="Returns.aspx">
                        <i class="bi bi-box-arrow-in-down"></i>
                        <span>Returns</span>
                    </a>
                </li>
                <li>
                    <a href="Documents.aspx">
                        <i class="bi bi-file-earmark-text"></i>
                        <span>Documents</span>
                    </a>
                </li>
                <li>
                    <a href="Reports.aspx">
                        <i class="bi bi-bar-chart"></i>
                        <span>Reports</span>
                    </a>
                </li>
                <li>
                    <a href="AuditLogs.aspx">
                        <i class="bi bi-clock-history"></i>
                        <span>Audit Logs</span>
                    </a>
                </li>
            </ul>
        </div>
        <!-- MAIN -->
        <div class="main">
            <!-- TOPBAR -->
            <div class="topbar">
                <div class="admin-info">
                    <div class="admin-icon">
                        <i class="bi bi-person-circle"></i>
                    </div>
                    <div class="admin-text">
                        <asp:Label ID="lblAdminName" runat="server" CssClass="admin-name"></asp:Label>
                        <asp:Label ID="lblAdminRole" runat="server" CssClass="admin-role"></asp:Label>
                    </div>
                </div>
            </div>
            <!-- CONTENT -->
            <div class="content">
                <!-- PAGE HEADER -->
                <div class="page-header">
                    <div class="page-title">
                        <h1>Edit Asset</h1>
                        <p>Update the information for this IT asset.</p>
                    </div>
                    <div class="header-icon">
                        <i class="bi bi-pencil-square"></i>
                    </div>
                </div>
                <!-- MESSAGE -->
                <asp:Label ID="lblMessage" runat="server" CssClass="message"></asp:Label>
                <!-- FORM CARD -->
                <div class="form-card">
                    <!-- ASSET IDENTIFICATION -->
                    <div class="form-section">
                        <div class="section-title">
                            <i class="bi bi-upc-scan"></i>
                            Asset Identification
                        </div>
                        <div class="asset-tag-info">
                            <i class="bi bi-info-circle"></i>
                            <span>The Asset Tag is the unique identifier for this asset and cannot be changed.</span>
                        </div>
                        <div class="form-grid">
                            <div class="form-group">
                                <label class="form-label">
                                    Asset Tag
                                    <span class="required">*</span>
                                </label>
                                <asp:TextBox ID="txtAssetTag" runat="server" CssClass="form-control" ReadOnly="true"></asp:TextBox>
                                <span class="help-text">Primary key and unique asset identifier.</span>
                            </div>
                            <div class="form-group">
                                <label class="form-label">
                                    Serial Number
                                    <span class="required">*</span>
                                </label>
                                <asp:TextBox ID="txtSerialNumber" runat="server" CssClass="form-control"></asp:TextBox>
                            </div>
                        </div>
                    </div>
                    <!-- ASSET INFORMATION -->
                    <div class="form-section">
                        <div class="section-title">
                            <i class="bi bi-laptop"></i>
                            Asset Information
                        </div>
                        <div class="form-grid">
                            <div class="form-group">
                                <label class="form-label">
                                    Asset Type
                                    <span class="required">*</span>
                                </label>
                                <asp:DropDownList ID="ddlAssetType" runat="server" CssClass="form-control">
                                    <asp:ListItem Text="-- Select Asset Type --" Value=""></asp:ListItem>
                                    <asp:ListItem Text="Laptop" Value="Laptop"></asp:ListItem>
                                    <asp:ListItem Text="Desktop" Value="Desktop"></asp:ListItem>
                                    <asp:ListItem Text="Monitor" Value="Monitor"></asp:ListItem>
                                    <asp:ListItem Text="Printer" Value="Printer"></asp:ListItem>
                                    <asp:ListItem Text="Tablet" Value="Tablet"></asp:ListItem>
                                    <asp:ListItem Text="Mobile Phone" Value="Mobile Phone"></asp:ListItem>
                                    <asp:ListItem Text="Keyboard" Value="Keyboard"></asp:ListItem>
                                    <asp:ListItem Text="Mouse" Value="Mouse"></asp:ListItem>
                                    <asp:ListItem Text="Docking Station" Value="Docking Station"></asp:ListItem>
                                    <asp:ListItem Text="Other" Value="Other"></asp:ListItem>
                                </asp:DropDownList>
                            </div>
                            <div class="form-group">
                                <label class="form-label">
                                    Make
                                    <span class="required">*</span>
                                </label>
                                <asp:TextBox ID="txtMake" runat="server" CssClass="form-control"></asp:TextBox>
                            </div>
                            <div class="form-group">
                                <label class="form-label">
                                    Model
                                    <span class="required">*</span>
                                </label>
                                <asp:TextBox ID="txtModel" runat="server" CssClass="form-control"></asp:TextBox>
                            </div>
                            <div class="form-group">
                                <label class="form-label">
                                    Condition
                                    <span class="required">*</span>
                                </label>
                                <asp:DropDownList ID="ddlCondition" runat="server" CssClass="form-control">
                                    <asp:ListItem Text="-- Select Condition --" Value=""></asp:ListItem>
                                    <asp:ListItem Text="New" Value="New"></asp:ListItem>
                                    <asp:ListItem Text="Good" Value="Good"></asp:ListItem>
                                    <asp:ListItem Text="Fair" Value="Fair"></asp:ListItem>
                                    <asp:ListItem Text="Poor" Value="Poor"></asp:ListItem>
                                    <asp:ListItem Text="Under Maintenance" Value="Under Maintenance"></asp:ListItem>
                                    <asp:ListItem Text="Retired" Value="Retired"></asp:ListItem>
                                </asp:DropDownList>
                            </div>
                        </div>
                    </div>
                    <!-- DATES -->
                    <div class="form-section">
                        <div class="section-title">
                            <i class="bi bi-calendar3"></i>
                            Asset Dates
                        </div>
                        <div class="form-grid">
                            <div class="form-group">
                                <label class="form-label">
                                    Warranty Expiration Date
                                    <span class="required">*</span>
                                </label>
                                <asp:TextBox ID="txtWarrantyExpirationDate" runat="server" CssClass="form-control" TextMode="Date"></asp:TextBox>
                            </div>
                            <div class="form-group">
                                <label class="form-label">
                                    Receive Date
                                    <span class="required">*</span>
                                </label>
                                <asp:TextBox ID="txtReceiveDate" runat="server" CssClass="form-control" TextMode="Date"></asp:TextBox>
                            </div>
                        </div>
                    </div>
                    <!-- ACTION BUTTONS -->
                    <div class="form-actions">
                        <asp:Button ID="btnCancel" runat="server" Text="Cancel" CssClass="btn btn-secondary" OnClick="btnCancel_Click" />
                        <asp:Button ID="btnUpdate" runat="server" Text="Update Asset" CssClass="btn btn-primary" OnClick="btnUpdate_Click" OnClientClick="return confirm('Are you sure you want to update this asset?');" />
                    </div>
                </div>
            </div>
        </div>
    </form>
</body>
</html>