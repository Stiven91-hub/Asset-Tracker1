﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="Returns.aspx.cs" Inherits="Assets_Tracker.Returns" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title>Returns - IT Assets Management System</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" />
    <style>
        :root {
            --primary-color: #2878ed;
            --primary-hover: #1764d1;
            --bg-body: #f4f7fb;
            --sidebar-gradient: linear-gradient(180deg, #006b4f, #063b63);
            --text-main: #10213f;
            --text-muted: #687994;
            --border-color: #dfe5ed;
            --card-radius: 12px;
        }

        *, *::before, *::after {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            background: var(--bg-body);
            color: var(--text-main);
            font-family: 'Segoe UI', -apple-system, BlinkMacSystemFont, Roboto, Helvetica, Arial, sans-serif;
            -webkit-font-smoothing: antialiased;
        }

        .dashboard-container {
            display: flex;
            min-height: 100vh;
        }

        /* ================= SIDEBAR ================= */

        .sidebar {
            width: 300px;
            background: var(--sidebar-gradient);
            color: #ffffff;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            flex-shrink: 0;
        }

        .logo {
            height: 90px;
            display: flex;
            align-items: center;
            padding: 20px 25px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.15);
        }

        .logo-icon {
            width: 48px;
            height: 48px;
            border: 2px solid #ffffff;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 15px;
            font-size: 24px;
        }

        .logo-text {
            font-size: 18px;
            font-weight: 700;
            line-height: 1.2;
        }

        .logo-text span {
            display: block;
            font-size: 14px;
            font-weight: 400;
            opacity: 0.85;
        }

        /* ================= NAVIGATION ================= */

        .navigation {
            padding: 20px 15px;
            flex: 1;
        }

        .nav-item {
            display: flex;
            align-items: center;
            gap: 15px;
            color: rgba(255, 255, 255, 0.9);
            text-decoration: none;
            padding: 12px 18px;
            margin-bottom: 6px;
            border-radius: 8px;
            font-size: 15px;
            font-weight: 600;
            transition: background 0.2s ease, color 0.2s ease;
        }

        .nav-item i {
            font-size: 20px;
            width: 24px;
            text-align: center;
        }

        .nav-item:hover {
            background: rgba(255, 255, 255, 0.12);
            color: #ffffff;
        }

        .nav-item.active {
            background: var(--primary-color);
            color: #ffffff;
        }

        .logout {
            padding: 20px 15px;
            border-top: 1px solid rgba(255, 255, 255, 0.15);
        }

        /* ================= MAIN CONTENT ================= */

        .main-content {
            flex: 1;
            min-width: 0;
            display: flex;
            flex-direction: column;
        }

        /* ================= TOP BAR ================= */

        .topbar {
            height: 90px;
            background: #ffffff;
            border-bottom: 1px solid var(--border-color);
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 35px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.02);
        }

        .topbar-left {
            display: flex;
            align-items: center;
            gap: 20px;
        }

        .menu-button {
            font-size: 24px;
            cursor: pointer;
            color: var(--text-main);
        }

        .page-title {
            font-size: 22px;
            font-weight: 700;
        }

        .topbar-right {
            display: flex;
            align-items: center;
            gap: 20px;
        }

        .profile {
            display: flex;
            align-items: center;
            gap: 12px;
            cursor: pointer;
        }

        .profile-icon {
            width: 42px;
            height: 42px;
            background: #edf3ff;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--primary-color);
            font-size: 20px;
        }

        .profile-info {
            display: flex;
            flex-direction: column;
        }

        .profile-info strong {
            font-size: 14px;
            color: var(--text-main);
        }

        .profile-info span {
            font-size: 12px;
            color: var(--text-muted);
        }

        /* ================= CONTENT ================= */

        .content {
            padding: 35px;
            flex: 1;
        }

        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
        }

        .heading h1 {
            font-size: 28px;
            font-weight: 700;
            margin-bottom: 4px;
        }

        .heading p {
            color: var(--text-muted);
            font-size: 15px;
        }

        .btn-primary-action {
            background-color: var(--primary-color);
            color: #ffffff;
            border: none;
            padding: 10px 20px;
            font-size: 14px;
            font-weight: 600;
            border-radius: 8px;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: background-color 0.2s ease, transform 0.1s ease;
        }

        .btn-primary-action:hover {
            background-color: var(--primary-hover);
            transform: translateY(-1px);
        }

        /* ================= STAT CARDS ================= */

        .return-stats {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .stat-card {
            background: #ffffff;
            border: 1px solid var(--border-color);
            border-radius: var(--card-radius);
            padding: 20px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.02);
            transition: transform 0.2s ease, box-shadow 0.2s ease;
        }

        .stat-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 15px rgba(0, 0, 0, 0.04);
        }

        .stat-icon {
            width: 48px;
            height: 48px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 22px;
            margin-bottom: 12px;
        }

        .stat-card p {
            color: var(--text-muted);
            font-size: 13px;
            font-weight: 600;
            margin-bottom: 4px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .stat-card h2 {
            font-size: 28px;
            font-weight: 700;
        }

        .pending .stat-icon { background: #fff1d8; color: #e78a00; }
        .returned .stat-icon { background: #e0f7ea; color: #009b50; }
        .today .stat-icon { background: #e2edff; color: #1769e0; }
        .damaged .stat-icon { background: #ffe2e5; color: #d52d3a; }

        /* ================= PANEL ================= */

        .panel {
            background: #ffffff;
            border: 1px solid var(--border-color);
            border-radius: var(--card-radius);
            overflow: hidden;
            margin-bottom: 30px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.02);
        }

        .panel-header {
            padding: 20px 25px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid var(--border-color);
            background: #ffffff;
        }

        .panel-title {
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 17px;
            font-weight: 700;
        }

        .panel-title i {
            color: var(--primary-color);
            font-size: 20px;
        }

        /* ================= SEARCH ================= */

        .search-container {
            display: flex;
            gap: 8px;
        }

        .search-box {
            position: relative;
        }

        .search-box i {
            position: absolute;
            left: 14px;
            top: 50%;
            transform: translateY(-50%);
            color: #7a899f;
            font-size: 14px;
            pointer-events: none;
        }

        .search-input {
            width: 260px;
            height: 40px;
            border: 1px solid #ccd5e2;
            border-radius: 6px;
            padding: 0 15px 0 38px;
            outline: none;
            font-size: 14px;
            transition: border-color 0.2s ease;
        }

        .search-input:focus {
            border-color: var(--primary-color);
        }

        .search-button {
            background: var(--primary-color);
            color: #ffffff;
            border: none;
            padding: 0 20px;
            height: 40px;
            border-radius: 6px;
            font-weight: 600;
            font-size: 14px;
            cursor: pointer;
            transition: background-color 0.2s ease;
        }

        .search-button:hover {
            background: var(--primary-hover);
        }

        /* ================= TABLE ================= */

        .table-wrapper {
            width: 100%;
            overflow-x: auto;
        }

        .return-table {
            width: 100%;
            border-collapse: collapse;
            text-align: left;
        }

        .return-table th {
            background: #f8fafc;
            color: var(--text-muted);
            font-size: 12px;
            padding: 14px 20px;
            border-bottom: 1px solid var(--border-color);
            text-transform: uppercase;
            letter-spacing: 0.5px;
            font-weight: 700;
        }

        .return-table td {
            padding: 16px 20px;
            border-bottom: 1px solid #edf0f4;
            font-size: 14px;
            vertical-align: middle;
        }

        .return-table tr:last-child td {
            border-bottom: none;
        }

        .return-table tr:hover {
            background: #fafcff;
        }

        .employee-info, .asset-info {
            display: flex;
            flex-direction: column;
            gap: 2px;
        }

        .employee-name, .asset-tag {
            font-weight: 600;
            color: var(--text-main);
        }

        .employee-number, .serial-number {
            color: var(--text-muted);
            font-size: 12px;
        }

        /* ================= BADGES ================= */

        .status-badge {
            display: inline-block;
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
        }

        .status-pending { background: #fff0d5; color: #c87500; }
        .status-returned { background: #dff6e8; color: #087f40; }

        .condition-badge {
            display: inline-block;
            padding: 4px 10px;
            border-radius: 6px;
            background: #eef2f7;
            color: #4c5c72;
            font-size: 12px;
            font-weight: 500;
        }

        /* ================= ACTIONS ================= */

        .actions {
            display: flex;
            gap: 8px;
        }

        .action-button {
            width: 34px;
            height: 34px;
            border-radius: 6px;
            display: flex;
            align-items: center;
            justify-content: center;
            text-decoration: none;
            border: none;
            cursor: pointer;
            font-size: 16px;
            transition: opacity 0.2s ease, transform 0.1s ease;
        }

        .return-button { background: #e2f7ea; color: #008b48; }
        .view-button { background: #e7efff; color: var(--primary-color); }

        .action-button:hover {
            opacity: 0.85;
            transform: scale(1.05);
        }

        /* ================= RESPONSIVE ================= */

        @media (max-width: 1024px) {
            .sidebar { width: 240px; }
            .return-stats { grid-template-columns: repeat(2, 1fr); }
        }

        @media (max-width: 768px) {
            .sidebar { display: none; }
            .return-stats { grid-template-columns: 1fr; }
            .content { padding: 20px; }
            .topbar { padding: 0 20px; }
            .page-header, .panel-header {
                flex-direction: column;
                align-items: flex-start;
                gap: 15px;
            }
            .search-container {
                width: 100%;
            }
            .search-box, .search-input {
                width: 100%;
            }
        }
    </style>
</head>
<body>
    <form id="form1" runat="server">
        <div class="dashboard-container">
            <!--===========Sidebar===========-->
            <aside class="sidebar">
                <div class="logo">
                    <div class="logo-icon">
                        <i class="bi bi-display"></i>
                    </div>
                    <div class="logo-text">
                        IT Assets Management
                        <span>System</span>
                    </div>
                </div>

                <!--Navigation-->
                <nav class="navigation">
                    <a href="Dashboard.aspx" class="nav-item">
                        <i class="bi bi-grid"></i> Dashboard
                    </a>
                    <a href="Users.aspx" class="nav-item">
                        <i class="bi bi-person"></i> Users
                    </a>
                    <a href="Assets.aspx" class="nav-item">
                        <i class="bi bi-laptop"></i> Assets
                    </a>
                    <a href="AssetAssignments.aspx" class="nav-item">
                        <i class="bi bi-person-check"></i> Asset Assignments
                    </a>
                    <a href="Returns.aspx" class="nav-item active">
                        <i class="bi bi-arrow-return-left"></i> Returns
                    </a>
                    <a href="Documents.aspx" class="nav-item">
                        <i class="bi bi-file-earmark-text"></i> Documents
                    </a>
                    <a href="Reports.aspx" class="nav-item">
                        <i class="bi bi-bar-chart"></i> Reports
                    </a>
                    <a href="AuditLogs.aspx" class="nav-item">
                        <i class="bi bi-shield-check"></i> Audit Logs
                    </a>
                    <a href="ImportData.aspx" class="nav-item">
                        <i class="bi bi-upload"></i> Import Data
                    </a>
                </nav>

                <div class="logout">
                    <a href="LoginPage.aspx" class="nav-item">
                        <i class="bi bi-box-arrow-left"></i> Logout
                    </a>
                </div>
            </aside>

            <!--===========Main Content===========-->
            <main class="main-content">
                <!--========topbar========-->
                <header class="topbar">
                    <div class="topbar-left">
                        <div class="menu-button">
                            <i class="bi bi-list"></i>
                        </div>
                        <div class="page-title">Returns</div>
                    </div>
                    <div class="topbar-right">
                        <div class="profile">
                            <div class="profile-icon">
                                <i class="bi bi-person-fill"></i>
                            </div>
                            <div class="profile-info">
                                <strong>
                                    <asp:Label ID="lblAdminName" runat="server" Text="Administrator"></asp:Label>
                                </strong>
                                <span>
                                    <asp:Label ID="lblAdminRole" runat="server" Text="IT Administrator"></asp:Label>
                                </span>
                            </div>
                            <i class="bi bi-chevron-down" style="font-size: 12px; color: var(--text-muted);"></i>
                        </div>
                    </div>
                </header>

                <!--========Content========-->
                <section class="content">
                    <!--page header-->
                    <div class="page-header">
                        <div class="heading">
                            <h1>Assets Returns</h1>
                            <p>Manage and track asset returns</p>
                        </div>
                        <asp:Button
                            ID="btnReturn"
                            runat="server"
                            CssClass="btn-primary-action"
                            Text="Return Asset"
                            OnClick="btnReturn_Click"/>
                    </div>

                    <!--=========Stats========-->
                    <div class="return-stats">
                        <!--Pending-->
                        <div class="stat-card pending">
                            <div class="stat-icon">
                                <i class="bi bi-clock-history"></i>
                            </div>
                            <p>Pending Returns</p>
                            <h2>
                                <asp:Label ID="lblPendingsReturns" runat="server" Text="0"></asp:Label>
                            </h2>
                        </div>

                        <!--Returned Assets-->
                        <div class="stat-card returned">
                            <div class="stat-icon">
                                <i class="bi bi-check-circle"></i>
                            </div>
                            <p>Returned Assets</p>
                            <h2>
                                <asp:Label ID="lblReturnedAssets" runat="server" Text="0"></asp:Label>
                            </h2>
                        </div>

                        <!--Returned Today-->
                        <div class="stat-card today">
                            <div class="stat-icon">
                                <i class="bi bi-calendar-check"></i>
                            </div>
                            <p>Returned Today</p>
                            <h2>
                                <asp:Label ID="lblReturnedToday" runat="server" Text="0"></asp:Label>
                            </h2>
                        </div>

                        <!--Damaged-->
                        <div class="stat-card damaged">
                            <div class="stat-icon">
                                <i class="bi bi-exclamation-triangle"></i>
                            </div>
                            <p>Returned Damaged</p>
                            <h2>
                                <asp:Label ID="lblDamagedReturns" runat="server" Text="0"></asp:Label>
                            </h2>
                        </div>
                    </div>

                    <!--Pending Returns Table-->
                    <div class="panel">
                        <div class="panel-header">
                            <div class="panel-title">
                                <i class="bi bi-arrow-return-left"></i>
                                Pending Asset Returns
                            </div>
                            <div class="search-container">
                                <div class="search-box">
                                    <i class="bi bi-search"></i>
                                    <asp:TextBox ID="txtSearch" runat="server" CssClass="search-input" Placeholder="Search returns..." />
                                </div>
                                <asp:Button ID="btnSearch" runat="server" Text="Search" CssClass="search-button" OnClick="btnSearch_Click" />
                            </div>
                        </div>
                        <div class="table-wrapper">
                            <table class="return-table">
                                <thead>
                                    <tr>
                                        <th>Employee</th>
                                        <th>Asset</th>
                                        <th>Asset Type</th>
                                        <th>Issue Date</th>
                                        <th>Issue Condition</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <asp:Repeater ID="rptrPendingReturns" runat="server">
                                        <ItemTemplate>
                                            <tr>
                                                <td>
                                                    <div class="employee-info">
                                                        <span class="employee-name">
                                                            <%# Eval("FirstName") %> <%# Eval("LastName") %>
                                                        </span>
                                                        <span class="employee-number">
                                                            <%# Eval("EmployeeNumber") %>
                                                        </span>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="asset-info">
                                                        <span class="asset-tag">
                                                            <%# Eval("AssetTag") %>
                                                        </span>
                                                        <span class="serial-number">
                                                            S/N: <%# Eval("SerialNumber") %>
                                                        </span>
                                                    </div>
                                                </td>
                                                <td><%# Eval("AssetType") %></td>
                                                <td><%# Eval("AllocationDate", "{0:dd MM yyyy}") %></td> 
                                                <td>
                                                    <span class="condition-badge">
                                                        <%# Eval("ConditionAtIssue") %>
                                                    </span>
                                                </td>
                                                <td>
                                                    <span class="status-badge status-pending">
                                                        <%# Eval("Status") %>
                                                    </span>
                                                </td>
                                                <td>
                                                    <div class="actions">
                                                        <a href="ProcessReturn.aspx?id=<%# Eval("AllocationID") %>" class="action-button return-button" title="Process Return">
                                                            <i class="bi bi-arrow-return-left"></i>
                                                        </a>
                                                        <a href="AllocationDetails.aspx?id=<%# Eval("AllocationID") %>" class="action-button view-button" title="View Details">
                                                            <i class="bi bi-eye"></i>
                                                        </a>
                                                    </div>
                                                </td>
                                            </tr>
                                        </ItemTemplate>
                                    </asp:Repeater>
                                </tbody>
                            </table>
                        </div>
                    </div>

                    <!--Return History Table-->
                    <div class="panel">
                        <div class="panel-header">
                            <div class="panel-title">
                                <i class="bi bi-clock-history"></i>
                                Return History
                            </div>
                        </div>
                        <div class="table-wrapper">
                            <table class="return-table">
                                <thead>
                                    <tr>
                                        <th>Employee</th>
                                        <th>Asset</th>
                                        <th>Returned Date</th>
                                        <th>Condition At Return</th>
                                        <th>Status</th>
                                        <th>Notes</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <asp:Repeater ID="rptrReturnHistory" runat="server">
                                        <ItemTemplate>
                                            <tr>
                                                <td>
                                                    <div class="employee-info">
                                                        <span class="employee-name">
                                                            <%# Eval("FirstName") %> <%# Eval("LastName") %>
                                                        </span>
                                                        <span class="employee-number">
                                                            <%# Eval("EmployeeNumber") %>
                                                        </span>
                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="asset-info">
                                                        <span class="asset-tag">
                                                            <%# Eval("AssetTag") %>
                                                        </span>
                                                        <span class="serial-number">
                                                            S/N: <%# Eval("SerialNumber") %>
                                                        </span>
                                                    </div>
                                                </td>
                                                <td><%# Eval("ReturnDate", "{0:dd MM yyyy}") %></td>
                                                <td>
                                                    <span class="condition-badge">
                                                        <%# Eval("ConditionAtReturn") %>
                                                    </span>
                                                </td>
                                                <td>
                                                    <span class="status-badge status-returned">
                                                        <%# Eval("Status") %>
                                                    </span>
                                                </td>
                                                <td><%# Eval("Notes") %></td>
                                            </tr>
                                        </ItemTemplate>
                                    </asp:Repeater>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </section>
            </main>
        </div>
    </form>
</body>
</html>