﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="LoginPage.aspx.cs" Inherits="Assets_Tracker.LoginPage" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title>IT Asset Management System</title>

    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" />

    <style type="text/css">
        /* General */
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background-color: #f5f8fc;
            color: #102a56;
        }

        /* MAIN PAGE */
        .page-container {
            display: flex;
            min-height: 100vh;
            width: 100%;
        }

        /* LEFT SIDE */
        .left-section {
            width: 52%;
            padding: 60px;
            background-color: #f5f8fc;
        }

        .welcome-container {
            padding: 0;
        }

        /* Logo */
        .logo {
            font-size: 24px;
            font-weight: bold;
            color: #102a56;
        }

        .logo-subtitle {
            font-size: 14px;
            letter-spacing: 1px;
            color: #102a56;
        }

        /* Welcome heading */
        .welcome-title {
            margin-top: 60px;
        }

        .welcome-title h1 {
            font-size: 42px;
            margin: 5px 0;
            color: #102a56;
        }

        .welcome-description {
            color: #5f6b7a;
            font-size: 17px;
            line-height: 1.6;
        }

        /* Features */
        .features {
            display: flex;
            flex-direction: column;
            gap: 20px;
            margin-top: 40px;
        }

        .feature-item {
            display: flex;
            align-items: center;
            gap: 20px;
        }

        .feature-icon {
            width: 60px;
            height: 60px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 15px;
            flex-shrink: 0;
        }

        .feature-icon i {
            font-size: 28px;
        }

        .feature-text h3 {
            margin: 0 0 5px 0;
            font-size: 18px;
            color: #102a56;
        }

        .feature-text p {
            margin: 0;
            color: #5f6b7a;
        }

        /* Feature colours */
        .asset-icon {
            background-color: #e8f1ff;
            color: #1557c0;
        }

        .employee-icon {
            background-color: #e8f8ef;
            color: #198754;
        }

        .document-icon {
            background-color: #fff3df;
            color: #e58a00;
        }

        .security-icon {
            background-color: #eee8ff;
            color: #6542c1;
        }

        /* Statistics */
        .statistics {
            display: flex;
            gap: 20px;
            margin-top: 50px;
            flex-wrap: wrap;
        }

        .stat-card {
            width: 200px;
            padding: 20px;
            display: flex;
            align-items: center;
            gap: 20px;
            background-color: white;
            border-radius: 15px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.08);
        }

        .stat-icon {
            width: 60px;
            height: 60px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 15px;
            background-color: #e8f1ff;
            color: #1557c0;
            flex-shrink: 0;
        }

        .stat-icon i {
            font-size: 30px;
        }

        .people-icon {
            background-color: #e8f8ef;
            color: #198754;
        }

        .document-stat-icon {
            background-color: #fff3df;
            color: #e58a00;
        }

        .stat-card p {
            margin: 0;
            color: #5f6b7a;
        }

        .stat-card h2 {
            margin: 5px 0 0 0;
            color: #102a56;
        }

        /* Right side */
        .right-section {
            width: 48%;
            min-height: 100vh;
            padding: 50px;
            background-color: #102a56;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            gap: 35px;
        }

        /* Dashboard Preview */
        .dashboard-preview {
            width: 90%;
            max-width: 600px;
            background-color: white;
            border-radius: 20px;
            overflow: hidden;
            box-shadow: 0 20px 50px rgba(0, 0, 0, 0.25);
        }

        /* Header */
        .preview-header {
            height: 45px;
            padding: 0 20px;
            background-color: #f5f7fa;
            display: flex;
            align-items: center;
            justify-content: space-between;
            font-size: 13px;
            font-weight: bold;
            color: #102a56;
        }

        .preview-dots {
            font-size: 8px;
            letter-spacing: 3px;
        }

        /* Preview content */
        .preview-content {
            display: flex;
            min-height: 250px;
        }

        /* Sidebar */
        .preview-sidebar {
            width: 60px;
            background-color: #102a56;
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 25px;
            padding-top: 25px;
        }

        .preview-sidebar i {
            color: white;
            font-size: 18px;
            opacity: 0.8;
        }

        /* Dashboard */
        .preview-dashboard {
            flex: 1;
            padding: 25px;
            background-color: #f8fafc;
        }

        .preview-dashboard h3 {
            margin: 0;
            color: #102a56;
        }

        /* Dashboard cards */
        .preview-cards {
            display: flex;
            gap: 15px;
            margin-top: 20px;
        }

        .preview-card {
            flex: 1;
            background-color: white;
            border-radius: 10px;
            padding: 15px;
            display: flex;
            align-items: center;
            gap: 12px;
            box-shadow: 0 3px 10px rgba(0, 0, 0, 0.05);
        }

        .preview-card i {
            font-size: 25px;
            color: #1557c0;
        }

        .preview-card small {
            display: block;
            color: #777;
        }

        .preview-card strong {
            font-size: 20px;
            color: #102a56;
        }

        /* Chart */
        .preview-chart {
            margin-top: 20px;
            padding: 15px;
            background-color: white;
            border-radius: 10px;
        }

        .chart-title {
            font-size: 13px;
            font-weight: bold;
            color: #102a56;
        }

        .chart-bars {
            height: 80px;
            margin-top: 15px;
            display: flex;
            align-items: flex-end;
            gap: 15px;
        }

        .chart-bars span {
            width: 30px;
            background-color: #1557c0;
            border-radius: 5px 5px 0 0;
        }

        /* Login card */
        .login-card {
            width: 90%;
            max-width: 500px;
            background-color: white;
            border-radius: 20px;
            padding: 35px;
            box-sizing: border-box;
            box-shadow: 0 15px 40px rgba(0, 0, 0, 0.2);
        }

        /* Login icon */
        .login-icon {
            width: 55px;
            height: 55px;
            border-radius: 15px;
            background-color: #e8f1ff;
            color: #1557c0;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .login-icon i {
            font-size: 25px;
        }

        .login-card h2 {
            margin: 20px 0 5px;
            color: #102a56;
        }

        .login-card > p {
            margin-top: 0;
            color: #6b7280;
        }

        /* Inputs */
        .input-group {
            margin-top: 20px;
        }

        .input-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
            font-size: 14px;
            color: #374151;
        }

        .input-wrapper {
            position: relative;
        }

        .input-wrapper i {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: #7a8699;
            z-index: 2;
        }

        .login-input {
            width: 100%;
            height: 45px;
            padding-left: 45px;
            padding-right: 15px;
            box-sizing: border-box;
            border: 1px solid #d9dee7;
            border-radius: 10px;
            outline: none;
            font-size: 14px;
        }

        .login-input:focus {
            border-color: #1557c0;
            box-shadow: 0 0 0 3px rgba(21, 87, 192, 0.1);
        }

        /* Login Options */
        .login-options {
            margin-top: 15px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-size: 13px;
        }

        .login-options a {
            color: #1557c0;
            text-decoration: none;
        }

        .login-options a:hover {
            text-decoration: underline;
        }

        /* Login button */
        .login-button {
            width: 100%;
            height: 48px;
            margin-top: 25px;
            border: none;
            border-radius: 10px;
            background-color: #1557c0;
            color: white;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
        }

        .login-button:hover {
            background-color: #10499f;
        }

        .error-message {
            display: block;
            margin-top: 15px;
            font-size: 13px;
        }

        /* Security message */
        .login-security {
            margin-top: 20px;
            text-align: center;
            font-size: 12px;
            color: #6b7280;
        }

        .login-security i {
            color: #198754;
            margin-right: 5px;
        }

        /* Responsive */
        @media (max-width: 1100px) {
            .page-container {
                flex-direction: column;
            }

            .left-section,
            .right-section {
                width: 100%;
            }

            .right-section {
                min-height: auto;
                padding: 40px 20px;
            }
        }

        @media (max-width: 600px) {
            .left-section {
                padding: 30px 20px;
            }

            .welcome-title h1 {
                font-size: 32px;
            }

            .statistics {
                flex-direction: column;
            }

            .stat-card {
                width: 100%;
            }

            .preview-cards {
                flex-direction: column;
            }

            .right-section {
                padding: 30px 15px;
            }
        }
    </style>
</head>

<body>
    <form id="form1" runat="server">
        <div class="page-container">

            <!-- Left Side -->
            <div class="left-section">
                <div class="welcome-container">

                    <!-- LOGO -->
                    <div class="logo">IT ASSET</div>
                    <div class="logo-subtitle">MANAGEMENT SYSTEM</div>

                    <!-- WELCOME -->
                    <div class="welcome-title">
                        <h1>Welcome to</h1>
                        <h1>IT Asset Management System</h1>
                        <p class="welcome-description">
                            A complete solution for tracking, managing, and<br />
                            securing your organization's IT assets.
                        </p>
                    </div>

                    <!-- Features -->
                    <div class="features">
                        <!-- Asset Tracking -->
                        <div class="feature-item">
                            <div class="feature-icon asset-icon">
                                <i class="bi bi-box-seam"></i>
                            </div>
                            <div class="feature-text">
                                <h3>Asset Tracking</h3>
                                <p>Track and manage all IT assets in real-time.</p>
                            </div>
                        </div>

                        <!-- Employee Management -->
                        <div class="feature-item">
                            <div class="feature-icon employee-icon">
                                <i class="bi bi-people"></i>
                            </div>
                            <div class="feature-text">
                                <h3>Employee Management</h3>
                                <p>Manage employees and their assigned assets.</p>
                            </div>
                        </div>

                        <!-- Document Generation -->
                        <div class="feature-item">
                            <div class="feature-icon document-icon">
                                <i class="bi bi-file-earmark-text"></i>
                            </div>
                            <div class="feature-text">
                                <h3>Document Generation</h3>
                                <p>Generate official forms and documents instantly.</p>
                            </div>
                        </div>

                        <!-- Secure & Reliable -->
                        <div class="feature-item">
                            <div class="feature-icon security-icon">
                                <i class="bi bi-shield-check"></i>
                            </div>
                            <div class="feature-text">
                                <h3>Secure &amp; Reliable</h3>
                                <p>Role-based access and enterprise-grade security.</p>
                            </div>
                        </div>
                    </div>

                    <!-- Statistics -->
                    <div class="statistics">
                        <!-- TOTAL ASSETS -->
                        <div class="stat-card">
                            <div class="stat-icon">
                                <i class="bi bi-laptop"></i>
                            </div>
                            <div>
                                <p>Total Assets</p>
                                <h2>342</h2>
                            </div>
                        </div>

                        <!-- USERS -->
                        <div class="stat-card">
                            <div class="stat-icon people-icon">
                                <i class="bi bi-people"></i>
                            </div>
                            <div>
                                <p>Users</p>
                                <h2>128</h2>
                            </div>
                        </div>

                        <!-- DOCUMENTS -->
                        <div class="stat-card">
                            <div class="stat-icon document-stat-icon">
                                <i class="bi bi-file-earmark-text"></i>
                            </div>
                            <div>
                                <p>Documents</p>
                                <h2>1,256</h2>
                            </div>
                        </div>
                    </div>

                </div>
            </div>

            <!-- Right Side -->
            <div class="right-section">

                <!-- Dashboard Preview -->
                <div class="dashboard-preview">
                    <div class="preview-header">
                        <span>IT Asset Management</span>
                        <div class="preview-dots">● ● ●</div>
                    </div>

                    <div class="preview-content">
                        <!-- Sidebar -->
                        <div class="preview-sidebar">
                            <i class="bi bi-grid"></i>
                            <i class="bi bi-laptop"></i>
                            <i class="bi bi-people"></i>
                            <i class="bi bi-file-earmark-text"></i>
                            <i class="bi bi-gear"></i>
                        </div>

                        <!-- Dashboard -->
                        <div class="preview-dashboard">
                            <h3>Dashboard</h3>
                            <div class="preview-cards">
                                <!-- Total Assets -->
                                <div class="preview-card">
                                    <i class="bi bi-laptop"></i>
                                    <div>
                                        <small>Total Assets</small>
                                        <strong>342</strong>
                                    </div>
                                </div>

                                <!-- Users -->
                                <div class="preview-card">
                                    <i class="bi bi-people"></i>
                                    <div>
                                        <small>Users</small>
                                        <strong>128</strong>
                                    </div>
                                </div>
                            </div>

                            <!-- Chart -->
                            <div class="preview-chart">
                                <div class="chart-title">Asset Overview</div>
                                <div class="chart-bars">
                                    <span style="height:45%;"></span>
                                    <span style="height:70%;"></span>
                                    <span style="height:55%;"></span>
                                    <span style="height:85%;"></span>
                                    <span style="height:65%;"></span>
                                    <span style="height:90%;"></span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Admin Login -->
                <div class="login-card">
                    <div class="login-icon">
                        <i class="bi bi-shield-lock"></i>
                    </div>

                    <h2>Administrator Login</h2>
                    <p>Sign in to access the IT Asset Management System</p>

                    <!-- Username -->
                    <div class="input-group">
                        <label>Username</label>
                        <div class="input-wrapper">
                            <i class="bi bi-person"></i>
                            <asp:TextBox
                                ID="txtUsername"
                                runat="server"
                                CssClass="login-input"
                                placeholder="Enter your email">
                            </asp:TextBox>
                        </div>
                    </div>

                    <!-- Password -->
                    <div class="input-group">
                        <label>Password</label>
                        <div class="input-wrapper">
                            <i class="bi bi-lock"></i>
                            <asp:TextBox
                                ID="txtPassword"
                                runat="server"
                                TextMode="Password"
                                CssClass="login-input"
                                placeholder="Enter your password">
                            </asp:TextBox>
                        </div>
                    </div>

                    <!-- Login Options -->
                    <div class="login-options">
                        <label>
                            <asp:CheckBox ID="chkRemember" runat="server" />
                            Remember me
                        </label>
                        <a href="#">Forgot Password?</a>
                    </div>

                    <!-- Error/Info Message Label -->
                    <asp:Label
                        ID="lblMessage"
                        runat="server"
                        CssClass="error-message"
                        ForeColor="Red"
                        EnableViewState="false" />

                    <!-- Login Button -->
                    <asp:Button
                        ID="btnLogin"
                        runat="server"
                        Text="Sign In"
                        CssClass="login-button"
                        OnClick="btnLogin_Click" />

                    <!-- Security Info -->
                    <div class="login-security">
                        <i class="bi bi-shield-check"></i> Secure administrator access
                    </div>
                </div>

            </div>

        </div>
    </form>
</body>
</html>