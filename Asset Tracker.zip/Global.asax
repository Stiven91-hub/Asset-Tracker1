﻿<%@ Application Codebehind="Global.asax.cs" Inherits="Assets_Tracker.Global" Language="C#" %>
