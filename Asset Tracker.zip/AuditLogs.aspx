﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="AuditLogs.aspx.cs" Inherits="Assets_Tracker.AuditLogs" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title>Audit Logs - IT Assets Management System</title>
    
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" />

    <style>
        /* ========== GENERAL RESET & VARIABLES ========== */
        *, *::before, *::after {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        :root {
            --primary-color: #2563eb;
            --primary-hover: #1d4ed8;
            --bg-main: #f8fafc;
            --sidebar-bg: linear-gradient(180deg, #075b4c 0%, #12375c 100%);
            --text-dark: #0f172a;
            --text-muted: #64748b;
            --border-color: #e2e8f0;
            --border-input: #cbd5e1;
        }

        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
            background-color: var(--bg-main);
            color: #1e293b;
            -webkit-font-smoothing: antialiased;
        }

        a {
            text-decoration: none;
            color: inherit;
        }

        /* ========== MAIN LAYOUT ========== */
        .dashboard-container {
            display: flex;
            min-height: 100vh;
        }

        /* ========== SIDEBAR ========== */
        .sidebar {
            width: 260px;
            background: var(--sidebar-bg);
            color: #ffffff;
            display: flex;
            flex-direction: column;
            position: fixed;
            height: 100vh;
            left: 0;
            top: 0;
            z-index: 100;
        }

        .logo {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 24px 20px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }

        .logo-icon {
            width: 42px;
            height: 42px;
            border: 2px solid rgba(255, 255, 255, 0.8);
            border-radius: 10px;
            display: flex;
            justify-content: center;
            align-items: center;
            font-size: 22px;
            flex-shrink: 0;
        }

        .logo-text {
            font-size: 15px;
            font-weight: 700;
            line-height: 1.2;
        }

        .logo-text span {
            display: block;
            font-size: 13px;
            font-weight: 400;
            opacity: 0.8;
        }

        .navigation {
            padding: 16px 12px;
            flex: 1;
            overflow-y: auto;
        }

        .nav-item {
            display: flex;
            align-items: center;
            gap: 14px;
            padding: 12px 16px;
            margin-bottom: 4px;
            color: rgba(255, 255, 255, 0.8);
            border-radius: 8px;
            font-size: 14.5px;
            font-weight: 500;
            transition: all 0.2s ease;
        }

        .nav-item i {
            font-size: 18px;
            width: 20px;
            text-align: center;
        }

        .nav-item:hover {
            background: rgba(255, 255, 255, 0.08);
            color: #ffffff;
        }

        .nav-item.active {
            background: var(--primary-color);
            color: #ffffff;
            box-shadow: 0 4px 12px rgba(37, 99, 235, 0.3);
        }

        .logout {
            padding: 16px 12px;
            border-top: 1px solid rgba(255, 255, 255, 0.1);
        }

        /* ========== MAIN CONTENT AREA ========== */
        .main-content {
            margin-left: 260px;
            width: calc(100% - 260px);
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }

        .topbar {
            height: 70px;
            background: #ffffff;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0 32px;
            border-bottom: 1px solid var(--border-color);
            position: sticky;
            top: 0;
            z-index: 90;
        }

        .topbar-left, .topbar-right {
            display: flex;
            align-items: center;
            gap: 20px;
        }

        .menu-button {
            font-size: 22px;
            color: var(--text-muted);
            cursor: pointer;
            display: flex;
            align-items: center;
        }

        .page-title {
            font-size: 18px;
            font-weight: 600;
            color: var(--text-dark);
        }

        .notifications {
            position: relative;
            font-size: 20px;
            color: var(--text-muted);
            cursor: pointer;
            display: flex;
            align-items: center;
        }

        .notification-badge {
            position: absolute;
            width: 8px;
            height: 8px;
            background: #ef4444;
            border-radius: 50%;
            right: 0;
            top: 2px;
            border: 2px solid #ffffff;
        }

        .profile {
            display: flex;
            align-items: center;
            gap: 10px;
            cursor: pointer;
        }

        .profile-icon {
            width: 38px;
            height: 38px;
            border-radius: 50%;
            background: #eff6ff;
            color: var(--primary-color);
            display: flex;
            justify-content: center;
            align-items: center;
            font-size: 18px;
        }

        .profile-info {
            display: flex;
            flex-direction: column;
        }

        .profile-info strong {
            color: #1e293b;
            font-size: 13.5px;
            font-weight: 600;
            line-height: 1.2;
        }

        .profile-info span {
            color: var(--text-muted);
            font-size: 12px;
        }

        .profile .bi-chevron-down {
            font-size: 12px;
            color: #94a3b8;
        }

        /* ========== CONTENT CONTAINER ========== */
        .content {
            padding: 32px;
            flex: 1;
        }

        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 24px;
        }

        .heading h1 {
            font-size: 24px;
            font-weight: 700;
            color: var(--text-dark);
            margin-bottom: 4px;
        }

        .heading p {
            color: var(--text-muted);
            font-size: 14px;
        }

        .refresh-button {
            border: none;
            background: var(--primary-color);
            color: #ffffff;
            padding: 10px 18px;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 500;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            box-shadow: 0 1px 2px rgba(0, 0, 0, 0.05);
            transition: background-color 0.2s ease;
        }

        .refresh-button:hover {
            background: var(--primary-hover);
        }

        /* ========== STATISTICS CARDS ========== */
        .audit-stats {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 20px;
            margin-bottom: 24px;
        }

        .stat-card {
            background: #ffffff;
            border: 1px solid var(--border-color);
            border-radius: 12px;
            padding: 20px;
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            transition: box-shadow 0.2s ease;
        }

        .stat-card:hover {
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.04);
        }

        .stat-icon {
            width: 44px;
            height: 44px;
            border-radius: 10px;
            display: flex;
            justify-content: center;
            align-items: center;
            font-size: 20px;
            margin-bottom: 12px;
        }

        .stat-card p {
            color: var(--text-muted);
            font-size: 13px;
            font-weight: 500;
            margin-bottom: 4px;
        }

        .stat-card h2 {
            font-size: 24px;
            font-weight: 700;
            color: var(--text-dark);
        }

        .total .stat-icon { background: #eff6ff; color: var(--primary-color); }
        .today .stat-icon { background: #f0fdf4; color: #16a34a; }
        .asset .stat-icon { background: #fffbeb; color: #d97706; }
        .user .stat-icon  { background: #faf5ff; color: #9333ea; }

        /* ========== PANELS ========== */
        .panel {
            background: #ffffff;
            border: 1px solid var(--border-color);
            border-radius: 12px;
            margin-bottom: 24px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.02);
        }

        .panel-header {
            padding: 16px 20px;
            border-bottom: 1px solid var(--border-color);
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 16px;
        }

        .panel-title {
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 16px;
            font-weight: 600;
            color: var(--text-dark);
        }

        .panel-title i {
            color: var(--primary-color);
            font-size: 18px;
        }

        /* ========== ACTIVITY TIMELINE ========== */
        .activity-list {
            padding: 8px 20px;
        }

        .activity-item {
            display: flex;
            align-items: center;
            gap: 16px;
            padding: 14px 0;
            border-bottom: 1px solid #f1f5f9;
        }

        .activity-item:last-child {
            border-bottom: none;
        }

        .activity-icon {
            width: 38px;
            height: 38px;
            border-radius: 8px;
            display: flex;
            justify-content: center;
            align-items: center;
            flex-shrink: 0;
            font-size: 16px;
        }

        .activity-icon.asset { background: #eff6ff; color: var(--primary-color); }
        .activity-icon.assignment { background: #f0fdf4; color: #16a34a; }
        .activity-icon.return { background: #fffbeb; color: #d97706; }
        .activity-icon.user { background: #faf5ff; color: #9333ea; }

        .activity-details {
            flex: 1;
        }

        .activity-details strong {
            display: block;
            color: #1e293b;
            font-size: 14px;
            font-weight: 600;
            margin-bottom: 2px;
        }

        .activity-details span {
            color: var(--text-muted);
            font-size: 13px;
        }

        .activity-time {
            color: #94a3b8;
            font-size: 12.5px;
            white-space: nowrap;
        }

        /* ========== FILTERS & CONTROLS ========== */
        .filter-container {
            display: flex;
            align-items: center;
            gap: 10px;
            flex-wrap: wrap;
        }

        .search-box {
            display: flex;
            align-items: center;
            border: 1px solid var(--border-input);
            border-radius: 6px;
            padding: 0 12px;
            height: 38px;
            background: #ffffff;
        }

        .search-box i {
            color: #94a3b8;
            margin-right: 8px;
            font-size: 14px;
        }

        .search-input {
            border: none !important;
            outline: none !important;
            width: 180px;
            font-size: 13.5px;
            color: #1e293b;
            background: transparent;
        }

        .filter-group .filter-input {
            height: 38px;
            border: 1px solid var(--border-input);
            border-radius: 6px;
            padding: 0 12px;
            font-size: 13.5px;
            outline: none;
            color: #475569;
        }

        .filter-select {
            height: 38px;
            border: 1px solid var(--border-input);
            border-radius: 6px;
            padding: 0 10px;
            background: #ffffff;
            color: #475569;
            font-size: 13.5px;
            outline: none;
            cursor: pointer;
        }

        .search-button {
            height: 38px;
            border: none;
            border-radius: 6px;
            padding: 0 16px;
            background: var(--primary-color);
            color: #ffffff;
            font-size: 13.5px;
            font-weight: 500;
            cursor: pointer;
            transition: background-color 0.2s ease;
        }

        .search-button:hover {
            background: var(--primary-hover);
        }

        /* ========== AUDIT TABLE ========== */
        .table-wrapper {
            overflow-x: auto;
        }

        .audit-table {
            width: 100%;
            border-collapse: collapse;
            text-align: left;
        }

        .audit-table th {
            background: #f8fafc;
            padding: 12px 20px;
            color: var(--text-muted);
            font-size: 12px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            border-bottom: 1px solid var(--border-color);
        }

        .audit-table td {
            padding: 14px 20px;
            border-bottom: 1px solid #f1f5f9;
            font-size: 13.5px;
            color: #334155;
            vertical-align: middle;
        }

        .audit-table tr:hover td {
            background-color: #f8fafc;
        }

        /* BADGES */
        .activity-badge {
            display: inline-block;
            padding: 4px 10px;
            border-radius: 12px;
            font-size: 12px;
            font-weight: 500;
        }

        .badge-blue { background: #eff6ff; color: var(--primary-color); }
        .badge-green { background: #f0fdf4; color: #16a34a; }
        .badge-orange { background: #fffbeb; color: #d97706; }
        .badge-purple { background: #faf5ff; color: #9333ea; }

        .module-badge {
            display: inline-block;
            background: #f1f5f9;
            color: #475569;
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 12px;
            font-weight: 500;
        }

        /* STATUS INDICATOR */
        .status-success {
            color: #16a34a;
            font-weight: 500;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            font-size: 13px;
        }

        .status-failed {
            color: #dc2626;
            font-weight: 500;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            font-size: 13px;
        }

        /* ========== PAGINATION ========== */
        .pagination {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 14px 20px;
            border-top: 1px solid var(--border-color);
        }

        .pagination-info {
            color: var(--text-muted);
            font-size: 13px;
        }

        .pagination-buttons {
            display: flex;
            gap: 4px;
        }

        .page-button {
            min-width: 32px;
            height: 32px;
            padding: 0 6px;
            border: 1px solid var(--border-input);
            background: #ffffff;
            border-radius: 6px;
            cursor: pointer;
            color: #475569;
            font-size: 13px;
            display: flex;
            justify-content: center;
            align-items: center;
            transition: all 0.2s ease;
        }

        .page-button:hover {
            background: #f1f5f9;
        }

        .page-button.active {
            background: var(--primary-color);
            color: #ffffff;
            border-color: var(--primary-color);
        }

        /* ========== FOOTER ========== */
        .footer {
            text-align: center;
            color: #94a3b8;
            font-size: 13px;
            padding: 20px 0;
            margin-top: auto;
        }

        /* ========== RESPONSIVE DESIGN ========== */
        @media (max-width: 1200px) {
            .audit-stats {
                grid-template-columns: repeat(2, 1fr);
            }
        }

        @media (max-width: 768px) {
            .sidebar {
                width: 70px;
            }

            .logo-text,
            .nav-item span {
                display: none;
            }

            .main-content {
                margin-left: 70px;
                width: calc(100% - 70px);
            }

            .content {
                padding: 16px;
            }

            .audit-stats {
                grid-template-columns: 1fr;
            }

            .panel-header {
                flex-direction: column;
                align-items: flex-start;
            }

            .filter-container {
                width: 100%;
                flex-direction: column;
                align-items: stretch;
            }

            .search-box, .filter-group, .filter-select, .search-button {
                width: 100%;
            }

            .search-input {
                width: 100%;
            }
        }
    </style>
</head>

<body>
    <form id="form1" runat="server">
        <div class="dashboard-container">
            <!-- ===========SIDEBAR=============== -->
            <aside class="sidebar">
                <div class="logo">
                    <div class="logo-icon">
                        <i class="bi bi-display"></i>
                    </div>
                    <div class="logo-text">
                        IT Assets Management
                        <span>System</span>
                    </div>
                </div>
                <!-- NAVIGATION -->
                <nav class="navigation">
                    <a href="Dashboard.aspx" class="nav-item">
                        <i class="bi bi-grid"></i>
                        <span>Dashboard</span>
                    </a>
                    <a href="Users.aspx" class="nav-item">
                        <i class="bi bi-person"></i>
                        <span>Users</span>
                    </a>
                    <a href="Assets.aspx" class="nav-item">
                        <i class="bi bi-laptop"></i>
                        <span>Assets</span>
                    </a>
                    <a href="AssetAssignments.aspx" class="nav-item">
                        <i class="bi bi-person-check"></i>
                        <span>Asset Assignments</span>
                    </a>
                    <a href="Returns.aspx" class="nav-item">
                        <i class="bi bi-arrow-return-left"></i>
                        <span>Returns</span>
                    </a>
                    <a href="Documents.aspx" class="nav-item">
                        <i class="bi bi-file-earmark-text"></i>
                        <span>Documents</span>
                    </a>
                    <a href="Reports.aspx" class="nav-item">
                        <i class="bi bi-bar-chart"></i>
                        <span>Reports</span>
                    </a>
                    <a href="AuditLogs.aspx" class="nav-item active">
                        <i class="bi bi-shield-check"></i>
                        <span>Audit Logs</span>
                    </a>
                    <a href="ImportData.aspx" class="nav-item">
                        <i class="bi bi-upload"></i>
                        <span>Import Data</span>
                    </a>
                </nav>
                <!-- LOGOUT -->
                <div class="logout">
                    <a href="Login.aspx" class="nav-item">
                        <i class="bi bi-box-arrow-left"></i>
                        <span>Logout</span>
                    </a>
                </div>
            </aside>

            <!-- ===============MAIN CONTENT================ -->
            <main class="main-content">
                <!-- TOPBAR -->
                <header class="topbar">
                    <div class="topbar-left">
                        <div class="menu-button">
                            <i class="bi bi-list"></i>
                        </div>
                        <div class="page-title">Audit Logs</div>
                    </div>
                    <div class="topbar-right">
                        <div class="profile">
                            <div class="profile-icon">
                                <i class="bi bi-person-fill"></i>
                            </div>
                            <div class="profile-info">
                                <strong>
                                    <asp:Label ID="lblAdminName" runat="server" Text="Administrator"></asp:Label>
                                </strong>
                                <span>
                                    <asp:Label ID="lblAdminRole" runat="server" Text="IT Administrator"></asp:Label>
                                </span>
                            </div>
                            <i class="bi bi-chevron-down"></i>
                        </div>
                    </div>
                </header>

                <!-- ===============CONTENT============== -->
                <section class="content">
                    <!-- PAGE HEADER -->
                    <div class="page-header">
                        <div class="heading">
                            <h1>Audit Logs</h1>
                            <p>Monitor and track all activities within the IT Assets Management System.</p>
                        </div>
                        <asp:Button ID="btnRefresh" runat="server" Text="↻ Refresh Logs" CssClass="refresh-button" OnClick="btnRefresh_Click" />
                    </div>

                    <!-- ==============STAT=============== -->
                    <div class="audit-stats">
                        <div class="stat-card total">
                            <div class="stat-icon"><i class="bi bi-journal-text"></i></div>
                            <p>Total Activities</p>
                            <h2><asp:Label ID="lblTotalActivities" runat="server" Text="0"></asp:Label></h2>
                        </div>
                        <div class="stat-card today">
                            <div class="stat-icon"><i class="bi bi-calendar-check"></i></div>
                            <p>Today's Activities</p>
                            <h2><asp:Label ID="lblTodayActivities" runat="server" Text="0"></asp:Label></h2>
                        </div>
                        <div class="stat-card asset">
                            <div class="stat-icon"><i class="bi bi-laptop"></i></div>
                            <p>Asset Activities</p>
                            <h2><asp:Label ID="lblAssetActivities" runat="server" Text="0"></asp:Label></h2>
                        </div>
                        <div class="stat-card user">
                            <div class="stat-icon"><i class="bi bi-people"></i></div>
                            <p>User Activities</p>
                            <h2><asp:Label ID="lblUserActivities" runat="server" Text="0"></asp:Label></h2>
                        </div>
                    </div>

                    <!-- ===============RECENT ACTIVITY================ -->
                    <div class="panel">
                        <div class="panel-header">
                            <div class="panel-title">
                                <i class="bi bi-activity"></i>
                                Recent System Activity
                            </div>
                        </div>
                        <div class="activity-list">
                            <asp:Repeater ID="rptRecentActivity" runat="server">
                                <ItemTemplate>
                                    <div class="activity-item">
                                        <div class="activity-icon asset">
                                            <i class="bi bi-clock-history"></i>
                                        </div>
                                        <div class="activity-details">
                                            <strong><%# Eval("Activity") %></strong>
                                            <span><%# Eval("Description") %></span>
                                        </div>
                                        <div class="activity-time">
                                            <%# Eval("ActivityDate", "{0:dd MM yyyy HH:mm}") %>
                                        </div>
                                    </div>
                                </ItemTemplate>
                            </asp:Repeater>
                        </div>
                    </div>

                    <!-- ===============AUDIT LOG TABLE============== -->
                    <div class="panel">
                        <div class="panel-header">
                            <div class="panel-title">
                                <i class="bi bi-shield-check"></i>
                                Audit Log History
                            </div>
                            <div class="filter-container">
                                <div class="search-box">
                                    <i class="bi bi-search"></i>
                                    <asp:TextBox ID="txtSearch" runat="server" CssClass="search-input" placeholder="Search audit logs..."></asp:TextBox>
                                </div>
                                <div class="filter-group">
                                    <asp:TextBox ID="txtDateRange" runat="server" CssClass="filter-input" placeholder="Select date range"></asp:TextBox>
                                </div>
                                <asp:DropDownList ID="ddlActivity" runat="server" CssClass="filter-select">
                                    <asp:ListItem Text="All Activities" Value=""></asp:ListItem>
                                    <asp:ListItem Text="Asset Added" Value="Asset Added"></asp:ListItem>
                                    <asp:ListItem Text="Asset Updated" Value="Asset Updated"></asp:ListItem>
                                    <asp:ListItem Text="Asset Assigned" Value="Asset Assigned"></asp:ListItem>
                                    <asp:ListItem Text="Asset Returned" Value="Asset Returned"></asp:ListItem>
                                    <asp:ListItem Text="Employee Added" Value="Employee Added"></asp:ListItem>
                                    <asp:ListItem Text="Login" Value="Login"></asp:ListItem>
                                    <asp:ListItem Text="Logout" Value="Logout"></asp:ListItem>
                                </asp:DropDownList>
                                <asp:DropDownList ID="ddlModule" runat="server" CssClass="filter-select">
                                    <asp:ListItem Text="All Modules" Value=""></asp:ListItem>
                                    <asp:ListItem Text="Users" Value="Users"></asp:ListItem>
                                    <asp:ListItem Text="Assets" Value="Assets"></asp:ListItem>
                                    <asp:ListItem Text="Asset Assignments" Value="Asset Assignments"></asp:ListItem>
                                    <asp:ListItem Text="Returns" Value="Returns"></asp:ListItem>
                                    <asp:ListItem Text="Documents" Value="Documents"></asp:ListItem>
                                    <asp:ListItem Text="Authentication" Value="Authentication"></asp:ListItem>
                                </asp:DropDownList>
                                <asp:Button ID="btnSearch" runat="server" Text="Search" CssClass="search-button" OnClick="btnSearch_Click" />
                            </div>
                        </div>

                        <!-- TABLE -->
                        <div class="table-wrapper">
                            <table class="audit-table">
                                <thead>
                                    <tr>
                                        <th>Date & Time</th>
                                        <th>Administrator</th>
                                        <th>Activity</th>
                                        <th>Module</th>
                                        <th>Description</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <asp:Repeater ID="rptAuditLogs" runat="server">
                                        <ItemTemplate>
                                            <tr>
                                                <td><%# Eval("ActivityDate", "{0:dd MM yyyy HH:mm}") %></td>
                                                <td><%# Eval("AdministratorName") %></td>
                                                <td>
                                                    <span class="activity-badge badge-blue"><%# Eval("Activity") %></span>
                                                </td>
                                                <td>
                                                    <span class="module-badge"><%# Eval("Module") %></span>
                                                </td>
                                                <td><%# Eval("Description") %></td>
                                                <td>
                                                    <span class="status-success">
                                                        <i class="bi bi-check-circle-fill"></i>
                                                        <%# Eval("Status") %>
                                                    </span>
                                                </td>
                                            </tr>
                                        </ItemTemplate>
                                    </asp:Repeater>
                                </tbody>
                            </table>
                        </div>

                        <!-- PAGINATION -->
                        <div class="pagination">
                            <div class="pagination-info">Showing recent audit activities</div>
                            <div class="pagination-buttons">
                                <button type="button" class="page-button"><i class="bi bi-chevron-left"></i></button>
                                <button type="button" class="page-button active">1</button>
                                <button type="button" class="page-button">2</button>
                                <button type="button" class="page-button">3</button>
                                <button type="button" class="page-button"><i class="bi bi-chevron-right"></i></button>
                            </div>
                        </div>
                    </div>

                    <footer class="footer">
                        &copy; 2026 IT Assets Management System. All rights reserved by S.N Nkuna.
                    </footer>
                </section>
            </main>
        </div>
    </form>
</body>
</html>