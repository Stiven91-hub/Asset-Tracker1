﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="EditAssignment.aspx.cs" Inherits="Assets_Tracker.EditAssignment" %>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title>Edit Assignment - IT Asset Management System</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet" />
    <style>
        * {
            box-sizing: border-box;
        }
        body {
            margin: 0;
            font-family: Arial, Helvetica, sans-serif;
            background: #f4f6fb;
            color: #1f2937;
        }
        .sidebar {
            position: fixed;
            left: 0;
            top: 0;
            width: 260px;
            height: 100vh;
            background: linear-gradient(180deg, #0f5c4d 0%, #123a5c 100%);
            color: white;
            padding: 25px 15px;
            overflow-y: auto;
        }
        .logo {
            text-align: center;
            padding: 10px 5px 30px;
            border-bottom: 1px solid rgba(255,255,255,0.15);
            margin-bottom: 20px;
        }
        .logo i {
            font-size: 35px;
            display: block;
            margin-bottom: 10px;
        }
        .logo h2 {
            font-size: 18px;
            margin: 0;
            line-height: 1.4;
        }
        .nav-menu {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        .nav-menu li {
            margin-bottom: 7px;
        }
        .nav-menu a {
            display: flex;
            align-items: center;
            gap: 13px;
            color: white;
            text-decoration: none;
            padding: 13px 15px;
            border-radius: 8px;
            font-size: 14px;
            transition: 0.2s;
        }
        .nav-menu a:hover {
            background: rgba(255,255,255,0.12);
        }
        .nav-menu a.active {
            background: linear-gradient(90deg, #2563c7, #3f7bd7);
        }
        .nav-menu i {
            font-size: 18px;
        }
        .main {
            margin-left: 260px;
            min-height: 100vh;
        }
        .topbar {
            height: 75px;
            background: white;
            border-bottom: 1px solid #e5e7eb;
            display: flex;
            justify-content: flex-end;
            align-items: center;
            padding: 0 30px;
        }
        .admin-info {
            display: flex;
            align-items: center;
            gap: 12px;
        }
        .admin-icon {
            width: 42px;
            height: 42px;
            border-radius: 50%;
            background: #2563c7;
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 19px;
        }
        .admin-details {
            text-align: right;
        }
        .admin-name {
            display: block;
            font-size: 14px;
            font-weight: 600;
            color: #1f2937;
        }
        .admin-role {
            display: block;
            font-size: 12px;
            color: #6b7280;
            margin-top: 3px;
        }
        .content {
            padding: 30px;
            max-width: 1200px;
        }
        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
        }
        .page-header h1 {
            margin: 0;
            font-size: 27px;
            color: #1f2937;
        }
        .page-header p {
            margin: 7px 0 0;
            color: #6b7280;
            font-size: 14px;
        }
        .header-icon {
            width: 50px;
            height: 50px;
            background: #eaf1ff;
            color: #2563c7;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
        }
        .message {
            display: block;
            margin-bottom: 20px;
            padding: 12px 15px;
            border-radius: 7px;
            font-size: 14px;
        }
        .form-card {
            background: white;
            border-radius: 12px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.06);
            padding: 28px;
            margin-bottom: 20px;
        }
        .card-title {
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 18px;
            font-weight: 600;
            color: #1f2937;
            margin-bottom: 22px;
            padding-bottom: 15px;
            border-bottom: 1px solid #e5e7eb;
        }
        .card-title i {
            color: #2563c7;
            font-size: 20px;
        }
        .form-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 20px 25px;
        }
        .form-group {
            display: flex;
            flex-direction: column;
        }
        .form-group.full-width {
            grid-column: 1 / -1;
        }
        .form-label {
            font-size: 13px;
            font-weight: 600;
            color: #374151;
            margin-bottom: 8px;
        }
        .required {
            color: #dc2626;
        }
        .form-control {
            width: 100%;
            height: 43px;
            border: 1px solid #d1d5db;
            border-radius: 7px;
            padding: 0 12px;
            font-size: 14px;
            color: #1f2937;
            background: white;
            outline: none;
            transition: 0.2s;
        }
        .form-control:focus {
            border-color: #2563c7;
            box-shadow: 0 0 0 3px rgba(37,99,199,0.10);
        }
        .form-control[readonly] {
            background: #f3f4f6;
            color: #6b7280;
            cursor: not-allowed;
        }
        textarea.form-control {
            height: 120px;
            padding-top: 11px;
            resize: vertical;
        }
        select.form-control {
            cursor: pointer;
        }
        .help-text {
            font-size: 12px;
            color: #6b7280;
            margin-top: 6px;
        }
        .info-box {
            background: #eff6ff;
            border: 1px solid #bfdbfe;
            color: #1e40af;
            padding: 13px 15px;
            border-radius: 8px;
            font-size: 13px;
            line-height: 1.5;
            margin-bottom: 20px;
        }
        .button-row {
            display: flex;
            justify-content: flex-end;
            gap: 12px;
            margin-top: 25px;
        }
        .btn {
            border: none;
            border-radius: 7px;
            padding: 11px 20px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            min-width: 130px;
        }
        .btn-primary {
            background: #2563c7;
            color: white;
        }
        .btn-primary:hover {
            background: #1d4fa3;
        }
        .btn-secondary {
            background: #e5e7eb;
            color: #374151;
        }
        .btn-secondary:hover {
            background: #d1d5db;
        }
        .section-description {
            color: #6b7280;
            font-size: 13px;
            margin: -10px 0 20px;
        }
        @media (max-width: 900px) {
            .sidebar {
                width: 220px;
            }
            .main {
                margin-left: 220px;
            }
            .form-grid {
                grid-template-columns: 1fr;
            }
            .form-group.full-width {
                grid-column: auto;
            }
        }
        @media (max-width: 700px) {
            .sidebar {
                display: none;
            }
            .main {
                margin-left: 0;
            }
            .content {
                padding: 20px;
            }
            .button-row {
                flex-direction: column-reverse;
            }
            .btn {
                width: 100%;
            }
        }
    </style>
</head>
<body>
    <form id="form1" runat="server">
        <!-- SIDEBAR -->
        <aside class="sidebar">
            <div class="logo">
                <i class="bi bi-pc-display"></i>
                <h2>IT Assets Management System</h2>
            </div>
            <ul class="nav-menu">
                <li>
                             <a href="Dashboard.aspx">
                        <i class="bi bi-grid"></i>
                        <span>Dashboard</span>
                    </a>
                </li>
                <li>
                    <a href="Users.aspx">
                        <i class="bi bi-people"></i>
                        <span>Employees</span>
                    </a>
                </li>
                <li>
                    <a href="Assets.aspx">
                        <i class="bi bi-laptop"></i>
                        <span>Assets</span>
                    </a>
                </li>
                <li>
                    <a href="AssetAssignments.aspx">
                        <i class="bi bi-person-check"></i>
                        <span>Assignments</span>
                    </a>
                </li>
                <li>
                    <a href="Returns.aspx" class="active">
                        <i class="bi bi-arrow-return-left"></i>
                        <span>Returns</span>
                    </a>
                </li>
                <li>
                    <a href="Documents.aspx">
                        <i class="bi bi-file-earmark-text"></i>
                        <span>Documents</span>
                    </a>
                </li>
                <li>
                    <a href="Reports.aspx">
                        <i class="bi bi-bar-chart"></i>
                        <span>Reports</span>
                    </a>
                </li>
                <li>
                    <a href="AuditLogs.aspx">
                        <i class="bi bi-shield-check"></i>
                        <span>Audit Logs</span>
                    </a>
                </li>
            </ul>
        </aside>
        <!-- MAIN -->
        <main class="main">
            <!-- TOPBAR -->
            <div class="topbar">
                <div class="admin-info">
                    <div class="admin-details">
                        <asp:Label
                            ID="lblAdminName"
                            runat="server"
                            CssClass="admin-name">
                        </asp:Label>
                        <asp:Label
                            ID="lblAdminRole"
                            runat="server"
                            CssClass="admin-role">
                        </asp:Label>
                    </div>
                    <div class="admin-icon">
                        <i class="bi bi-person-fill"></i>
                    </div>
                </div>
            </div>
            <!-- CONTENT -->
            <div class="content">
                <div class="page-header">
                    <div>
                        <h1>Edit Assignment</h1>
                        <p>Update the information recorded for this asset assignment.</p>
                    </div>
                    <div class="header-icon">
                        <i class="bi bi-pencil-square"></i>
                    </div>
                </div>
                <asp:Label
                    ID="lblMessage"
                    runat="server"
                    CssClass="message">
                </asp:Label>
                <div class="info-box">
                    <i class="bi bi-info-circle"></i>
                    You are editing assignment
                    <strong>#<asp:Label ID="lblAssignmentNumber" runat="server"></asp:Label></strong>.
                    Assignment history is retained in the system for tracking and auditing purposes.
                </div>
                <!-- ASSIGNMENT INFORMATION -->
                <div class="form-card">
                    <div class="card-title">
                        <i class="bi bi-clipboard-data"></i>
                        Assignment Information
                    </div>
                    <p class="section-description">
                        Update the employee, asset and allocation information.
                    </p>
                    <div class="form-grid">
                        <div class="form-group">
                            <label class="form-label">
                                Assignment ID
                            </label>
                            <asp:TextBox
                                ID="txtAllocationID"
                                runat="server"
                                CssClass="form-control"
                                ReadOnly="true">
                            </asp:TextBox>
                            <span class="help-text">
                                The assignment ID cannot be changed.
                            </span>
                        </div>
                        <div class="form-group">
                            <label class="form-label">
                                Employee <span class="required">*</span>
                            </label>
                            <asp:DropDownList
                                ID="ddlEmployee"
                                runat="server"
                                CssClass="form-control"
                                AutoPostBack="true"
                                OnSelectedIndexChanged="ddlEmployee_SelectedIndexChanged">
                            </asp:DropDownList>
                        </div>
                        <div class="form-group">
                            <label class="form-label">
                                Asset <span class="required">*</span>
                            </label>
                            <asp:DropDownList
                                ID="ddlAsset"
                                runat="server"
                                CssClass="form-control"
                                AutoPostBack="true"
                                OnSelectedIndexChanged="ddlAsset_SelectedIndexChanged">
                            </asp:DropDownList>
                        </div>
                        <div class="form-group">
                            <label class="form-label">
                                Allocation Date <span class="required">*</span>
                            </label>
                            <asp:TextBox
                                ID="txtAllocationDate"
                                runat="server"
                                CssClass="form-control"
                                TextMode="Date">
                            </asp:TextBox>
                        </div>
                        <div class="form-group">
                            <label class="form-label">
                                Status <span class="required">*</span>
                            </label>
                            <asp:DropDownList
                                ID="ddlStatus"
                                runat="server"
                                CssClass="form-control">
                                <asp:ListItem Text="Select Status" Value=""></asp:ListItem>
                                <asp:ListItem Text="Active" Value="Active"></asp:ListItem>
                                <asp:ListItem Text="Returned" Value="Returned"></asp:ListItem>
                                <asp:ListItem Text="Lost" Value="Lost"></asp:ListItem>
                                <asp:ListItem Text="Damaged" Value="Damaged"></asp:ListItem>
                                <asp:ListItem Text="Cancelled" Value="Cancelled"></asp:ListItem>
                            </asp:DropDownList>
                        </div>
                        <div class="form-group">
                            <label class="form-label">
                                Condition at Issue <span class="required">*</span>
                            </label>
                            <asp:DropDownList
                                ID="ddlConditionAtIssue"
                                runat="server"
                                CssClass="form-control">
                                <asp:ListItem Text="Select Condition" Value=""></asp:ListItem>
                                <asp:ListItem Text="New" Value="New"></asp:ListItem>
                                <asp:ListItem Text="Good" Value="Good"></asp:ListItem>
                                <asp:ListItem Text="Fair" Value="Fair"></asp:ListItem>
                                <asp:ListItem Text="Poor" Value="Poor"></asp:ListItem>
                            </asp:DropDownList>
                        </div>
                    </div>
                </div>
                <!-- RETURN INFORMATION -->
                <div class="form-card">
                    <div class="card-title">
                        <i class="bi bi-box-arrow-in-left"></i>
                        Return Information
                    </div>
                    <p class="section-description">
                        Complete these fields only when the asset has been returned.
                    </p>
                    <div class="form-grid">
                        <div class="form-group">
                            <label class="form-label">
                                Return Date
                            </label>
                            <asp:TextBox
                                ID="txtReturnDate"
                                runat="server"
                                CssClass="form-control"
                                TextMode="Date">
                            </asp:TextBox>
                            <span class="help-text">
                                Leave blank if the asset has not been returned.
                            </span>
                        </div>
                        <div class="form-group">
                            <label class="form-label">
                                Condition at Return
                            </label>
                            <asp:DropDownList
                                ID="ddlConditionAtReturn"
                                runat="server"
                                CssClass="form-control">
                                <asp:ListItem Text="Not Returned" Value=""></asp:ListItem>
                                <asp:ListItem Text="New" Value="New"></asp:ListItem>
                                <asp:ListItem Text="Good" Value="Good"></asp:ListItem>
                                <asp:ListItem Text="Fair" Value="Fair"></asp:ListItem>
                                <asp:ListItem Text="Poor" Value="Poor"></asp:ListItem>
                                <asp:ListItem Text="Under Maintenance" Value="Under Maintenance"></asp:ListItem>
                            </asp:DropDownList>
                        </div>
                    </div>
                </div>
                <!-- NOTES -->
                <div class="form-card">
                    <div class="card-title">
                        <i class="bi bi-journal-text"></i>
                        Assignment Notes
                    </div>
                    <div class="form-group full-width">
                        <label class="form-label">
                            Notes
                        </label>
                        <asp:TextBox
                            ID="txtNotes"
                            runat="server"
                            CssClass="form-control"
                            TextMode="MultiLine"
                            MaxLength="500">
                        </asp:TextBox>
                        <span class="help-text">
                            Maximum 500 characters.
                        </span>
                    </div>
                </div>
                <!-- BUTTONS -->
                <div class="button-row">
                    <asp:Button
                        ID="btnCancel"
                        runat="server"
                        Text="Cancel"
                        CssClass="btn btn-secondary"
                        OnClick="btnCancel_Click" />
                    <asp:Button
                        ID="btnUpdate"
                        runat="server"
                        Text="Update Assignment"
                        CssClass="btn btn-primary"
                        OnClick="btnUpdate_Click"
                        OnClientClick="return confirm('Are you sure you want to update this assignment?');" />
                </div>
            </div>
        </main>
    </form>
</body>
</html>