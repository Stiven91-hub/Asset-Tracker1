﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="AddEmployee.aspx.cs" Inherits="Assets_Tracker.AddEmployee" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title>Add Employee - IT Assets Management System</title>
    <link rel="stylesheet"
        href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" />
    <style>
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }

        body {
            background: #f4f7fb;
            color: #1f2937;
        }

        /* ================= SIDEBAR ================= */

        .dashboard-container {
            display: flex;
            min-height: 100vh;
        }

        .sidebar {
            width: 260px;
            background: linear-gradient(180deg, #0f172a, #1e293b);
            color: white;
            display: flex;
            flex-direction: column;
            position: fixed;
            height: 100vh;
            left: 0;
            top: 0;
        }

        .logo {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 25px 20px;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }

        .logo-icon {
            width: 42px;
            height: 42px;
            background: #2563eb;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 22px;
        }

        .logo-text {
            font-size: 15px;
            font-weight: bold;
        }

        .logo-text span {
            display: block;
            font-size: 12px;
            color: #94a3b8;
            margin-top: 3px;
        }

        .navigation {
            padding: 20px 12px;
            flex: 1;
        }

        .nav-item {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 13px 15px;
            margin-bottom: 5px;
            border-radius: 8px;
            text-decoration: none;
            color: #cbd5e1;
            transition: 0.3s;
        }

        .nav-item:hover {
            background: rgba(255,255,255,0.08);
            color: white;
        }

        .nav-item.active {
            background: #2563eb;
            color: white;
        }

        .nav-item i {
            font-size: 18px;
        }

        .logout {
            padding: 15px;
            border-top: 1px solid rgba(255,255,255,0.1);
        }


        /* ================= MAIN CONTENT ================= */

        .main-content {
            margin-left: 260px;
            width: calc(100% - 260px);
            min-height: 100vh;
        }


        /* ================= TOPBAR ================= */

        .topbar {
            height: 75px;
            background: white;
            border-bottom: 1px solid #e5e7eb;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 35px;
        }

        .topbar-left {
            display: flex;
            align-items: center;
            gap: 20px;
        }

        .menu-button {
            font-size: 25px;
            color: #475569;
        }

        .page-title {
            font-size: 20px;
            font-weight: 600;
        }

        .topbar-right {
            display: flex;
            align-items: center;
            gap: 25px;
        }

        .notifications {
            position: relative;
            font-size: 21px;
            color: #64748b;
        }

        .notification-badge {
            position: absolute;
            width: 8px;
            height: 8px;
            background: #ef4444;
            border-radius: 50%;
            top: 0;
            right: -3px;
        }

        .profile {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .profile-icon {
            width: 40px;
            height: 40px;
            background: #dbeafe;
            color: #2563eb;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .profile-info strong {
            display: block;
            font-size: 14px;
        }

        .profile-info span {
            display: block;
            font-size: 12px;
            color: #64748b;
        }


        /* ================= CONTENT ================= */

        .content {
            padding: 35px;
        }

        .page-header {
            margin-bottom: 25px;
        }

        .page-header h1 {
            font-size: 28px;
            margin-bottom: 7px;
        }

        .page-header p {
            color: #64748b;
        }


        /* ================= FORM CARD ================= */

        .form-card {
            background: white;
            border-radius: 14px;
            padding: 30px;
            max-width: 900px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.06);
        }

        .form-card-header {
            display: flex;
            align-items: center;
            gap: 12px;
            padding-bottom: 20px;
            border-bottom: 1px solid #e5e7eb;
            margin-bottom: 25px;
        }

        .form-card-header i {
            font-size: 24px;
            color: #2563eb;
        }

        .form-card-header h2 {
            font-size: 20px;
        }


        /* ================= FORM ================= */

        .form-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 20px;
        }

        .form-group {
            display: flex;
            flex-direction: column;
        }

        .form-group.full-width {
            grid-column: span 2;
        }

        .form-group label {
            font-size: 14px;
            font-weight: 600;
            margin-bottom: 8px;
            color: #374151;
        }

        .form-control {
            width: 100%;
            padding: 12px 14px;
            border: 1px solid #d1d5db;
            border-radius: 8px;
            font-size: 14px;
            outline: none;
            transition: 0.2s;
        }

        .form-control:focus {
            border-color: #2563eb;
            box-shadow: 0 0 0 3px rgba(37,99,235,0.1);
        }


        /* ================= BUTTONS ================= */

        .form-actions {
            display: flex;
            justify-content: flex-end;
            gap: 12px;
            margin-top: 30px;
            padding-top: 20px;
            border-top: 1px solid #e5e7eb;
        }

        .cancel-button {
            padding: 11px 20px;
            background: #f1f5f9;
            color: #475569;
            text-decoration: none;
            border-radius: 8px;
            font-weight: 500;
        }

        .cancel-button:hover {
            background: #e2e8f0;
        }

        .save-button {
            border: none;
            background: #2563eb;
            color: white;
            padding: 11px 22px;
            border-radius: 8px;
            cursor: pointer;
            font-size: 14px;
            font-weight: 500;
        }

        .save-button:hover {
            background: #1d4ed8;
        }


        /* ================= MESSAGE ================= */

        .message {
            display: block;
            margin-bottom: 20px;
            padding: 12px 15px;
            border-radius: 8px;
            font-size: 14px;
        }

        .success-message {
            background: #dcfce7;
            color: #166534;
        }

        .error-message {
            background: #fee2e2;
            color: #991b1b;
        }


        /* ================= RESPONSIVE ================= */

        @media(max-width: 900px) {

            .sidebar {
                width: 220px;
            }

            .main-content {
                margin-left: 220px;
                width: calc(100% - 220px);
            }

            .form-grid {
                grid-template-columns: 1fr;
            }

            .form-group.full-width {
                grid-column: span 1;
            }
        }
    </style>
</head>
<body>
    <form id="form1" runat="server">
        <div class="dashboard-container">
            <!--===========SIDEBAR=======-->
            <aside class="sidebar">
                <div class="logo">
                    <div class="logo-icon">
                        <i class="bg-info bi-display"></i>
                    </div>
                    <div class="logo-text">
                        IT Assets Management
                        <span>System</span>
                    </div>
                </div>
                <!--Navigation-->
                <nav class="navigation">
                    <a href="Dashboard.aspx"
                        class="nav-item">
                        <i class="bi bi-grid"></i>Dashboard
                    </a>
                    <a href="Users.aspx"
                        class="nav-item">
                        <i class="bi bi-person"></i>Users
                    </a>
                    <a href="Assets.aspx"
                        class="nav-item">
                        <i class="bi bi-laptop"></i>Assets
                    </a>
                    <a href="AssetAssignments.aspx"
                        class="nav-item">
                        <i class="bi bi-persom-check"></i>Asset Assignments
                    </a>
                    <a href="Returns.aspx"
                        class="nav-item">
                        <i class="bi bi-arrow-return-left"></i>Returns
                    </a>
                    <a href="Documents.aspx"
                        class="nav-item">
                        <i class="bi bi-bar-chart"></i>Reports
                    </a>
                    <a href="AuditLogs.aspx"
                        class="nav-item">
                        <i class="bi bi-shield-check"></i>Audit Logs
                    </a>
                </nav>
                <div class="logout">
                    <a href="LoginPage.aspx"
                        class="nav-item">
                        <i class="bi bi-box-arrow-left"></i>Logout
                    </a>
                </div>
            </aside>
            <!--=======Main Content=======-->
            <main class="main-content">
                <!--TOPBAR-->
                <header class="topbar">
                    <div class="topbar-left">
                        <div class ="menu-button">
                            <i class="bi bi-list"></i>
                        </div>
                        <div class="page-title">
                            Add Employee
                        </div>
                    </div>
                    <div class="topbar-right">
                        <div class="profile">
                            <div class="profile-icon">
                                <i class="bi bi-persom-fill"></i>
                            </div>
                            <div class="profile-info">
                                <strong>
                                    <asp:Label
                                        ID="lblAdminName"
                                        runat="server">Administrator</asp:Label>
                                </strong>
                                <span>
                                    <asp:label
                                        ID="lblAdminRole"
                                        runat="server">IT Administrator</asp:label>
                                </span>
                            </div>
                            <i class="bi bi-chevron-down"></i>
                        </div>
                    </div>
                </header>
                <!--========CONTENT=======-->
                <section class="content">
                    <div class="page-header">
                        <h1>Add New Employee</h1>
                        <p>Enter Employee Information To Register Them In The System</p>
                    </div>
                    <!--MASSAGE-->
                    <asp:Label
                        ID="lblMessage"
                        runat="server"
                        Visible="false">
                    </asp:Label>
                    <!--Dorm Card-->
                    <div class="form-card">
                        <div class="form-card-header">
                            <i class="bi bi-persom-plus-fill"></i>
                            <h2>Employess Information</h2>
                        </div>
                        <div class="form-grid">
                            <!--EMPLOYEE NUMBER-->
                            <div class="form-group">
                                <label>Employee Number *</label>
                                <asp:TextBox
                                    ID="txtEmployeeNumber"
                                    runat="server"
                                    CssClass="form-control"
                                    placeholder="Enter employee number"></asp:TextBox>
                            </div>
                             <!--EMPLOYEE ID-->
                            <div class="form-group">
                                <label>Employee ID *</label>
                                <asp:TextBox
                                    ID="txtEmployeeID"
                                    runat="server"
                                    CssClass="form-control"
                                    placeholder="Enter employee ID"></asp:TextBox>
                            </div>
                            <!--FIRST NAME-->
                            <div class="form-group">
                                <label>Frist Name *</label>
                                <asp:TextBox
                                    ID="txtFirstName"
                                    runat="server"
                                    CssClass="form-control"
                                    placeholder="Enter first name"></asp:TextBox>
                            </div>
                            <!--EMPLOYEE NUMBER-->
                            <div class="form-group">
                                <label>Last Name *</label>
                                <asp:TextBox
                                    ID="txtLastName"
                                    runat="server"
                                    CssClass="form-control"
                                    placeholder="Enter last name"></asp:TextBox>
                            </div>
                          <!--EMAIL-->
                            <div class="form-group">
                                <label>Email Address *</label>
                                <asp:TextBox
                                    ID="txtEmail"
                                    runat="server"
                                    CssClass="form-control"
                                    TextMode="Email"
                                    placeholder="Enter employee number"></asp:TextBox>
                            </div>
                           <!--JOB TITLE-->
                            <div class="form-group">
                                <label>Job Title *</label>
                                <asp:TextBox
                                    ID="txtJobTitl"
                                    runat="server"
                                    CssClass="form-control"
                                    placeholder="Enter job title"></asp:TextBox>
                            </div>
                          <!--PHONE NUMBER-->
                            <div class="form-group">
                                <label>Phone Number *</label>
                                <asp:TextBox
                                    ID="txtPhoneNumber"
                                    runat="server"
                                    CssClass="form-control"
                                    placeholder="Enter phone number"></asp:TextBox>
                            </div>
                        </div>
                        <!--BUTTONS-->
                        <div class="form-actions">
                            <a href="Users.aspx"
                                class="cancel-button"></a>
                            <asp:Button
                                ID="btnSaveEmployee"
                                runat="server"
                                Text="Save Employee"
                                CssClass="save-button"
                                OnClick="btnSaveEmployee_Click" />
                        </div>
                    </div>
                </section>
            </main>
        </div>
    </form>
</body>
</html>
