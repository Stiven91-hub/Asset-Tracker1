﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="Users.aspx.cs" Inherits="Assets_Tracker.Users" %>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title>Users - IT Asset Management System</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" />
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
            background: #f8fafc;
            color: #1e293b;
        }

        .dashboard-container {
            display: flex;
            min-height: 100vh;
        }

        /* ==============================
           SIDEBAR
        ============================== */
        .sidebar {
            width: 260px;
            background: linear-gradient(180deg, #006b4f 0%, #063b5c 100%);
            position: fixed;
            left: 0;
            top: 0;
            bottom: 0;
            display: flex;
            flex-direction: column;
            z-index: 100;
        }

        .logo {
            height: 75px;
            display: flex;
            align-items: center;
            padding: 0 20px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.12);
            color: white;
        }

        .logo-icon {
            width: 40px;
            height: 40px;
            background: rgba(255, 255, 255, 0.1);
            border: 2px solid white;
            color: white;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
            margin-right: 12px;
            flex-shrink: 0;
        }

        .logo-text {
            font-size: 14px;
            font-weight: 700;
            color: white;
            line-height: 1.2;
        }

        .logo-text span {
            display: block;
            font-weight: 400;
            opacity: 0.8;
            font-size: 12px;
            margin-top: 2px;
        }

        .navigation {
            padding: 20px 12px;
            flex: 1;
            overflow-y: auto;
        }

        .nav-item {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 16px;
            margin-bottom: 4px;
            text-decoration: none;
            color: rgba(255, 255, 255, 0.85);
            border-radius: 8px;
            font-size: 14px;
            transition: all 0.2s ease;
        }

        .nav-item i {
            font-size: 18px;
            width: 20px;
            text-align: center;
        }

        .nav-item:hover {
            background: rgba(255, 255, 255, 0.12);
            color: white;
        }

        .nav-item.active {
            background: #2563eb;
            color: white;
            font-weight: 600;
            box-shadow: 0 4px 12px rgba(37, 99, 235, 0.3);
        }

        .logout {
            padding: 16px 12px;
            border-top: 1px solid rgba(255, 255, 255, 0.12);
        }

        /* ==============================
           MAIN CONTENT
        ============================== */
        .main-content {
            margin-left: 260px;
            width: calc(100% - 260px);
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }

        /* ==============================
           TOP BAR
        ============================== */
        .topbar {
            height: 75px;
            background: #ffffff;
            border-bottom: 1px solid #e2e8f0;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0 32px;
            position: sticky;
            top: 0;
            z-index: 90;
        }

        .topbar-left {
            display: flex;
            align-items: center;
            gap: 16px;
        }

        .menu-button {
            font-size: 22px;
            color: #64748b;
            cursor: pointer;
        }

        .page-title {
            font-size: 20px;
            font-weight: 700;
            color: #0f172a;
        }

        .topbar-right {
            display: flex;
            align-items: center;
            gap: 24px;
        }

        .notification {
            position: relative;
            font-size: 20px;
            color: #64748b;
            cursor: pointer;
        }

        .notification-badge {
            position: absolute;
            top: -4px;
            right: -4px;
            background: #ef4444;
            color: white;
            font-size: 10px;
            font-weight: 600;
            width: 16px;
            height: 16px;
            border-radius: 50%;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .profile {
            display: flex;
            align-items: center;
            gap: 12px;
            cursor: pointer;
        }

        .profile-icon {
            width: 40px;
            height: 40px;
            background: #eff6ff;
            color: #2563eb;
            border-radius: 50%;
            display: flex;
            justify-content: center;
            align-items: center;
            font-size: 18px;
        }

        .profile-info strong {
            display: block;
            font-size: 14px;
            color: #1e293b;
            line-height: 1.2;
        }

        .profile-info span {
            display: block;
            color: #64748b;
            font-size: 12px;
        }

        .profile-arrow {
            color: #94a3b8;
            font-size: 14px;
        }

        /* ==============================
           CONTENT
        ============================== */
        .content {
            padding: 32px;
            flex: 1;
        }

        /* ==============================
           PAGE HEADER
        ============================== */
        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 28px;
        }

        .heading h1 {
            font-size: 24px;
            font-weight: 700;
            color: #0f172a;
            margin-bottom: 4px;
        }

        .heading p {
            color: #64748b;
            font-size: 14px;
        }

        .add-button {
            background: #2563eb;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 8px;
            text-decoration: none;
            font-size: 14px;
            font-weight: 600;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            cursor: pointer;
            transition: background 0.2s ease;
        }

        .add-button:hover {
            background: #1d4ed8;
        }

        /* ==============================
           STAT CARDS
        ============================== */
        .employee-stats {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 20px;
            margin-bottom: 28px;
        }

        .small-stat {
            background: white;
            border: 1px solid #e2e8f0;
            border-radius: 12px;
            padding: 20px;
            display: flex;
            align-items: center;
            gap: 16px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.02);
        }

        .small-stat-icon {
            width: 48px;
            height: 48px;
            border-radius: 10px;
            background: #eff6ff;
            color: #2563eb;
            display: flex;
            justify-content: center;
            align-items: center;
            font-size: 22px;
            flex-shrink: 0;
        }

        .small-stat:nth-child(2) .small-stat-icon {
            background: #f0fdf4;
            color: #16a34a;
        }

        .small-stat:nth-child(3) .small-stat-icon {
            background: #fff7ed;
            color: #ea580c;
        }

        .small-stat p {
            font-size: 13px;
            color: #64748b;
            margin-bottom: 4px;
            font-weight: 500;
        }

        .small-stat h2 {
            font-size: 24px;
            font-weight: 700;
            color: #0f172a;
        }

        /* ==============================
           TABLE PANEL
        ============================== */
        .panel {
            background: white;
            border: 1px solid #e2e8f0;
            border-radius: 12px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.02);
            overflow: hidden;
        }

        .panel-header {
            padding: 20px 24px;
            border-bottom: 1px solid #e2e8f0;
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 16px;
        }

        .panel-title {
            font-size: 16px;
            font-weight: 600;
            color: #0f172a;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .panel-title i {
            color: #2563eb;
        }

        /* ==============================
           SEARCH
        ============================== */
        .search-container {
            display: flex;
            gap: 10px;
            align-items: center;
        }

        .search-box {
            position: relative;
        }

        .search-box i {
            position: absolute;
            left: 12px;
            top: 50%;
            transform: translateY(-50%);
            color: #94a3b8;
            font-size: 14px;
        }

        .search-input {
            width: 260px;
            height: 38px;
            border: 1px solid #cbd5e1;
            border-radius: 8px;
            padding-left: 36px;
            padding-right: 12px;
            outline: none;
            font-size: 13px;
            transition: border-color 0.2s ease;
        }

        .search-input:focus {
            border-color: #2563eb;
            box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.1);
        }

        /* ==============================
           TABLE
        ============================== */
        .table-wrapper {
            overflow-x: auto;
        }

        .employee-table {
            width: 100%;
            border-collapse: collapse;
        }

        .employee-table th {
            background: #f8fafc;
            color: #475569;
            font-size: 11px;
            font-weight: 700;
            letter-spacing: 0.05em;
            text-transform: uppercase;
            text-align: left;
            padding: 14px 24px;
            border-bottom: 1px solid #e2e8f0;
        }

        .employee-table td {
            padding: 16px 24px;
            border-bottom: 1px solid #f1f5f9;
            font-size: 13px;
            color: #334155;
            vertical-align: middle;
        }

        .employee-table tr:last-child td {
            border-bottom: none;
        }

        .employee-table tr:hover {
            background: #f8fafc;
        }

        /* ==============================
           EMPLOYEE
        ============================== */
        .employee-cell {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .employee-avatar {
            width: 36px;
            height: 36px;
            border-radius: 50%;
            background: #eff6ff;
            color: #2563eb;
            display: flex;
            justify-content: center;
            align-items: center;
            font-weight: 700;
            font-size: 13px;
            flex-shrink: 0;
        }

        .employee-name {
            font-weight: 600;
            color: #0f172a;
            display: block;
        }

        .employee-number {
            font-size: 11px;
            color: #64748b;
            margin-top: 2px;
            display: block;
        }

        /* ==============================
           BADGES
        ============================== */
        .job-badge {
            display: inline-block;
            padding: 4px 10px;
            border-radius: 6px;
            background: #f1f5f9;
            color: #475569;
            font-size: 12px;
            font-weight: 500;
        }

        /* ==============================
           ACTION BUTTONS
        ============================== */
        .actions {
            display: flex;
            gap: 8px;
        }

        .action-button {
            width: 32px;
            height: 32px;
            border: none;
            border-radius: 6px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            text-decoration: none;
            transition: opacity 0.2s ease;
        }

        .view-button {
            background: #eff6ff;
            color: #2563eb;
        }

        .edit-button {
            background: #fff7ed;
            color: #ea580c;
        }

        .delete-button {
            background: #fef2f2;
            color: #dc2626;
        }

        .action-button:hover {
            opacity: 0.8;
        }

        /* ==============================
           FOOTER
        ============================== */
        .footer {
            text-align: center;
            color: #94a3b8;
            font-size: 12px;
            padding: 24px 0 12px;
        }

        /* ==============================
           RESPONSIVE
        ============================== */
        @media (max-width: 1024px) {
            .sidebar {
                width: 220px;
            }

            .main-content {
                margin-left: 220px;
                width: calc(100% - 220px);
            }

            .employee-stats {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>

<form id="form1" runat="server">
    <div class="dashboard-container">

        <!-- SIDEBAR -->
        <aside class="sidebar">
            <div class="logo">
                <div class="logo-icon">
                    <i class="bi bi-display"></i>
                </div>
                <div class="logo-text">
                    IT Asset Management
                    <span>System</span>
                </div>
            </div>

            <nav class="navigation">
                <a href="Dashboard.aspx" class="nav-item">
                    <i class="bi bi-grid"></i>
                    <span>Dashboard</span>
                </a>

                <a href="Employees.aspx" class="nav-item active">
                    <i class="bi bi-person"></i>
                    <span>Users</span>
                </a>

                <a href="Assets.aspx" class="nav-item">
                    <i class="bi bi-laptop"></i>
                    <span>Assets</span>
                </a>

                <a href="AssetAssignments.aspx" class="nav-item">
                    <i class="bi bi-person-check"></i>
                    <span>Asset Assignments</span>
                </a>

                <a href="Returns.aspx" class="nav-item">
                    <i class="bi bi-box-arrow-in-left"></i>
                    <span>Returns</span>
                </a>

                <a href="Documents.aspx" class="nav-item">
                    <i class="bi bi-file-earmark-text"></i>
                    <span>Documents</span>
                </a>

                <a href="Reports.aspx" class="nav-item">
                    <i class="bi bi-bar-chart"></i>
                    <span>Reports</span>
                </a>

                <a href="AuditLogs.aspx" class="nav-item">
                    <i class="bi bi-shield-check"></i>
                    <span>Audit Logs</span>
                </a>

                <a href="ImportData.aspx" class="nav-item">
                    <i class="bi bi-upload"></i>
                    <span>Import Data</span>
                </a>
            </nav>

            <div class="logout">
                <a href="LoginPage.aspx" class="nav-item">
                    <i class="bi bi-box-arrow-left"></i>
                    <span>Logout</span>
                </a>
            </div>
        </aside>

        <!-- MAIN CONTENT -->
        <main class="main-content">

            <!-- TOP BAR -->
            <header class="topbar">
                <div class="topbar-left">
                    <div class="menu-button">
                        <i class="bi bi-list"></i>
                    </div>
                    <div class="page-title">
                        Employees
                    </div>
                </div>

                <div class="topbar-right">
                    <div class="profile">
                        <div class="profile-icon">
                            <i class="bi bi-person-fill"></i>
                        </div>
                        <div class="profile-info">
                            <strong>
                                <asp:Label ID="lblAdminName" runat="server">Administrator</asp:Label>
                            </strong>
                            <span>
                                <asp:Label ID="lblAdminRole" runat="server">IT Administrator</asp:Label>
                            </span>
                        </div>
                        <div class="profile-arrow">
                            <i class="bi bi-chevron-down"></i>
                        </div>
                    </div>
                </div>
            </header>

            <!-- CONTENT BODY -->
            <section class="content">

                <!-- PAGE HEADER -->
                <div class="page-header">
                    <div class="heading">
                        <h1>Employee Management</h1>
                        <p>Manage employees and their IT asset information.</p>
                    </div>

                    <a href="AddEmployee.aspx" class="add-button">
                        <i class="bi bi-person-plus"></i>
                        <span>Add Employee</span>
                    </a>
                </div>

                <!-- STATISTICS CARDS -->
                <div class="employee-stats">
                    <div class="small-stat">
                        <div class="small-stat-icon">
                            <i class="bi bi-people"></i>
                        </div>
                        <div>
                            <p>Total Employees</p>
                            <h2>
                                <asp:Label ID="lblTotalEmployees" runat="server">0</asp:Label>
                            </h2>
                        </div>
                    </div>

                    <div class="small-stat">
                        <div class="small-stat-icon">
                            <i class="bi bi-person-check"></i>
                        </div>
                        <div>
                            <p>Employees With Assets</p>
                            <h2>
                                <asp:Label ID="lblEmployeesWithAssets" runat="server">0</asp:Label>
                            </h2>
                        </div>
                    </div>

                    <div class="small-stat">
                        <div class="small-stat-icon">
                            <i class="bi bi-person-x"></i>
                        </div>
                        <div>
                            <p>Employees Without Assets</p>
                            <h2>
                                <asp:Label ID="lblEmployeesWithoutAssets" runat="server">0</asp:Label>
                            </h2>
                        </div>
                    </div>
                </div>

                <!-- EMPLOYEE TABLE PANEL -->
                <div class="panel">
                    <div class="panel-header">
                        <div class="panel-title">
                            <i class="bi bi-people"></i>
                            <span>Employee List</span>
                        </div>

                        <div class="search-container">
                            <div class="search-box">
                                <i class="bi bi-search"></i>
                                <asp:TextBox ID="txtSearch" runat="server" CssClass="search-input" placeholder="Search employees..."></asp:TextBox>
                            </div>
                            <asp:Button ID="btnSearch" runat="server" Text="Search" CssClass="add-button" OnClick="btnSearch_Click" />
                        </div>
                    </div>

                    <div class="table-wrapper">
                        <table class="employee-table">
                            <thead>
                                <tr>
                                    <th>EMPLOYEE</th>
                                    <th>EMPLOYEE ID</th>
                                    <th>EMAIL</th>
                                    <th>JOB TITLE</th>
                                    <th>PHONE NUMBER</th>
                                    <th>ACTIONS</th>
                                </tr>
                            </thead>
                            <tbody>
                                <asp:Repeater ID="rptEmployees" runat="server">
                                    <ItemTemplate>
                                        <tr>
                                            <td>
                                                <div class="employee-cell">
                                                    <div class="employee-avatar">
                                                        <%# (Eval("FirstName").ToString().Substring(0, 1) + Eval("LastName").ToString().Substring(0, 1)).ToUpper() %>
                                                    </div>
                                                    <div>
                                                        <span class="employee-name"><%# Eval("FirstName") %> <%# Eval("LastName") %></span>
                                                        <span class="employee-number">Employee No: <%# Eval("EmployeeNumber") %></span>
                                                    </div>
                                                </div>
                                            </td>
                                            <td><%# Eval("EmployeeID") %></td>
                                            <td><%# Eval("Email") %></td>
                                            <td>
                                                <span class="job-badge"><%# Eval("JobTitle") %></span>
                                            </td>
                                            <td><%# Eval("PhoneNumber") %></td>
                                            <td>
                                                <div class="actions">
                                                    <a class="action-button view-button" title="View Employee" href='EmployeeDetails.aspx?id=<%# Eval("EmployeeNumber") %>'>
                                                        <i class="bi bi-eye"></i>
                                                    </a>
                                                    <a class="action-button edit-button" title="Edit Employee" href='EditEmployee.aspx?id=<%# Eval("EmployeeNumber") %>'>
                                                        <i class="bi bi-pencil"></i>
                                                    </a>
                                                    <a class="action-button delete-button" title="Delete Employee" href='DeleteEmployee.aspx?id=<%# Eval("EmployeeNumber") %>'>
                                                        <i class="bi bi-trash"></i>
                                                    </a>
                                                </div>
                                            </td>
                                        </tr>
                                    </ItemTemplate>
                                </asp:Repeater>
                            </tbody>
                        </table>
                    </div>
                </div>

                <!-- FOOTER -->
                <footer class="footer">
                    © <asp:Label ID="lblYear" runat="server"></asp:Label> IT Asset Management System. All rights reserved.
                </footer>

            </section>
        </main>
    </div>
</form>

</body>
</html>