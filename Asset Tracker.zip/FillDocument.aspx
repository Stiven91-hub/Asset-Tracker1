﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="FillDocument.aspx.cs" Inherits="Assets_Tracker.FillDocument" %>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title>Fill Document - IT Assets Management System</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" />
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: Arial, Helvetica, sans-serif;
            background: #f4f6fb;
            color: #1f2937;
        }
        .dashboard-container {
            display: flex;
            min-height: 100vh;
        }
        /* ================= SIDEBAR ================= */
        .sidebar {
            width: 255px;
            background: linear-gradient(180deg, #0f5c4d 0%, #123a5c 100%);
            color: white;
            position: fixed;
            top: 0;
            left: 0;
            bottom: 0;
            display: flex;
            flex-direction: column;
            z-index: 1000;
        }
        .logo {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 25px 20px;
            border-bottom: 1px solid rgba(255,255,255,0.12);
        }
        .logo-icon {
            width: 42px;
            height: 42px;
            border-radius: 10px;
            background: rgba(255,255,255,0.15);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 21px;
        }
        .logo-text {
            font-size: 15px;
            font-weight: 700;
            line-height: 1.3;
        }
        .logo-text span {
            display: block;
            font-size: 12px;
            font-weight: 400;
            opacity: 0.75;
        }
        .navigation {
            padding: 20px 12px;
            flex: 1;
        }
        .nav-item {
            display: flex;
            align-items: center;
            gap: 13px;
            padding: 13px 15px;
            margin-bottom: 6px;
            color: rgba(255,255,255,0.82);
            text-decoration: none;
            border-radius: 9px;
            font-size: 14px;
            transition: 0.2s;
        }
        .nav-item i {
            font-size: 18px;
            width: 22px;
        }
        .nav-item:hover {
            background: rgba(255,255,255,0.10);
            color: white;
        }
        .nav-item.active {
            background: linear-gradient(90deg, #2563c7, #3f7bd7);
            color: white;
            box-shadow: 0 5px 15px rgba(0,0,0,0.15);
        }
        .logout {
            padding: 15px 12px 25px;
            border-top: 1px solid rgba(255,255,255,0.12);
        }
        /* ================= MAIN ================= */
        .main-content {
            margin-left: 255px;
            width: calc(100% - 255px);
            min-height: 100vh;
        }
        /* ================= TOPBAR ================= */
        .topbar {
            height: 75px;
            background: white;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 30px;
            border-bottom: 1px solid #e5e7eb;
        }
        .topbar-left {
            display: flex;
            align-items: center;
            gap: 18px;
        }
        .menu-button {
            width: 40px;
            height: 40px;
            border-radius: 8px;
            background: #f1f5f9;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #334155;
            font-size: 21px;
        }
        .page-title {
            font-size: 20px;
            font-weight: 700;
            color: #1e293b;
        }
        .topbar-right {
            display: flex;
            align-items: center;
            gap: 25px;
        }
        .notifications {
            position: relative;
            font-size: 21px;
            color: #475569;
        }
        .notification-badge {
            position: absolute;
            width: 8px;
            height: 8px;
            background: #ef4444;
            border-radius: 50%;
            top: 0;
            right: -2px;
        }
        .profile {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .profile-icon {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: #e8f1ff;
            color: #2563c7;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .profile-info strong {
            display: block;
            font-size: 13px;
            color: #1e293b;
        }
        .profile-info span {
            display: block;
            font-size: 11px;
            color: #64748b;
            margin-top: 2px;
        }
        /* ================= CONTENT ================= */
        .content {
            padding: 30px;
        }
        .page-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 25px;
        }
        .heading h1 {
            font-size: 27px;
            color: #172033;
            margin-bottom: 6px;
        }
        .heading p {
            color: #64748b;
            font-size: 14px;
        }
        .back-button {
            text-decoration: none;
            background: white;
            border: 1px solid #dbe1e8;
            color: #334155;
            padding: 10px 17px;
            border-radius: 8px;
            font-size: 13px;
            font-weight: 600;
        }
        .back-button:hover {
            background: #f8fafc;
        }
        /* ================= DOCUMENT CARD ================= */
        .document-card {
            background: white;
            border-radius: 12px;
            border: 1px solid #e3e8ef;
            box-shadow: 0 3px 12px rgba(15,23,42,0.05);
            margin-bottom: 25px;
        }
        .document-header {
            padding: 20px 24px;
            border-bottom: 1px solid #e5e7eb;
            display: flex;
            align-items: center;
            gap: 14px;
        }
        .document-header-icon {
            width: 45px;
            height: 45px;
            background: #e8f1ff;
            color: #2563c7;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 22px;
        }
        .document-header h2 {
            font-size: 18px;
            color: #1e293b;
        }
        .document-header p {
            font-size: 12px;
            color: #64748b;
            margin-top: 4px;
        }
        .document-body {
            padding: 25px;
        }
        /* ================= EMPLOYEE / ASSET SELECTION ================= */
        .selection-section {
            background: #f8fafc;
            border: 1px solid #e2e8f0;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 25px;
        }
        .section-title {
            font-size: 15px;
            font-weight: 700;
            color: #1e293b;
            margin-bottom: 17px;
            display: flex;
            align-items: center;
            gap: 8px;
        }
        .section-title i {
            color: #2563c7;
        }
        .form-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 18px;
        }
        .form-group {
            display: flex;
            flex-direction: column;
        }
        .form-group.full {
            grid-column: 1 / -1;
        }
        .form-label {
            font-size: 13px;
            font-weight: 600;
            color: #374151;
            margin-bottom: 7px;
        }
        .required {
            color: #dc2626;
        }
        .form-control,
        .form-select {
            width: 100%;
            height: 43px;
            border: 1px solid #d1d5db;
            border-radius: 7px;
            padding: 0 12px;
            background: white;
            font-size: 13px;
            color: #334155;
            outline: none;
        }
        .form-control:focus,
        .form-select:focus {
            border-color: #2563c7;
            box-shadow: 0 0 0 3px rgba(37,99,199,0.10);
        }
        textarea.form-control {
            height: 90px;
            padding: 12px;
            resize: vertical;
        }
        /* ================= DOCUMENT FORMS ================= */
        .form-section {
            border: 1px solid #dfe5ec;
            border-radius: 10px;
            margin-bottom: 20px;
            overflow: hidden;
        }
        .form-section-header {
            background: #f1f5f9;
            padding: 14px 18px;
            font-size: 14px;
            font-weight: 700;
            color: #1e293b;
            border-bottom: 1px solid #dfe5ec;
        }
        .form-section-body {
            padding: 20px;
        }
        .document-title {
            text-align: center;
            padding: 10px 0 22px;
        }
        .document-title h2 {
            font-size: 20px;
            color: #172033;
            margin-bottom: 5px;
        }
        .document-title p {
            font-size: 12px;
            color: #64748b;
        }
        /* ================= CHECKBOXES ================= */
        .checkbox-row {
            display: flex;
            gap: 25px;
            flex-wrap: wrap;
            margin-top: 8px;
        }
        .checkbox-item {
            display: flex;
            align-items: center;
            gap: 7px;
            font-size: 13px;
            color: #475569;
        }
        .checkbox-item input {
            width: 16px;
            height: 16px;
            accent-color: #2563c7;
        }
        /* ================= TABLE ================= */
        .document-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }
        .document-table th,
        .document-table td {
            border: 1px solid #d9e0e8;
            padding: 11px;
            font-size: 12px;
            text-align: left;
        }
        .document-table th {
            background: #f1f5f9;
            font-weight: 700;
            color: #334155;
        }
        .document-table td {
            color: #475569;
        }
        .table-input {
            width: 100%;
            border: 1px solid #d1d5db;
            border-radius: 5px;
            padding: 7px;
            font-size: 12px;
        }
        /* ================= MESSAGE ================= */
        .message {
            display: block;
            padding: 12px 15px;
            border-radius: 7px;
            margin-bottom: 20px;
            font-size: 13px;
        }
        .message.success {
            background: #ecfdf5;
            border: 1px solid #a7f3d0;
            color: #047857;
        }
        .message.error {
            background: #fef2f2;
            border: 1px solid #fecaca;
            color: #b91c1c;
        }
        /* ================= BUTTONS ================= */
        .button-area {
            display: flex;
            justify-content: flex-end;
            gap: 12px;
            padding-top: 10px;
        }
        .btn {
            border: none;
            border-radius: 8px;
            padding: 11px 20px;
            font-size: 13px;
            font-weight: 600;
            cursor: pointer;
        }
        .btn-primary {
            background: linear-gradient(90deg, #2563c7, #3b82f6);
            color: white;
        }
        .btn-primary:hover {
            opacity: 0.92;
        }
        .btn-secondary {
            background: #e5e7eb;
            color: #374151;
        }
        .btn-secondary:hover {
            background: #dbe0e6;
        }
        /* ================= FOOTER ================= */
        .footer {
            text-align: center;
            color: #94a3b8;
            font-size: 12px;
            padding: 25px 0 5px;
        }
        /* ================= RESPONSIVE ================= */
        @media (max-width: 900px) {
            .sidebar {
                width: 220px;
            }
            .main-content {
                margin-left: 220px;
                width: calc(100% - 220px);
            }
            .form-grid {
                grid-template-columns: 1fr;
            }
            .form-group.full {
                grid-column: auto;
            }
        }
    </style>
</head>
<body>
<form id="form1" runat="server">
<div class="dashboard-container">
    <!-- ====================== SIDEBAR ====================== -->
    <aside class="sidebar">
        <div class="logo">
            <div class="logo-icon">
                <i class="bi bi-display"></i>
            </div>
            <div class="logo-text">
                IT Assets Management System
                <span>System</span>
            </div>
        </div>
        <nav class="navigation">
            <a href="Dashboard.aspx" class="nav-item">
                <i class="bi bi-grid"></i>
                Dashboard
            </a>
            <a href="Users.aspx" class="nav-item">
                <i class="bi bi-person"></i>
                Users
            </a>
            <a href="Assets.aspx" class="nav-item">
                <i class="bi bi-laptop"></i>
                Assets
            </a>
            <a href="AssetAssignments.aspx" class="nav-item">
                <i class="bi bi-person-check"></i>
                Asset Assignments
            </a>
            <a href="Returns.aspx" class="nav-item">
                <i class="bi bi-arrow-in-left"></i>
                Returns
            </a>
            <a href="Documents.aspx" class="nav-item active">
                <i class="bi bi-file-earmark-text"></i>
                Documents
            </a>
            <a href="Reports.aspx" class="nav-item">
                <i class="bi bi-bar-chart"></i>
                Reports
            </a>
            <a href="AditLogs.aspx" class="nav-item">
                <i class="bi bi-shield-check"></i>
                Audit Logs
            </a>
            <a href="ImportData.aspx" class="nav-item">
                <i class="bi bi-upload"></i>
                Import Data
            </a>
        </nav>
        <div class="logout">
            <a href="Login.aspx" class="nav-item">
                <i class="bi bi-box-arrow-left"></i>
                Logout
            </a>
        </div>
    </aside>
    <!-- ====================== MAIN CONTENT ====================== -->
    <main class="main-content">
        <!-- TOPBAR -->
        <header class="topbar">
            <div class="topbar-left">
                <div class="menu-button">
                    <i class="bi bi-list"></i>
                </div>
                <div class="page-title">
                    Fill Document
                </div>
            </div>
            <div class="topbar-right">
                <div class="profile">
                    <div class="profile-icon">
                        <i class="bi bi-person-fill"></i>
                    </div>
                    <div class="profile-info">
                        <strong>
                            <asp:Label ID="lblAdminName" runat="server" Text="Administrator"></asp:Label>
                        </strong>
                        <span>
                            <asp:Label ID="lblAdminRole" runat="server" Text="IT Administrator"></asp:Label>
                        </span>
                    </div>
                    <i class="bi bi-chevron-down"></i>
                </div>
            </div>
        </header>
        <!-- ====================== CONTENT ====================== -->
        <section class="content">
            <div class="page-header">
                <div class="heading">
                    <h1>Fill Document</h1>
                    <p>
                        Complete the required document before issuing or managing an asset.
                    </p>
                </div>
                <a href="Documents.aspx" class="back-button">
                    <i class="bi bi-arrow-left"></i>
                    Back to Documents
                </a>
            </div>
            <!-- MESSAGE -->
            <asp:Label ID="lblMessage" runat="server" CssClass="message" Visible="false"></asp:Label>
            <!-- DOCUMENT CARD -->
            <div class="document-card">
                <div class="document-header">
                    <div class="document-header-icon">
                        <i class="bi bi-file-earmark-text"></i>
                    </div>
                    <div>
                        <h2>
                            <asp:Label ID="lblDocumentTitle" runat="server" Text="Document"></asp:Label>
                        </h2>
                        <p>
                            <asp:Label ID="lblDocumentDescription" runat="server" Text="Complete the information below."></asp:Label>
                        </p>
                    </div>
                </div>
                <div class="document-body">
                    <!-- ================= EMPLOYEE / ASSET ================= -->
                    <div class="selection-section">
                        <div class="section-title">
                            <i class="bi bi-person-vcard"></i>
                            Employee & Asset Information
                        </div>
                        <div class="form-grid">
                            <div class="form-group">
                                <label class="form-label">
                                    Employee
                                    <span class="required">*</span>
                                </label>
                                <asp:DropDownList ID="ddlEmployee" runat="server" CssClass="form-select" AutoPostBack="true" OnSelectedIndexChanged="ddlEmployee_SelectedIndexChanged"></asp:DropDownList>
                            </div>
                            <div class="form-group">
                                <label class="form-label">
                                    Asset
                                    <span class="required">*</span>
                                </label>
                                <asp:DropDownList ID="ddlAsset" runat="server" CssClass="form-select" AutoPostBack="true" OnSelectedIndexChanged="ddlAsset_SelectedIndexChanged"></asp:DropDownList>
                            </div>
                            <div class="form-group">
                                <label class="form-label">
                                    Employee Number / Persal Number
                                </label>
                                <asp:TextBox ID="txtEmployeeNumber" runat="server" CssClass="form-control" ReadOnly="true"></asp:TextBox>
                            </div>
                            <div class="form-group">
                                <label class="form-label">
                                    Employee Name
                                </label>
                                <asp:TextBox ID="txtEmployeeName" runat="server" CssClass="form-control" ReadOnly="true"></asp:TextBox>
                            </div>
                            <div class="form-group">
                                <label class="form-label">
                                    Asset Tag
                                </label>
                                <asp:TextBox ID="txtAssetTag" runat="server" CssClass="form-control" ReadOnly="true"></asp:TextBox>
                            </div>
                            <div class="form-group">
                                <label class="form-label">
                                    Serial Number
                                </label>
                                <asp:TextBox ID="txtSerialNumber" runat="server" CssClass="form-control" ReadOnly="true"></asp:TextBox>
                            </div>
                        </div>
                    </div>
                    <!-- ================= DOCUMENT 1 ================= -->
                    <asp:Panel ID="pnlAssetForm" runat="server" Visible="false">
                        <div class="form-section">
                            <div class="form-section-header">
                                <i class="bi bi-laptop"></i>
                                Asset Form HP
                            </div>
                            <div class="form-section-body">
                                <div class="document-title">
                                    <h2>
                                        NEW / LOAN COMPUTER ISSUE CONTROL FORM
                                    </h2>
                                    <p>
                                        Equipment Issue Information
                                    </p>
                                </div>
                                <div class="form-grid">
                                    <div class="form-group">
                                        <label class="form-label">
                                            Name
                                        </label>
                                        <asp:TextBox ID="txtFirstName" runat="server" CssClass="form-control"></asp:TextBox>
                                    </div>
                                    <div class="form-group">
                                        <label class="form-label">
                                            Surname
                                        </label>
                                        <asp:TextBox ID="txtLastName" runat="server" CssClass="form-control"></asp:TextBox>
                                    </div>
                                    <div class="form-group">
                                        <label class="form-label">
                                            Position
                                        </label>
                                        <asp:TextBox ID="txtPosition" runat="server" CssClass="form-control"></asp:TextBox>
                                    </div>
                                    <div class="form-group">
                                        <label class="form-label">
                                            Reports To
                                        </label>
                                        <asp:TextBox ID="txtReportsTo" runat="server" CssClass="form-control"></asp:TextBox>
                                    </div>
                                    <div class="form-group">
                                        <label class="form-label">
                                            Directorate / Unit
                                        </label>
                                        <asp:TextBox ID="txtDirectorate" runat="server" CssClass="form-control"></asp:TextBox>
                                    </div>
                                    <div class="form-group">
                                        <label class="form-label">
                                            E-mail
                                        </label>
                                        <asp:TextBox ID="txtEmail" runat="server" CssClass="form-control"></asp:TextBox>
                                    </div>
                                    <div class="form-group">
                                        <label class="form-label">
                                            Contact Number
                                        </label>
                                        <asp:TextBox ID="txtContactNumber" runat="server" CssClass="form-control"></asp:TextBox>
                                    </div>
                                    <div class="form-group">
                                        <label class="form-label">
                                            Building
                                        </label>
                                        <asp:TextBox ID="txtBuilding" runat="server" CssClass="form-control"></asp:TextBox>
                                    </div>
                                </div>
                                <div class="section-title" style="margin-top:25px;">
                                    <i class="bi bi-pc-display"></i>
                                    Equipment
                                </div>
                                <table class="document-table">
                                    <thead>
                                        <tr>
                                            <th>Description</th>
                                            <th>Model</th>
                                            <th>Serial No. / Service Tag</th>
                                            <th>Included</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>Laptop</td>
                                            <td>
                                                <asp:TextBox ID="txtLaptopModel" runat="server" CssClass="table-input"></asp:TextBox>
                                            </td>
                                            <td>
                                                <asp:TextBox ID="txtLaptopSerial" runat="server" CssClass="table-input"></asp:TextBox>
                                            </td>
                                            <td>
                                                <asp:CheckBox ID="chkLaptop" runat="server" />
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>Charger</td>
                                            <td colspan="2"></td>
                                            <td>
                                                <asp:CheckBox ID="chkCharger" runat="server" />
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>LAN Cable Adapter</td>
                                            <td colspan="2"></td>
                                            <td>
                                                <asp:CheckBox ID="chkAdapter" runat="server" />
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>Mouse</td>
                                            <td colspan="2"></td>
                                            <td>
                                                <asp:CheckBox ID="chkMouse" runat="server" />
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>Bag</td>
                                            <td colspan="2"></td>
                                            <td>
                                                <asp:CheckBox ID="chkBag" runat="server" />
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>Lock</td>
                                            <td colspan="2"></td>
                                            <td>
                                                <asp:CheckBox ID="chkLock" runat="server" />
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                                <div class="form-grid" style="margin-top:20px;">
                                    <div class="form-group">
                                        <label class="form-label">
                                            Issued By
                                        </label>
                                        <asp:TextBox ID="txtIssuedBy" runat="server" CssClass="form-control"></asp:TextBox>
                                    </div>
                                    <div class="form-group">
                                        <label class="form-label">
                                            Issue Date
                                        </label>
                                        <asp:TextBox ID="txtIssueDate" runat="server" TextMode="Date" CssClass="form-control"></asp:TextBox>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </asp:Panel>
                    <!-- ================= DOCUMENT 2 ================= -->
                    <asp:Panel ID="pnlPCCompliance" runat="server" Visible="false">
                        <div class="form-section">
                            <div class="form-section-header">
                                <i class="bi bi-clipboard-check"></i>
                                PC Compliance Checklist
                            </div>
                            <div class="form-section-body">
                                <div class="document-title">
                                    <h2>
                                        PC COMPLIANCE CHECKLIST
                                    </h2>
                                    <p>
                                        Gauteng Department of Human Settlements
                                    </p>
                                </div>
                                <div class="form-grid">
                                    <div class="form-group">
                                        <label class="form-label">
                                            User Name and Surname
                                        </label>
                                        <asp:TextBox ID="txtPCUserName" runat="server" CssClass="form-control"></asp:TextBox>
                                    </div>
                                    <div class="form-group">
                                        <label class="form-label">
                                            Persal Number
                                        </label>
                                        <asp:TextBox ID="txtPCPersal" runat="server" CssClass="form-control"></asp:TextBox>
                                    </div>
                                    <div class="form-group">
                                        <label class="form-label">
                                            User Contact No.
                                        </label>
                                        <asp:TextBox ID="txtPCContact" runat="server" CssClass="form-control"></asp:TextBox>
                                    </div>
                                    <div class="form-group">
                                        <label class="form-label">
                                            Directorate
                                        </label>
                                        <asp:TextBox ID="txtPCDirectorate" runat="server" CssClass="form-control"></asp:TextBox>
                                    </div>
                                    <div class="form-group">
                                        <label class="form-label">
                                            Region
                                        </label>
                                        <asp:TextBox ID="txtPCRegion" runat="server" CssClass="form-control"></asp:TextBox>
                                    </div>
                                    <div class="form-group">
                                        <label class="form-label">
                                            ITSM Reference Number
                                        </label>
                                        <asp:TextBox ID="txtITSMReference" runat="server" CssClass="form-control"></asp:TextBox>
                                    </div>
                                </div>
                                <div class="section-title" style="margin-top:25px;">
                                    <i class="bi bi-check2-square"></i>
                                    Compliance Checks
                                </div>
                                <table class="document-table">
                                    <thead>
                                        <tr>
                                            <th>Category</th>
                                            <th>Description</th>
                                            <th>Yes</th>
                                            <th>No</th>
                                            <th>N/A</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>Forms</td>
                                            <td>RFC Form Completed</td>
                                            <td>
                                                <asp:RadioButton ID="rbRFCYes" runat="server" GroupName="RFC" />
                                            </td>
                                            <td>
                                                <asp:RadioButton ID="rbRFCNo" runat="server" GroupName="RFC" />
                                            </td>
                                            <td>
                                                <asp:RadioButton ID="rbRFCNA" runat="server" GroupName="RFC" />
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>Forms</td>
                                            <td>Asset Movement Form Completed</td>
                                            <td>
                                                <asp:RadioButton ID="rbAssetYes" runat="server" GroupName="AssetForm" />
                                            </td>
                                            <td>
                                                <asp:RadioButton ID="rbAssetNo" runat="server" GroupName="AssetForm" />
                                            </td>
                                            <td>
                                                <asp:RadioButton ID="rbAssetNA" runat="server" GroupName="AssetForm" />
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>Forms</td>
                                            <td>Laptop Pass Out Form Completed</td>
                                            <td>
                                                <asp:RadioButton ID="rbLaptopPassYes" runat="server" GroupName="LaptopPass" />
                                            </td>
                                            <td>
                                                <asp:RadioButton ID="rbLaptopPassNo" runat="server" GroupName="LaptopPass" />
                                            </td>
                                            <td>
                                                <asp:RadioButton ID="rbLaptopPassNA" runat="server" GroupName="LaptopPass" />
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>Systems</td>
                                            <td>Employee Self Service Portal (ESS) shortcut</td>
                                            <td>
                                                <asp:RadioButton ID="rbESSYes" runat="server" GroupName="ESS" />
                                            </td>
                                            <td>
                                                <asp:RadioButton ID="rbESSNo" runat="server" GroupName="ESS" />
                                            </td>
                                            <td>
                                                <asp:RadioButton ID="rbESSNA" runat="server" GroupName="ESS" />
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>Systems</td>
                                            <td>Claims Management System</td>
                                            <td>
                                                <asp:RadioButton ID="rbClaimsYes" runat="server" GroupName="Claims" />
                                            </td>
                                            <td>
                                                <asp:RadioButton ID="rbClaimsNo" runat="server" GroupName="Claims" />
                                            </td>
                                            <td>
                                                <asp:RadioButton ID="rbClaimsNA" runat="server" GroupName="Claims" />
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>Software</td>
                                            <td>Office 365</td>
                                            <td>
                                                <asp:RadioButton ID="rbOfficeYes" runat="server" GroupName="Office" />
                                            </td>
                                            <td>
                                                <asp:RadioButton ID="rbOfficeNo" runat="server" GroupName="Office" />
                                            </td>
                                            <td>
                                                <asp:RadioButton ID="rbOfficeNA" runat="server" GroupName="Office" />
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>Network</td>
                                            <td>Patches updating</td>
                                            <td>
                                                <asp:RadioButton ID="rbPatchesYes" runat="server" GroupName="Patches" />
                                            </td>
                                            <td>
                                                <asp:RadioButton ID="rbPatchesNo" runat="server" GroupName="Patches" />
                                            </td>
                                            <td>
                                                <asp:RadioButton ID="rbPatchesNA" runat="server" GroupName="Patches" />
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>Network</td>
                                            <td>Scan to Mail</td>
                                            <td>
                                                <asp:RadioButton ID="rbScanYes" runat="server" GroupName="Scan" />
                                            </td>
                                            <td>
                                                <asp:RadioButton ID="rbScanNo" runat="server" GroupName="Scan" />
                                            </td>
                                            <td>
                                                <asp:RadioButton ID="rbScanNA" runat="server" GroupName="Scan" />
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                                <div class="form-group" style="margin-top:20px;">
                                    <label class="form-label">
                                        Notes
                                    </label>
                                    <asp:TextBox ID="txtPCNotes" runat="server" CssClass="form-control" TextMode="MultiLine"></asp:TextBox>
                                </div>
                                <div class="form-grid" style="margin-top:20px;">
                                    <div class="form-group">
                                        <label class="form-label">
                                            User Signature
                                        </label>
                                        <asp:TextBox ID="txtUserSignature" runat="server" CssClass="form-control"></asp:TextBox>
                                    </div>
                                    <div class="form-group">
                                        <label class="form-label">
                                            Setup Done By
                                        </label>
                                        <asp:TextBox ID="txtSetupDoneBy" runat="server" CssClass="form-control"></asp:TextBox>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </asp:Panel>
                    <!-- ================= DOCUMENT 3 ================= -->
                    <asp:Panel ID="pnlLaptopPass" runat="server" Visible="false">
                        <div class="form-section">
                            <div class="form-section-header">
                                <i class="bi bi-shield-check"></i>
                                Permit To Carry Laptop
                            </div>
                            <div class="form-section-body">
                                <div class="document-title">
                                    <h2>
                                        PERMIT TO CARRY LAPTOP
                                    </h2>
                                    <p>
                                        Gauteng Department of Human Settlements
                                    </p>
                                </div>
                                <div class="form-grid">
                                    <div class="form-group">
                                        <label class="form-label">
                                            Full Name and Surname
                                        </label>
                                        <asp:TextBox ID="txtPermitName" runat="server" CssClass="form-control"></asp:TextBox>
                                    </div>
                                    <div class="form-group">
                                        <label class="form-label">
                                            Title
                                        </label>
                                        <asp:TextBox ID="txtPermitTitle" runat="server" CssClass="form-control"></asp:TextBox>
                                    </div>
                                    <div class="form-group">
                                        <label class="form-label">
                                            Directorate
                                        </label>
                                        <asp:TextBox ID="txtPermitDirectorate" runat="server" CssClass="form-control"></asp:TextBox>
                                    </div>
                                    <div class="form-group">
                                        <label class="form-label">
                                            Telephone Number
                                        </label>
                                        <asp:TextBox ID="txtPermitTelephone" runat="server" CssClass="form-control"></asp:TextBox>
                                    </div>
                                    <div class="form-group">
                                        <label class="form-label">
                                            Reports To
                                        </label>
                                        <asp:TextBox ID="txtPermitReportsTo" runat="server" CssClass="form-control"></asp:TextBox>
                                    </div>
                                    <div class="form-group">
                                        <label class="form-label">
                                            Make and Model
                                        </label>
                                        <asp:TextBox ID="txtPermitMakeModel" runat="server" CssClass="form-control"></asp:TextBox>
                                    </div>
                                    <div class="form-group">
                                        <label class="form-label">
                                            Serial Number
                                        </label>
                                        <asp:TextBox ID="txtPermitSerial" runat="server" CssClass="form-control"></asp:TextBox>
                                    </div>
                                    <div class="form-group">
                                        <label class="form-label">
                                            Departmental Barcode Number
                                        </label>
                                        <asp:TextBox ID="txtPermitBarcode" runat="server" CssClass="form-control"></asp:TextBox>
                                    </div>
                                </div>
                                <div class="section-title" style="margin-top:25px;">
                                    <i class="bi bi-pen"></i>
                                    Authorisation
                                </div>
                                <div class="form-grid">
                                    <div class="form-group">
                                        <label class="form-label">
                                            Signature of Holder
                                        </label>
                                        <asp:TextBox ID="txtHolderSignature" runat="server" CssClass="form-control"></asp:TextBox>
                                    </div>
                                    <div class="form-group">
                                        <label class="form-label">
                                            Date
                                        </label>
                                        <asp:TextBox ID="txtHolderDate" runat="server" TextMode="Date" CssClass="form-control"></asp:TextBox>
                                    </div>
                                    <div class="form-group">
                                        <label class="form-label">
                                            Permit Authorised By
                                        </label>
                                        <asp:TextBox ID="txtAuthorisedBy" runat="server" CssClass="form-control"></asp:TextBox>
                                    </div>
                                    <div class="form-group">
                                        <label class="form-label">
                                            Authorising Title
                                        </label>
                                        <asp:TextBox ID="txtAuthorisingTitle" runat="server" CssClass="form-control"></asp:TextBox>
                                    </div>
                                    <div class="form-group">
                                        <label class="form-label">
                                            Authorisation Date
                                        </label>
                                        <asp:TextBox ID="txtAuthorisationDate" runat="server" TextMode="Date" CssClass="form-control"></asp:TextBox>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </asp:Panel>
                    <!-- ================= BUTTONS ================= -->
                    <div class="button-area">
                        <asp:Button ID="btnCancel" runat="server" Text="Cancel" CssClass="btn btn-secondary" OnClick="btnCancel_Click" />
                        <asp:Button ID="btnSave" runat="server" Text="Save Document" CssClass="btn btn-primary" OnClick="btnSave_Click" />
                        <asp:Button ID="btnGenerate" runat="server" Text="Save & Generate Document" CssClass="btn btn-primary" OnClick="btnGenerate_Click" />
                    </div>
                </div>
            </div>
            <!-- FOOTER -->
            <footer class="footer">
                &copy; 2026 IT Assets Management System. All rights reserved by S.N Nkuna.
            </footer>
        </section>
    </main>
</div>
</form>
</body>
</html>