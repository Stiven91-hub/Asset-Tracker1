﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="EmployeeDetails.aspx.cs" Inherits="Assets_Tracker.EmployeeDetails" %>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title>Employee Details - IT Assets Management System</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" />
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, Helvetica, sans-serif;
        }
        body {
            background: #f4f6fb;
            color: #333;
        }
        /* ================= SIDEBAR ================= */
        .dashboard-container {
            display: flex;
            min-height: 100vh;
        }
        .sidebar {
            width: 260px;
            min-height: 100vh;
            background: linear-gradient(180deg, #0f5c4d, #123a5c);
            color: white;
            position: fixed;
            left: 0;
            top: 0;
            bottom: 0;
            padding: 20px 15px;
        }
        .logo {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 10px 8px 25px;
            border-bottom: 1px solid rgba(255,255,255,0.15);
        }
        .logo-icon {
            width: 45px;
            height: 45px;
            background: rgba(255,255,255,0.15);
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 22px;
        }
        .logo-text {
            font-size: 15px;
            font-weight: bold;
            line-height: 20px;
        }
        .logo-text span {
            display: block;
            font-size: 12px;
            font-weight: normal;
            opacity: 0.8;
        }
        .navigation {
            margin-top: 25px;
        }
        .nav-item {
            display: flex;
            align-items: center;
            gap: 13px;
            color: white;
            text-decoration: none;
            padding: 13px 15px;
            margin-bottom: 6px;
            border-radius: 8px;
            font-size: 14px;
            transition: 0.2s;
        }
        .nav-item i {
            font-size: 18px;
        }
        .nav-item:hover {
            background: rgba(255,255,255,0.12);
        }
        .nav-item.active {
            background: linear-gradient(90deg, #2563c7, #3f7bd7);
        }
        .logout {
            position: absolute;
            bottom: 20px;
            left: 15px;
            right: 15px;
        }
        /* ================= MAIN ================= */
        .main-content {
            margin-left: 260px;
            width: calc(100% - 260px);
            min-height: 100vh;
        }
        /* ================= TOPBAR ================= */
        .topbar {
            height: 75px;
            background: white;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 30px;
            border-bottom: 1px solid #e5e7eb;
        }
        .topbar-left {
            display: flex;
            align-items: center;
            gap: 18px;
        }
        .menu-button {
            width: 40px;
            height: 40px;
            border-radius: 8px;
            background: #f1f5f9;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 22px;
            color: #334155;
        }
        .page-title {
            font-size: 20px;
            font-weight: bold;
            color: #1e293b;
        }
        .topbar-right {
            display: flex;
            align-items: center;
            gap: 25px;
        }
        .notifications {
            position: relative;
            font-size: 21px;
            color: #475569;
        }
        .notification-badge {
            position: absolute;
            top: -2px;
            right: -3px;
            width: 8px;
            height: 8px;
            background: #ef4444;
            border-radius: 50%;
        }
        .profile {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .profile-icon {
            width: 40px;
            height: 40px;
            background: #e8eef8;
            color: #2563c7;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .profile-info strong {
            display: block;
            font-size: 14px;
            color: #1e293b;
        }
        .profile-info span {
            display: block;
            font-size: 12px;
            color: #64748b;
            margin-top: 2px;
        }
        /* ================= CONTENT ================= */
        .content {
            padding: 30px;
        }
        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
        }
        .heading h1 {
            font-size: 27px;
            color: #1e293b;
            margin-bottom: 6px;
        }
        .heading p {
            color: #64748b;
            font-size: 14px;
        }
        .back-button {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 11px 18px;
            background: #64748b;
            color: white;
            text-decoration: none;
            border-radius: 7px;
            font-size: 14px;
        }
        .back-button:hover {
            background: #475569;
        }
        /* ================= PROFILE CARD ================= */
        .profile-card {
            background: white;
            border-radius: 12px;
            box-shadow: 0 3px 12px rgba(0,0,0,0.06);
            overflow: hidden;
            margin-bottom: 25px;
        }
        .profile-header {
            padding: 25px 30px;
            background: linear-gradient(90deg, #0f5c4d, #123a5c);
            color: white;
            display: flex;
            align-items: center;
            gap: 20px;
        }
        .profile-avatar {
            width: 75px;
            height: 75px;
            background: rgba(255,255,255,0.18);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 35px;
        }
        .profile-header-info h2 {
            font-size: 23px;
            margin-bottom: 5px;
        }
        .profile-header-info p {
            font-size: 13px;
            opacity: 0.85;
        }
        /* ================= DETAILS ================= */
        .details-section {
            padding: 28px 30px;
        }
        .section-title {
            font-size: 17px;
            font-weight: bold;
            color: #123a5c;
            padding-bottom: 12px;
            border-bottom: 1px solid #e5e7eb;
            margin-bottom: 22px;
        }
        .details-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 20px;
        }
        .detail-box {
            background: #f8fafc;
            border: 1px solid #e2e8f0;
            border-radius: 8px;
            padding: 16px;
        }
        .detail-label {
            display: block;
            color: #64748b;
            font-size: 12px;
            margin-bottom: 7px;
        }
        .detail-value {
            display: block;
            color: #1e293b;
            font-size: 14px;
            font-weight: bold;
        }
        /* ================= ASSETS ================= */
        .assets-section {
            background: white;
            border-radius: 12px;
            box-shadow: 0 3px 12px rgba(0,0,0,0.06);
            overflow: hidden;
        }
        .assets-header {
            padding: 20px 25px;
            border-bottom: 1px solid #e5e7eb;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        .assets-header-icon {
            width: 40px;
            height: 40px;
            background: #e8f0ff;
            color: #2563c7;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
        }
        .assets-header h2 {
            font-size: 18px;
            color: #1e293b;
        }
        .assets-header p {
            font-size: 13px;
            color: #64748b;
            margin-top: 3px;
        }
        .table-container {
            overflow-x: auto;
        }
        .asset-table {
            width: 100%;
            border-collapse: collapse;
        }
        .asset-table th {
            text-align: left;
            padding: 14px 18px;
            background: #f8fafc;
            color: #475569;
            font-size: 12px;
            border-bottom: 1px solid #e5e7eb;
        }
        .asset-table td {
            padding: 15px 18px;
            color: #334155;
            font-size: 13px;
            border-bottom: 1px solid #f1f5f9;
        }
        .asset-table tr:hover {
            background: #f8fafc;
        }
        .status-badge {
            display: inline-block;
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 11px;
            font-weight: bold;
            background: #dcfce7;
            color: #166534;
        }
        .no-assets {
            padding: 35px;
            text-align: center;
            color: #64748b;
            font-size: 14px;
        }
        /* ================= MESSAGE ================= */
        .message {
            display: block;
            padding: 13px 16px;
            border-radius: 7px;
            margin-bottom: 20px;
            font-size: 13px;
        }
        /* ================= BUTTONS ================= */
        .actions {
            display: flex;
            justify-content: flex-end;
            gap: 10px;
            padding: 20px 25px;
            border-top: 1px solid #e5e7eb;
        }
        .btn {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 10px 18px;
            border-radius: 7px;
            text-decoration: none;
            border: none;
            font-size: 13px;
            font-weight: bold;
            cursor: pointer;
        }
        .btn-primary {
            background: linear-gradient(90deg, #2563c7, #3b82f6);
            color: white;
        }
        .btn-primary:hover {
            opacity: 0.9;
        }
        .btn-secondary {
            background: #e2e8f0;
            color: #334155;
        }
        .btn-secondary:hover {
            background: #cbd5e1;
        }
        /* ================= FOOTER ================= */
        .footer {
            margin-top: 30px;
            padding: 20px 0;
            text-align: center;
            color: #94a3b8;
            font-size: 12px;
        }
        /* ================= RESPONSIVE ================= */
        @media(max-width: 900px) {
            .sidebar {
                width: 220px;
            }
            .main-content {
                margin-left: 220px;
                width: calc(100% - 220px);
            }
            .details-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
<form id="form1" runat="server">
<div class="dashboard-container">
    <!-- ================= SIDEBAR ================= -->
    <aside class="sidebar">
        <div class="logo">
            <div class="logo-icon">
                <i class="bi bi-display"></i>
            </div>
            <div class="logo-text">
                IT Assets Management System
                <span>System</span>
            </div>
        </div>
        <nav class="navigation">
            <a href="Dashboard.aspx" class="nav-item">
                <i class="bi bi-grid"></i>
                Dashboard
            </a>
            <a href="Users.aspx" class="nav-item active">
                <i class="bi bi-people"></i>
                Users
            </a>
            <a href="Assets.aspx" class="nav-item">
                <i class="bi bi-laptop"></i>
                Assets
            </a>
            <a href="AssetAssignments.aspx" class="nav-item">
                <i class="bi bi-person-check"></i>
                Asset Assignments
            </a>
            <a href="Returns.aspx" class="nav-item">
                <i class="bi bi-arrow-return-left"></i>
                Returns
            </a>
            <a href="Documents.aspx" class="nav-item">
                <i class="bi bi-file-earmark-text"></i>
                Documents
            </a>
            <a href="Reports.aspx" class="nav-item">
                <i class="bi bi-bar-chart"></i>
                Reports
            </a>
            <a href="AuditLogs.aspx" class="nav-item">
                <i class="bi bi-shield-check"></i>
                Audit Logs
            </a>
        </nav>
        <div class="logout">
            <a href="LoginPage.aspx" class="nav-item">
                <i class="bi bi-box-arrow-left"></i>
                Logout
            </a>
        </div>
    </aside>
    <!-- ================= MAIN ================= -->
    <main class="main-content">
        <!-- TOPBAR -->
        <header class="topbar">
            <div class="topbar-left">
                <div class="menu-button">
                    <i class="bi bi-list"></i>
                </div>
                <div class="page-title">
                    Employee Details
                </div>
            </div>
            <div class="topbar-right">
                <div class="notifications">
                    <i class="bi bi-bell"></i>
                    <span class="notification-badge"></span>
                </div>
                <div class="profile">
                    <div class="profile-icon">
                        <i class="bi bi-person-fill"></i>
                    </div>
                    <div class="profile-info">
                        <strong>
                            <asp:Label ID="lblAdminName" runat="server" Text="Administrator"></asp:Label>
                        </strong>
                        <span>
                            <asp:Label ID="lblAdminRole" runat="server" Text="IT Administrator"></asp:Label>
                        </span>
                    </div>
                    <i class="bi bi-chevron-down"></i>
                </div>
            </div>
        </header>
        <!-- ================= PAGE CONTENT ================= -->
        <section class="content">
            <div class="page-header">
                <div class="heading">
                    <h1>Employee Details</h1>
                    <p>
                        View employee information and assigned IT assets
                    </p>
                </div>
                <a href="Users.aspx" class="back-button">
                    <i class="bi bi-arrow-left"></i>
                    Back to Users
                </a>
            </div>
            <asp:Label ID="lblMessage" runat="server" CssClass="message"></asp:Label>
            <!-- ================= EMPLOYEE PROFILE ================= -->
            <div class="profile-card">
                <div class="profile-header">
                    <div class="profile-avatar">
                        <i class="bi bi-person-fill"></i>
                    </div>
                    <div class="profile-header-info">
                        <h2>
                            <asp:Label ID="lblFullName" runat="server" Text="Employee Name"></asp:Label>
                        </h2>
                        <p>
                            <asp:Label ID="lblEmployeeNumberHeader" runat="server"></asp:Label>
                        </p>
                    </div>
                </div>
                <div class="details-section">
                    <div class="section-title">
                        <i class="bi bi-person-vcard"></i>
                        Employee Information
                    </div>
                    <div class="details-grid">
                        <div class="detail-box">
                            <span class="detail-label">
                                Employee Number
                            </span>
                            <asp:Label ID="lblEmployeeNumber" runat="server" CssClass="detail-value"></asp:Label>
                        </div>
                        <div class="detail-box">
                            <span class="detail-label">
                                Employee ID
                            </span>
                            <asp:Label ID="lblEmployeeID" runat="server" CssClass="detail-value"></asp:Label>
                        </div>
                        <div class="detail-box">
                            <span class="detail-label">
                                First Name
                            </span>
                            <asp:Label ID="lblFirstName" runat="server" CssClass="detail-value"></asp:Label>
                        </div>
                        <div class="detail-box">
                            <span class="detail-label">
                                Last Name
                            </span>
                            <asp:Label ID="lblLastName" runat="server" CssClass="detail-value"></asp:Label>
                        </div>
                        <div class="detail-box">
                            <span class="detail-label">
                                Email Address
                            </span>
                            <asp:Label ID="lblEmail" runat="server" CssClass="detail-value"></asp:Label>
                        </div>
                        <div class="detail-box">
                            <span class="detail-label">
                                Phone Number
                            </span>
                            <asp:Label ID="lblPhoneNumber" runat="server" CssClass="detail-value"></asp:Label>
                        </div>
                        <div class="detail-box">
                            <span class="detail-label">
                                Job Title
                            </span>
                            <asp:Label ID="lblJobTitle" runat="server" CssClass="detail-value"></asp:Label>
                        </div>
                    </div>
                </div>
                <div class="actions">
                    <asp:Button ID="btnEditEmployee" runat="server" Text="Edit Employee" CssClass="btn btn-primary" OnClick="btnEditEmployee_Click" />
                </div>
            </div>
            <!-- ================= ASSIGNED ASSETS ================= -->
            <div class="assets-section">
                <div class="assets-header">
                    <div class="assets-header-icon">
                        <i class="bi bi-laptop"></i>
                    </div>
                    <div>
                        <h2>Assigned Assets</h2>
                        <p>
                            IT assets currently assigned to this employee
                        </p>
                    </div>
                </div>
                <div class="table-container">
                    <asp:GridView ID="gvAssignedAssets" runat="server" AutoGenerateColumns="False" CssClass="asset-table" GridLines="None" EmptyDataText="No assets are currently assigned to this employee.">
                        <Columns>
                            <asp:BoundField DataField="AssetTag" HeaderText="Asset Tag" />
                            <asp:BoundField DataField="AssetType" HeaderText="Asset Type" />
                            <asp:BoundField DataField="Make" HeaderText="Make" />
                            <asp:BoundField DataField="SerialNumber" HeaderText="Serial Number" />
                            <asp:BoundField DataField="AllocationDate" HeaderText="Assigned Date" DataFormatString="{0:dd/MM/yyyy}" />
                            <asp:TemplateField HeaderText="Status">
                                <ItemTemplate>
                                    <span class="status-badge">
                                        <%# Eval("Status") %>
                                    </span>
                                </ItemTemplate>
                            </asp:TemplateField>
                        </Columns>
                    </asp:GridView>
                </div>
            </div>
            <div class="footer">
                &copy; 2026 IT Assets Management System.
                All rights reserved by S.N Nkuna.
            </div>
        </section>
    </main>
</div>
</form>
</body>
</html>