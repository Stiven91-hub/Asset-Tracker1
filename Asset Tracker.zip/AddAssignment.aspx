﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="AddAssignment.aspx.cs" Inherits="Assets_Tracker.AddAssignment" %>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title>Add Asset Assignment - IT Assets Management System</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" />
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, Helvetica, sans-serif;
        }
        body {
            background: #f4f6f9;
            color: #24344d;
        }
        /* ================= SIDEBAR ================= */
        .dashboard-container {
            display: flex;
            min-height: 100vh;
        }
        .sidebar {
            width: 265px;
            background: linear-gradient(180deg, #0d5c50, #123b5d);
            color: white;
            display: flex;
            flex-direction: column;
            position: fixed;
            height: 100vh;
            left: 0;
            top: 0;
        }
        .logo {
            display: flex;
            align-items: center;
            gap: 14px;
            padding: 24px 20px;
            border-bottom: 1px solid rgba(255,255,255,0.12);
        }
        .logo-icon {
            width: 48px;
            height: 48px;
            border: 2px solid rgba(255,255,255,0.7);
            border-radius: 12px;
            display: flex;
            justify-content: center;
            align-items: center;
            font-size: 24px;
        }
        .logo-text {
            font-size: 18px;
            font-weight: 700;
            line-height: 1.3;
        }
        .logo-text span {
            display: block;
            font-weight: 400;
            margin-top: 2px;
        }
        .navigation {
            padding: 20px 12px;
            flex: 1;
        }
        .nav-item {
            display: flex;
            align-items: center;
            gap: 16px;
            padding: 15px 18px;
            margin-bottom: 8px;
            text-decoration: none;
            color: rgba(255,255,255,0.85);
            border-radius: 10px;
            font-size: 16px;
            transition: 0.3s;
        }
        .nav-item:hover {
            background: rgba(255,255,255,0.08);
            color: white;
        }
        .nav-item.active {
            background: linear-gradient(90deg, #2768c7, #3979d1);
            color: white;
            box-shadow: 0 5px 15px rgba(0,0,0,0.15);
        }
        .nav-item i {
            font-size: 20px;
        }
        .logout {
            padding: 18px 12px;
            border-top: 1px solid rgba(255,255,255,0.12);
        }
        /* ================= MAIN CONTENT ================= */
        .main-content {
            margin-left: 265px;
            width: calc(100% - 265px);
        }
        /* ================= TOPBAR ================= */
        .topbar {
            height: 82px;
            background: white;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0 38px;
            border-bottom: 1px solid #e5e7eb;
        }
        .topbar-left {
            display: flex;
            align-items: center;
            gap: 25px;
        }
        .menu-button {
            font-size: 25px;
            cursor: pointer;
        }
        .page-title {
            font-size: 24px;
            font-weight: 700;
        }
        .topbar-right {
            display: flex;
            align-items: center;
            gap: 28px;
        }
        .notifications {
            position: relative;
            font-size: 21px;
        }
        .notification-badge {
            position: absolute;
            width: 8px;
            height: 8px;
            background: #e53935;
            border-radius: 50%;
            right: -2px;
            top: -2px;
        }
        .profile {
            display: flex;
            align-items: center;
            gap: 12px;
        }
        .profile-icon {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            background: #eef3fb;
            color: #2463b8;
            display: flex;
            justify-content: center;
            align-items: center;
            font-size: 22px;
        }
        .profile-info {
            display: flex;
            flex-direction: column;
            font-size: 14px;
        }
        .profile-info span {
            color: #718096;
            margin-top: 4px;
        }
        /* ================= CONTENT ================= */
        .content {
            padding: 40px;
        }
        .page-header {
            margin-bottom: 30px;
        }
        .page-header h1 {
            font-size: 30px;
            margin-bottom: 8px;
        }
        .page-header p {
            color: #718096;
            font-size: 16px;
        }
        /* ================= MESSAGE ================= */
        .message-container {
            margin-bottom: 20px;
        }
        .success-message {
            display: block;
            background: #dcfce7;
            color: #15803d;
            border: 1px solid #86efac;
            padding: 14px 18px;
            border-radius: 10px;
            font-weight: 500;
        }
        .error-message {
            display: block;
            background: #fee2e2;
            color: #b91c1c;
            border: 1px solid #fca5a5;
            padding: 14px 18px;
            border-radius: 10px;
            font-weight: 500;
        }
        /* ================= FORM CARD ================= */
        .form-card {
            background: white;
            border-radius: 14px;
            border: 1px solid #e1e7ef;
            box-shadow: 0 5px 20px rgba(0,0,0,0.04);
            overflow: hidden;
        }
        .form-card-header {
            padding: 22px 30px;
            border-bottom: 1px solid #e8edf3;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        .form-card-header i {
            color: #2768c7;
            font-size: 23px;
        }
        .form-card-header h2 {
            font-size: 20px;
        }
        .form-card-body {
            padding: 35px;
        }
        /* ================= FORM ================= */
        .form-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 25px;
        }
        .form-group {
            display: flex;
            flex-direction: column;
        }
        .form-group.full-width {
            grid-column: span 2;
        }
        .form-group label {
            font-size: 14px;
            font-weight: 600;
            margin-bottom: 9px;
            color: #34445d;
        }
        .required {
            color: #e53935;
        }
        .form-control {
            width: 100%;
            padding: 13px 15px;
            border: 1px solid #d9e0e8;
            border-radius: 8px;
            font-size: 15px;
            outline: none;
            color: #34445d;
            transition: 0.2s;
        }
        .form-control:focus {
            border-color: #2768c7;
            box-shadow: 0 0 0 3px rgba(39,104,199,0.1);
        }
        textarea.form-control {
            resize: vertical;
            min-height: 110px;
        }
        /* ================= INFO BOX ================= */
        .info-box {
            margin-top: 28px;
            background: #eff6ff;
            border: 1px solid #bfdbfe;
            border-radius: 10px;
            padding: 18px;
            display: flex;
            gap: 13px;
            align-items: flex-start;
        }
        .info-box i {
            color: #2563eb;
            font-size: 20px;
        }
        .info-box h4 {
            margin-bottom: 5px;
            color: #1e40af;
        }
        .info-box p {
            color: #47617f;
            font-size: 14px;
            line-height: 1.5;
        }
        /* ================= BUTTONS ================= */
        .form-actions {
            margin-top: 35px;
            padding-top: 25px;
            border-top: 1px solid #e8edf3;
            display: flex;
            justify-content: flex-end;
            gap: 15px;
        }
        .btn {
            border: none;
            padding: 13px 24px;
            border-radius: 8px;
            font-size: 15px;
            font-weight: 600;
            cursor: pointer;
            transition: 0.3s;
            text-decoration: none;
        }
        .btn-cancel {
            background: #f1f3f5;
            color: #4b5563;
        }
        .btn-cancel:hover {
            background: #e5e7eb;
        }
        .btn-save {
            background: linear-gradient(90deg, #2768c7, #3979d1);
            color: white;
        }
        .btn-save:hover {
            opacity: 0.9;
            transform: translateY(-1px);
        }
        /* ================= FOOTER ================= */
        .footer {
            text-align: center;
            color: #7a8798;
            padding: 30px 0 10px;
            font-size: 14px;
        }
        /* ================= RESPONSIVE ================= */
        @media(max-width: 1000px) {
            .sidebar {
                width: 220px;
            }
            .main-content {
                margin-left: 220px;
                width: calc(100% - 220px);
            }
        }
        @media(max-width: 768px) {
            .sidebar {
                display: none;
            }
            .main-content {
                margin-left: 0;
                width: 100%;
            }
            .form-grid {
                grid-template-columns: 1fr;
            }
            .form-group.full-width {
                grid-column: span 1;
            }
            .content {
                padding: 20px;
            }
        }
    </style>
</head>
<body>
<form id="form1" runat="server">
    <div class="dashboard-container">
        <!-- ================= SIDEBAR ================= -->
        <aside class="sidebar">
            <div class="logo">
                <div class="logo-icon">
                    <i class="bi bi-display"></i>
                </div>
                <div class="logo-text">
                    IT Assets Management
                    <span>System</span>
                </div>
            </div>
            <nav class="navigation">
                <a href="Dashboard.aspx" class="nav-item">
                    <i class="bi bi-grid"></i>
                    Dashboard
                </a>
                <a href="Users.aspx" class="nav-item">
                    <i class="bi bi-person"></i>
                    Users
                </a>
                <a href="Assets.aspx" class="nav-item">
                    <i class="bi bi-laptop"></i>
                    Assets
                </a>
                <a href="AssetAssignments.aspx" class="nav-item active">
                    <i class="bi bi-person-check"></i>
                    Asset Assignments
                </a>
                <a href="Returns.aspx" class="nav-item">
                    <i class="bi bi-arrow-return-left"></i>
                    Returns
                </a>
                <a href="Documents.aspx" class="nav-item">
                    <i class="bi bi-file-earmark-text"></i>
                    Documents
                </a>
                <a href="Reports.aspx" class="nav-item">
                    <i class="bi bi-bar-chart"></i>
                    Reports
                </a>
                <a href="AuditLogs.aspx" class="nav-item">
                    <i class="bi bi-shield-check"></i>
                    Audit Logs
                </a>
            </nav>
            <div class="logout">
                <a href="Login.aspx" class="nav-item">
                    <i class="bi bi-box-arrow-left"></i>
                    Logout
                </a>
            </div>
        </aside>
        <!-- ================= MAIN CONTENT ================= -->
        <main class="main-content">
            <!-- TOPBAR -->
            <header class="topbar">
                <div class="topbar-left">
                    <div class="menu-button">
                        <i class="bi bi-list"></i>
                    </div>
                    <div class="page-title">
                        Add Asset Assignment
                    </div>
                </div>
                <div class="topbar-right">
                    <div class="notifications">
                        <i class="bi bi-bell"></i>
                        <span class="notification-badge"></span>
                    </div>
                    <div class="profile">
                        <div class="profile-icon">
                            <i class="bi bi-person-fill"></i>
                        </div>
                        <div class="profile-info">
                            <strong>
                                <asp:Label ID="lblAdminName" runat="server" Text="Administrator"></asp:Label>
                            </strong>
                            <span>
                                <asp:Label ID="lblAdminRole" runat="server" Text="IT Administrator"></asp:Label>
                            </span>
                        </div>
                        <i class="bi bi-chevron-down"></i>
                    </div>
                </div>
            </header>
            <!-- ================= CONTENT ================= -->
            <section class="content">
                <!-- PAGE HEADER -->
                <div class="page-header">
                    <h1>Assign Asset</h1>
                    <p>Assign an available IT asset to an employee.</p>
                </div>
                <!-- MESSAGE -->
                <div class="message-container">
                    <asp:Label ID="lblMessage" runat="server" Visible="false"></asp:Label>
                </div>
                <!-- FORM CARD -->
                <div class="form-card">
                    <div class="form-card-header">
                        <i class="bi bi-person-check"></i>
                        <h2>Assignment Information</h2>
                    </div>
                    <div class="form-card-body">
                        <div class="form-grid">
                            <!-- EMPLOYEE -->
                            <div class="form-group">
                                <label>
                                    Select Employee
                                    <span class="required">*</span>
                                </label>
                                <asp:DropDownList ID="ddlEmployee" runat="server" CssClass="form-control">
                                    <asp:ListItem Text="-- Select Employee --" Value=""></asp:ListItem>
                                </asp:DropDownList>
                            </div>
                            <!-- ASSET -->
                            <div class="form-group">
                                <label>
                                    Select Available Asset
                                    <span class="required">*</span>
                                </label>
                                <asp:DropDownList ID="ddlAsset" runat="server" CssClass="form-control">
                                    <asp:ListItem Text="-- Select Asset --" Value=""></asp:ListItem>
                                </asp:DropDownList>
                            </div>
                            <!-- ALLOCATION DATE -->
                            <div class="form-group">
                                <label>
                                    Allocation Date
                                    <span class="required">*</span>
                                </label>
                                <asp:TextBox ID="txtAllocationDate" runat="server" CssClass="form-control" TextMode="Date"></asp:TextBox>
                            </div>
                            <!-- EXPECTED RETURN DATE -->
                            <div class="form-group">
                                <label>
                                    Expected Return Date
                                </label>
                                <asp:TextBox ID="txtExpectedReturnDate" runat="server" CssClass="form-control" TextMode="Date"></asp:TextBox>
                            </div>
                            <!-- NOTES -->
                            <div class="form-group full-width">
                                <label>
                                    Assignment Notes
                                </label>
                                <asp:TextBox ID="txtNotes" runat="server" CssClass="form-control" TextMode="MultiLine" placeholder="Enter any additional notes about this asset assignment..."></asp:TextBox>
                            </div>
                        </div>
                        <!-- INFORMATION BOX -->
                        <div class="info-box">
                            <i class="bi bi-info-circle"></i>
                            <div>
                                <h4>Asset Assignment Information</h4>
                                <p>Once an asset is assigned to an employee, it will no longer appear in the available assets list until it is returned.</p>
                            </div>
                        </div>
                        <!-- BUTTONS -->
                        <div class="form-actions">
                            <asp:Button ID="btnCancel" runat="server" Text="Cancel" CssClass="btn btn-cancel" CausesValidation="false" OnClick="btnCancel_Click" />
                            <asp:Button ID="btnSaveAssignment" runat="server" Text="Assign Asset" CssClass="btn btn-save" OnClick="btnSaveAssignment_Click" />
                        </div>
                    </div>
                </div>
                <!-- FOOTER -->
                <footer class="footer">
                    &copy; 2026 IT Assets Management System. All rights reserved by S.N Nkuna.
                </footer>
            </section>
        </main>
    </div>
</form>
</body>
</html>