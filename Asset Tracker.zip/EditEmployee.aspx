﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="EditEmployee.aspx.cs" Inherits="Assets_Tracker.EditEmployee" %>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title>Edit Employee - IT Assets Management System</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" />
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, Helvetica, sans-serif;
        }
        body {
            background: #f4f6fb;
            color: #333;
        }
        /* ================= SIDEBAR ================= */
        .dashboard-container {
            display: flex;
            min-height: 100vh;
        }
        .sidebar {
            width: 260px;
            min-height: 100vh;
            background: linear-gradient(180deg, #0f5c4d, #123a5c);
            color: white;
            position: fixed;
            left: 0;
            top: 0;
            bottom: 0;
            padding: 20px 15px;
        }
        .logo {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 10px 8px 25px;
            border-bottom: 1px solid rgba(255,255,255,0.15);
        }
        .logo-icon {
            width: 45px;
            height: 45px;
            background: rgba(255,255,255,0.15);
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 22px;
        }
        .logo-text {
            font-size: 15px;
            font-weight: bold;
            line-height: 20px;
        }
        .logo-text span {
            display: block;
            font-size: 12px;
            font-weight: normal;
            opacity: 0.8;
        }
        .navigation {
            margin-top: 25px;
        }
        .nav-item {
            display: flex;
            align-items: center;
            gap: 13px;
            color: white;
            text-decoration: none;
            padding: 13px 15px;
            margin-bottom: 6px;
            border-radius: 8px;
            font-size: 14px;
            transition: 0.2s;
        }
        .nav-item i {
            font-size: 18px;
        }
        .nav-item:hover {
            background: rgba(255,255,255,0.12);
        }
        .nav-item.active {
            background: linear-gradient(90deg, #2563c7, #3f7bd7);
        }
        .logout {
            position: absolute;
            bottom: 20px;
            left: 15px;
            right: 15px;
        }
        /* ================= MAIN ================= */
        .main-content {
            margin-left: 260px;
            width: calc(100% - 260px);
            min-height: 100vh;
        }
        /* ================= TOPBAR ================= */
        .topbar {
            height: 75px;
            background: white;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 30px;
            border-bottom: 1px solid #e5e7eb;
        }
        .topbar-left {
            display: flex;
            align-items: center;
            gap: 18px;
        }
        .menu-button {
            width: 40px;
            height: 40px;
            border-radius: 8px;
            background: #f1f5f9;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 22px;
            color: #334155;
        }
        .page-title {
            font-size: 20px;
            font-weight: bold;
            color: #1e293b;
        }
        .topbar-right {
            display: flex;
            align-items: center;
            gap: 25px;
        }
        .notifications {
            position: relative;
            font-size: 21px;
            color: #475569;
        }
        .notification-badge {
            position: absolute;
            top: -2px;
            right: -3px;
            width: 8px;
            height: 8px;
            background: #ef4444;
            border-radius: 50%;
        }
        .profile {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .profile-icon {
            width: 40px;
            height: 40px;
            background: #e8eef8;
            color: #2563c7;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .profile-info strong {
            display: block;
            font-size: 14px;
            color: #1e293b;
        }
        .profile-info span {
            display: block;
            font-size: 12px;
            color: #64748b;
            margin-top: 2px;
        }
        /* ================= CONTENT ================= */
        .content {
            padding: 30px;
        }
        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
        }
        .heading h1 {
            font-size: 27px;
            color: #1e293b;
            margin-bottom: 6px;
        }
        .heading p {
            color: #64748b;
            font-size: 14px;
        }
        .back-button {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 11px 18px;
            background: #64748b;
            color: white;
            text-decoration: none;
            border-radius: 7px;
            font-size: 14px;
        }
        .back-button:hover {
            background: #475569;
        }
        /* ================= FORM CARD ================= */
        .form-card {
            background: white;
            border-radius: 12px;
            box-shadow: 0 3px 12px rgba(0,0,0,0.06);
            overflow: hidden;
        }
        .form-card-header {
            background: linear-gradient(90deg, #0f5c4d, #123a5c);
            color: white;
            padding: 24px 30px;
            display: flex;
            align-items: center;
            gap: 15px;
        }
        .form-card-header-icon {
            width: 48px;
            height: 48px;
            border-radius: 10px;
            background: rgba(255,255,255,0.16);
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 23px;
        }
        .form-card-header h2 {
            font-size: 20px;
            margin-bottom: 4px;
        }
        .form-card-header p {
            font-size: 13px;
            opacity: 0.85;
        }
        /* ================= FORM ================= */
        .form-body {
            padding: 30px;
        }
        .section-title {
            display: flex;
            align-items: center;
            gap: 9px;
            color: #123a5c;
            font-size: 17px;
            font-weight: bold;
            padding-bottom: 12px;
            border-bottom: 1px solid #e5e7eb;
            margin-bottom: 25px;
        }
        .section-title i {
            color: #2563c7;
            font-size: 19px;
        }
        .form-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 22px;
        }
        .form-group {
            display: flex;
            flex-direction: column;
        }
        .form-group.full-width {
            grid-column: 1 / -1;
        }
        .form-label {
            font-size: 13px;
            font-weight: bold;
            color: #334155;
            margin-bottom: 8px;
        }
        .required {
            color: #dc2626;
        }
        .form-control {
            width: 100%;
            height: 44px;
            padding: 10px 13px;
            border: 1px solid #cbd5e1;
            border-radius: 7px;
            background: white;
            color: #1e293b;
            font-size: 14px;
            outline: none;
            transition: 0.2s;
        }
        .form-control:focus {
            border-color: #2563c7;
            box-shadow: 0 0 0 3px rgba(37,99,199,0.10);
        }
        .form-control.readonly {
            background: #f1f5f9;
            color: #64748b;
            cursor: not-allowed;
        }
        .help-text {
            margin-top: 6px;
            color: #64748b;
            font-size: 11px;
        }
        /* ================= MESSAGE ================= */
        .message {
            display: block;
            padding: 13px 16px;
            border-radius: 7px;
            margin-bottom: 20px;
            font-size: 13px;
        }
        .success-message {
            background: #dcfce7;
            color: #166534;
            border: 1px solid #bbf7d0;
        }
        .error-message {
            background: #fee2e2;
            color: #991b1b;
            border: 1px solid #fecaca;
        }
        /* ================= BUTTONS ================= */
        .form-actions {
            margin-top: 30px;
            padding-top: 22px;
            border-top: 1px solid #e5e7eb;
            display: flex;
            justify-content: flex-end;
            gap: 12px;
        }
        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            min-width: 125px;
            height: 43px;
            padding: 0 18px;
            border-radius: 7px;
            border: none;
            font-size: 13px;
            font-weight: bold;
            cursor: pointer;
            text-decoration: none;
        }
        .btn-primary {
            background: linear-gradient(90deg, #2563c7, #3b82f6);
            color: white;
        }
        .btn-primary:hover {
            opacity: 0.9;
        }
        .btn-secondary {
            background: #e2e8f0;
            color: #334155;
        }
        .btn-secondary:hover {
            background: #cbd5e1;
        }
        /* ================= FOOTER ================= */
        .footer {
            margin-top: 30px;
            padding: 20px 0;
            text-align: center;
            color: #94a3b8;
            font-size: 12px;
        }
        /* ================= RESPONSIVE ================= */
        @media(max-width: 900px) {
            .sidebar {
                width: 220px;
            }
            .main-content {
                margin-left: 220px;
                width: calc(100% - 220px);
            }
            .form-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
<form id="form1" runat="server">
    <div class="dashboard-container">
        <!-- ================= SIDEBAR ================= -->
        <aside class="sidebar">
            <div class="logo">
                <div class="logo-icon">
                    <i class="bi bi-display"></i>
                </div>
                <div class="logo-text">
                    IT Assets Management System
                    <span>System</span>
                </div>
            </div>
            <nav class="navigation">
                <a href="Dashboard.aspx" class="nav-item">
                    <i class="bi bi-grid"></i>
                    Dashboard
                </a>
                <a href="Users.aspx" class="nav-item active">
                    <i class="bi bi-people"></i>
                    Users
                </a>
                <a href="Assets.aspx" class="nav-item">
                    <i class="bi bi-laptop"></i>
                    Assets
                </a>
                <a href="AssetAssignments.aspx" class="nav-item">
                    <i class="bi bi-person-check"></i>
                    Asset Assignments
                </a>
                <a href="Returns.aspx" class="nav-item">
                    <i class="bi bi-arrow-return-left"></i>
                    Returns
                </a>
                <a href="Documents.aspx" class="nav-item">
                    <i class="bi bi-file-earmark-text"></i>
                    Documents
                </a>
                <a href="Reports.aspx" class="nav-item">
                    <i class="bi bi-bar-chart"></i>
                    Reports
                </a>
                <a href="AuditLogs.aspx" class="nav-item">
                    <i class="bi bi-shield-check"></i>
                    Audit Logs
                </a>
            </nav>
            <div class="logout">
                <a href="LoginPage.aspx" class="nav-item">
                    <i class="bi bi-box-arrow-left"></i>
                    Logout
                </a>
            </div>
        </aside>
        <!-- ================= MAIN CONTENT ================= -->
        <main class="main-content">
            <!-- ================= TOPBAR ================= -->
            <header class="topbar">
                <div class="topbar-left">
                    <div class="menu-button">
                        <i class="bi bi-list"></i>
                    </div>
                    <div class="page-title">
                        Edit Employee
                    </div>
                </div>
                <div class="topbar-right">
                    <div class="notifications">
                        <i class="bi bi-bell"></i>
                        <span class="notification-badge"></span>
                    </div>
                    <div class="profile">
                        <div class="profile-icon">
                            <i class="bi bi-person-fill"></i>
                        </div>
                        <div class="profile-info">
                            <strong>
                                <asp:Label ID="lblAdminName" runat="server" Text="Administrator"></asp:Label>
                            </strong>
                            <span>
                                <asp:Label ID="lblAdminRole" runat="server" Text="IT Administrator"></asp:Label>
                            </span>
                        </div>
                        <i class="bi bi-chevron-down"></i>
                    </div>
                </div>
            </header>
            <!-- ================= CONTENT ================= -->
            <section class="content">
                <div class="page-header">
                    <div class="heading">
                        <h1>Edit Employee</h1>
                        <p>
                            Update the employee information stored in the system
                        </p>
                    </div>
                    <a href="Users.aspx" class="back-button">
                        <i class="bi bi-arrow-left"></i>
                        Back to Users
                    </a>
                </div>
                <!-- MESSAGE -->
                <asp:Label ID="lblMessage" runat="server" CssClass="message"></asp:Label>
                <!-- ================= FORM CARD ================= -->
                <div class="form-card">
                    <div class="form-card-header">
                        <div class="form-card-header-icon">
                            <i class="bi bi-person-gear"></i>
                        </div>
                        <div>
                            <h2>Employee Information</h2>
                            <p>
                                Edit the details below and save your changes.
                            </p>
                        </div>
                    </div>
                    <div class="form-body">
                        <div class="section-title">
                            <i class="bi bi-person-vcard"></i>
                            Personal & Employee Details
                        </div>
                        <div class="form-grid">
                            <!-- EMPLOYEE NUMBER -->
                            <div class="form-group">
                                <label class="form-label">
                                    Employee Number
                                    <span class="required">*</span>
                                </label>
                                <asp:TextBox ID="txtEmployeeNumber" runat="server" CssClass="form-control readonly" ReadOnly="true"></asp:TextBox>
                                <span class="help-text">
                                    Employee Number cannot be changed.
                                </span>
                            </div>
                            <!-- EMPLOYEE ID -->
                            <div class="form-group">
                                <label class="form-label">
                                    Employee ID
                                    <span class="required">*</span>
                                </label>
                                <asp:TextBox ID="txtEmployeeID" runat="server" CssClass="form-control"></asp:TextBox>
                            </div>
                            <!-- FIRST NAME -->
                            <div class="form-group">
                                <label class="form-label">
                                    First Name
                                    <span class="required">*</span>
                                </label>
                                <asp:TextBox ID="txtFirstName" runat="server" CssClass="form-control"></asp:TextBox>
                            </div>
                            <!-- LAST NAME -->
                            <div class="form-group">
                                <label class="form-label">
                                    Last Name
                                    <span class="required">*</span>
                                </label>
                                <asp:TextBox ID="txtLastName" runat="server" CssClass="form-control"></asp:TextBox>
                            </div>
                            <!-- EMAIL -->
                            <div class="form-group">
                                <label class="form-label">
                                    Email Address
                                    <span class="required">*</span>
                                </label>
                                <asp:TextBox ID="txtEmail" runat="server" CssClass="form-control" TextMode="Email"></asp:TextBox>
                            </div>
                            <!-- PHONE -->
                            <div class="form-group">
                                <label class="form-label">
                                    Phone Number
                                </label>
                                <asp:TextBox ID="txtPhoneNumber" runat="server" CssClass="form-control"></asp:TextBox>
                            </div>
                            <!-- JOB TITLE -->
                            <div class="form-group full-width">
                                <label class="form-label">
                                    Job Title
                                </label>
                                <asp:TextBox ID="txtJobTitle" runat="server" CssClass="form-control"></asp:TextBox>
                            </div>
                        </div>
                        <!-- ================= ACTIONS ================= -->
                        <div class="form-actions">
                            <asp:Button ID="btnCancel" runat="server" Text="Cancel" CssClass="btn btn-secondary" OnClick="btnCancel_Click" />
                            <asp:Button ID="btnUpdate" runat="server" Text="Save Changes" CssClass="btn btn-primary" OnClick="btnUpdate_Click" />
                        </div>
                    </div>
                </div>
                <div class="footer">
                    &copy; 2026 IT Assets Management System.
                    All rights reserved by S.N Nkuna.
                </div>
            </section>
        </main>
    </div>
</form>
</body>
</html>