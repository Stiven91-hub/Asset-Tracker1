﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="DeleteAsset.aspx.cs" Inherits="Assets_Tracker.DeleteAsset" %>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title>Delete Asset - IT Asset Management System</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" />
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }
        body {
            font-family: Arial, Helvetica, sans-serif;
            background: #f4f6fb;
            color: #1f2937;
        }
        .sidebar {
            position: fixed;
            left: 0;
            top: 0;
            width: 250px;
            height: 100vh;
            background: linear-gradient(180deg, #0f5c4d, #123a5c);
            color: white;
            padding: 22px 15px;
            z-index: 1000;
        }
        .logo {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 5px 10px 25px 10px;
            font-size: 19px;
            font-weight: bold;
        }
        .logo i {
            font-size: 25px;
        }
        .nav-menu {
            list-style: none;
            margin-top: 15px;
        }
        .nav-menu li {
            margin-bottom: 6px;
        }
        .nav-menu a {
            display: flex;
            align-items: center;
            gap: 13px;
            color: white;
            text-decoration: none;
            padding: 12px 14px;
            border-radius: 8px;
            font-size: 14px;
            transition: 0.2s;
        }
        .nav-menu a:hover {
            background: rgba(255, 255, 255, 0.12);
        }
        .nav-menu a.active {
            background: linear-gradient(90deg, #2563c7, #3f7bd7);
        }
        .nav-menu i {
            font-size: 17px;
            width: 20px;
        }
        .main {
            margin-left: 250px;
            min-height: 100vh;
        }
        .topbar {
            height: 70px;
            background: white;
            border-bottom: 1px solid #e5e7eb;
            display: flex;
            justify-content: flex-end;
            align-items: center;
            padding: 0 30px;
        }
        .admin-info {
            display: flex;
            align-items: center;
            gap: 12px;
        }
        .admin-icon {
            width: 42px;
            height: 42px;
            border-radius: 50%;
            background: #eaf2ff;
            color: #2563c7;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
        }
        .admin-text {
            display: flex;
            flex-direction: column;
            align-items: flex-end;
        }
        .admin-name {
            font-weight: bold;
            font-size: 14px;
        }
        .admin-role {
            color: #6b7280;
            font-size: 12px;
            margin-top: 2px;
        }
        .content {
            padding: 30px;
            max-width: 1050px;
        }
        .page-header {
            margin-bottom: 25px;
        }
        .page-title h1 {
            font-size: 27px;
            color: #1f2937;
            margin-bottom: 7px;
        }
        .page-title p {
            color: #6b7280;
            font-size: 14px;
        }
        .message {
            display: block;
            padding: 13px 16px;
            border-radius: 7px;
            margin-bottom: 20px;
            font-size: 14px;
        }
        .error-message {
            background: #fef2f2;
            color: #b91c1c;
            border: 1px solid #fecaca;
        }
        .warning-card {
            background: #fff;
            border: 1px solid #e5e7eb;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.04);
            overflow: hidden;
        }
        .warning-header {
            background: #fef2f2;
            border-bottom: 1px solid #fecaca;
            padding: 22px 25px;
            display: flex;
            align-items: center;
            gap: 14px;
        }
        .warning-icon {
            width: 48px;
            height: 48px;
            background: #fee2e2;
            color: #dc2626;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 22px;
            flex-shrink: 0;
        }
        .warning-header h2 {
            font-size: 19px;
            color: #991b1b;
            margin-bottom: 4px;
        }
        .warning-header p {
            color: #7f1d1d;
            font-size: 13px;
        }
        .asset-card {
            padding: 25px;
        }
        .asset-title {
            font-size: 17px;
            font-weight: bold;
            margin-bottom: 18px;
            color: #1f2937;
        }
        .details-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            border: 1px solid #e5e7eb;
            border-radius: 8px;
            overflow: hidden;
            margin-bottom: 22px;
        }
        .detail-item {
            padding: 17px 20px;
            border-bottom: 1px solid #e5e7eb;
            background: white;
        }
        .detail-item:nth-child(odd) {
            border-right: 1px solid #e5e7eb;
        }
        .detail-label {
            color: #6b7280;
            font-size: 11px;
            font-weight: 600;
            text-transform: uppercase;
            margin-bottom: 6px;
        }
        .detail-value {
            color: #1f2937;
            font-size: 14px;
            font-weight: 500;
        }
        .asset-tag {
            color: #2563c7;
            font-weight: bold;
        }
        .danger-notice {
            background: #fff7ed;
            border: 1px solid #fed7aa;
            border-radius: 8px;
            padding: 16px;
            display: flex;
            gap: 12px;
            margin-bottom: 22px;
        }
        .danger-notice i {
            color: #ea580c;
            font-size: 19px;
            flex-shrink: 0;
        }
        .danger-notice strong {
            display: block;
            color: #9a3412;
            font-size: 14px;
            margin-bottom: 5px;
        }
        .danger-notice span {
            color: #7c2d12;
            font-size: 13px;
            line-height: 1.5;
        }
        .actions {
            display: flex;
            justify-content: flex-end;
            gap: 10px;
            padding: 20px 25px;
            border-top: 1px solid #e5e7eb;
            background: #fafafa;
        }
        .btn {
            border: none;
            border-radius: 7px;
            padding: 11px 20px;
            font-size: 14px;
            cursor: pointer;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            font-weight: 600;
        }
        .btn-danger {
            background: #dc2626;
            color: white;
        }
        .btn-danger:hover {
            background: #b91c1c;
        }
        .btn-secondary {
            background: white;
            color: #374151;
            border: 1px solid #d1d5db;
        }
        .btn-secondary:hover {
            background: #f9fafb;
        }
        @media (max-width: 800px) {
            .sidebar {
                width: 220px;
            }
            .main {
                margin-left: 220px;
            }
        }
        @media (max-width: 650px) {
            .sidebar {
                position: relative;
                width: 100%;
                height: auto;
            }
            .main {
                margin-left: 0;
            }
            .content {
                padding: 20px;
            }
            .details-grid {
                grid-template-columns: 1fr;
            }
            .detail-item:nth-child(odd) {
                border-right: none;
            }
            .actions {
                flex-direction: column;
            }
            .actions .btn {
                width: 100%;
            }
        }
    </style>
</head>
<body>
    <form id="form1" runat="server">
        <!-- SIDEBAR -->
        <div class="sidebar">
            <div class="logo">
                <i class="bi bi-pc-display"></i>
                <span>IT Assets Management System</span>
            </div>
            <ul class="nav-menu">
                <li>
                    <a href="Dashboard.aspx">
                        <i class="bi bi-speedometer2"></i>
                        <span>Dashboard</span>
                    </a>
                </li>
                <li>
                    <a href="Users.aspx">
                        <i class="bi bi-people"></i>
                        <span>Employees</span>
                    </a>
                </li>
                <li>
                    <a href="Assets.aspx" class="active">
                        <i class="bi bi-laptop"></i>
                        <span>Assets</span>
                    </a>
                </li>
                <li>
                    <a href="AssetAssignments.aspx">
                        <i class="bi bi-arrow-left-right"></i>
                        <span>Asset Assignments</span>
                    </a>
                </li>
                <li>
                    <a href="Returns.aspx">
                        <i class="bi bi-box-arrow-in-down"></i>
                        <span>Returns</span>
                    </a>
                </li>
                <li>
                    <a href="Documents.aspx">
                        <i class="bi bi-file-earmark-text"></i>
                        <span>Documents</span>
                    </a>
                </li>
                <li>
                    <a href="Reports.aspx">
                        <i class="bi bi-bar-chart"></i>
                        <span>Reports</span>
                    </a>
                </li>
                <li>
                    <a href="AuditLogs.aspx">
                        <i class="bi bi-clock-history"></i>
                        <span>Audit Logs</span>
                    </a>
                </li>
            </ul>
        </div>
        <!-- MAIN -->
        <div class="main">
            <!-- TOPBAR -->
            <div class="topbar">
                <div class="admin-info">
                    <div class="admin-icon">
                        <i class="bi bi-person-circle"></i>
                    </div>
                    <div class="admin-text">
                        <asp:Label ID="lblAdminName" runat="server" CssClass="admin-name"></asp:Label>
                        <asp:Label ID="lblAdminRole" runat="server" CssClass="admin-role"></asp:Label>
                    </div>
                </div>
            </div>
            <!-- CONTENT -->
            <div class="content">
                <!-- PAGE HEADER -->
                <div class="page-header">
                    <div class="page-title">
                        <h1>Delete Asset</h1>
                        <p>Review the asset information before deleting it.</p>
                    </div>
                </div>
                <!-- MESSAGE -->
                <asp:Label ID="lblMessage" runat="server" CssClass="message"></asp:Label>
                <!-- WARNING CARD -->
                <div class="warning-card">
                    <div class="warning-header">
                        <div class="warning-icon">
                            <i class="bi bi-exclamation-triangle"></i>
                        </div>
                        <div>
                            <h2>Delete Asset</h2>
                            <p>This action permanently removes the asset from the system.</p>
                        </div>
                    </div>
                    <!-- ASSET INFORMATION -->
                    <div class="asset-card">
                        <div class="asset-title">Asset Information</div>
                        <div class="details-grid">
                            <div class="detail-item">
                                <div class="detail-label">Asset Tag</div>
                                <div class="detail-value asset-tag">
                                    <asp:Label ID="lblAssetTag" runat="server"></asp:Label>
                                </div>
                            </div>
                            <div class="detail-item">
                                <div class="detail-label">Serial Number</div>
                                <div class="detail-value">
                                    <asp:Label ID="lblSerialNumber" runat="server"></asp:Label>
                                </div>
                            </div>
                            <div class="detail-item">
                                <div class="detail-label">Asset Type</div>
                                <div class="detail-value">
                                    <asp:Label ID="lblAssetType" runat="server"></asp:Label>
                                </div>
                            </div>
                            <div class="detail-item">
                                <div class="detail-label">Make</div>
                                <div class="detail-value">
                                    <asp:Label ID="lblMake" runat="server"></asp:Label>
                                </div>
                            </div>
                            <div class="detail-item">
                                <div class="detail-label">Model</div>
                                <div class="detail-value">
                                    <asp:Label ID="lblModel" runat="server"></asp:Label>
                                </div>
                            </div>
                            <div class="detail-item">
                                <div class="detail-label">Condition</div>
                                <div class="detail-value">
                                    <asp:Label ID="lblCondition" runat="server"></asp:Label>
                                </div>
                            </div>
                            <div class="detail-item">
                                <div class="detail-label">Warranty Expiration</div>
                                <div class="detail-value">
                                    <asp:Label ID="lblWarrantyExpirationDate" runat="server"></asp:Label>
                                </div>
                            </div>
                            <div class="detail-item">
                                <div class="detail-label">Receive Date</div>
                                <div class="detail-value">
                                    <asp:Label ID="lblReceiveDate" runat="server"></asp:Label>
                                </div>
                            </div>
                        </div>
                        <!-- IMPORTANT WARNING -->
                        <div class="danger-notice">
                            <i class="bi bi-shield-exclamation"></i>
                            <div>
                                <strong>Asset allocation history</strong>
                                <span>An asset with allocation history should not be deleted because the allocation records are linked to this asset. The system should prevent deletion when allocation records exist.</span>
                            </div>
                        </div>
                    </div>
                    <!-- ACTIONS -->
                    <div class="actions">
                        <asp:Button ID="btnCancel" runat="server" Text="Cancel" CssClass="btn btn-secondary" OnClick="btnCancel_Click" />
                        <asp:Button ID="btnDelete" runat="server" Text="Delete Asset" CssClass="btn btn-danger" OnClick="btnDelete_Click" OnClientClick="return confirm('Are you sure you want to permanently delete this asset? This action cannot be undone.');" />
                    </div>
                </div>
            </div>
        </div>
    </form>
</body>
</html>