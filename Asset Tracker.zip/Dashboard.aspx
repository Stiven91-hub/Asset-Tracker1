﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="Dashboard.aspx.cs" Inherits="Assets_Tracker.Dashboard" %>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title>Dashboard - IT Asset Management System</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" />
    <style>
        * {
            box-sizing: border-box;
        }
        body {
            margin: 0;
            font-family: Arial, Helvetica, sans-serif;
            background: #f6f8fc;
            color: #101c38;
        }
        /* Layout */
        .dashboard-container {
            display: flex;
            min-height: 100vh;
        }
        /* Sidebar - Updated Flex Layout */
        .sidebar {
            width: 260px;
            height: 100vh;
            background: linear-gradient(180deg, #016a3d, #062a5c);
            color: #ffffff;
            position: fixed;
            left: 0;
            top: 0;
            padding: 22px 12px;
            z-index: 100;
            display: flex;
            flex-direction: column;
        }
        /* Logo */
        .logo {
            display: flex;
            align-items: center;
            gap: 14px;
            padding: 0 10px 20px 10px;
            flex-shrink: 0;
        }
        .logo-icon {
            width: 40px;
            height: 40px;
            border: 2px solid #ffffff;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 22px;
        }
        .logo-text {
            font-size: 17px;
            font-weight: bold;
            line-height: 1.3;
        }
        .logo-text span {
            display: block;
            font-size: 13px;
            font-weight: normal;
        }
        /* Navigation - Updated Scrollable Container */
        .navigation {
            margin-top: 10px;
            flex-grow: 1;
            overflow-y: auto;
            padding-right: 2px;
        }
        .nav-item {
            display: flex;
            align-items: center;
            gap: 17px;
            height: 46px;
            padding: 0 15px;
            margin-bottom: 6px;
            border-radius: 8px;
            color: #ffffff;
            text-decoration: none;
            font-size: 14px;
            font-weight: 600;
            transition: background 0.2s ease;
        }
        .nav-item i {
            width: 22px;
            font-size: 19px;
        }
        .nav-item:hover {
            background: rgba(255, 255, 255, 0.1);
        }
        .nav-item.active {
            background: #1764d8;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
        }
        /* Logout - Fixed Flow Control */
        .logout {
            margin-top: auto;
            padding-top: 15px;
            border-top: 1px solid rgba(255, 255, 255, 0.15);
            flex-shrink: 0;
        }
        /* Main Content */
        .main-content {
            margin-left: 260px;
            width: calc(100% - 260px);
            min-height: 100vh;
        }
        /* Topbar */
        .topbar {
            height: 72px;
            background: #ffffff;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 28px;
            border-bottom: 1px solid #e6e9ef;
        }
        .topbar-left {
            display: flex;
            align-items: center;
            gap: 28px;
        }
        .menu-button {
            font-size: 25px;
            color: #101c38;
            cursor: pointer;
        }
        .page-title {
            font-size: 18px;
            font-weight: bold;
        }
        /* User Area */
        .topbar-right {
            display: flex;
            align-items: center;
            gap: 25px;
        }
        .notification {
            position: relative;
            font-size: 23px;
            cursor: pointer;
        }
        .notification-badge {
            position: absolute;
            top: -8px;
            right: -8px;
            width: 18px;
            height: 18px;
            border-radius: 50%;
            background: #c92a2a;
            color: #ffffff;
            font-size: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        /* User Profile */
        .profile {
            display: flex;
            align-items: center;
            gap: 12px;
        }
        .profile-icon {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: #e9edf4;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 25px;
        }
        .profile-info strong {
            display: block;
            font-size: 14px;
        }
        .profile-info span {
            display: block;
            font-size: 12px;
            color: #68738a;
            margin-top: 3px;
        }
        .profile-arrow {
            margin-left: 10px;
        }
        /* Page Content */
        .content {
            padding: 30px;
        }
        /* Stat Cards */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(5, 1fr);
            gap: 20px;
        }
        .stat-card {
            min-height: 130px;
            padding: 20px;
            border-radius: 12px;
            border: 1px solid rgba(0, 0, 0, 0.04);
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }
        .stat-card.blue { background: #edf4ff; }
        .stat-card.green { background: #edf9f1; }
        .stat-card.orange { background: #fff6e8; }
        .stat-card.red { background: #fff0f2; }
        .stat-card.gray { background: #f3f4f6; }
        .stat-header {
            display: flex;
            align-items: center;
            gap: 15px;
        }
        .stat-icon {
            width: 55px;
            height: 55px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 28px;
            flex-shrink: 0;
        }
        .blue .stat-icon { background: #dceaff; color: #124da8; }
        .green .stat-icon { background: #d8f2e0; color: #087f3d; }
        .orange .stat-icon { background: #ffe9bf; color: #bd6c00; }
        .red .stat-icon { background: #f9dce2; color: #ad3447; }
        .gray .stat-icon { background: #e4e7eb; color: #343a40; }
        .stat-details {
            display: flex;
            flex-direction: column;
        }
        .stat-title {
            font-size: 12px;
            color: #17223b;
        }
        .stat-number {
            font-size: 25px;
            font-weight: bold;
            color: #07152e;
            margin-top: 2px;
        }
        .stat-link {
            font-size: 12px;
            color: #0757c7;
            text-decoration: none;
            margin-top: 10px;
        }
        .stat-link:hover {
            text-decoration: underline;
        }
        /* Middle Grid Layout */
        .middle-grid {
            display: grid;
            grid-template-columns: 1.65fr 1fr;
            gap: 25px;
            margin-top: 30px;
        }
        .panel {
            background: #ffffff;
            border-radius: 12px;
            border: 1px solid #e5e9ef;
            overflow: hidden;
        }
        .panel-header {
            padding: 18px 20px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            border-bottom: 1px solid #e9edf2;
        }
        .panel-title {
            display: flex;
            align-items: center;
            gap: 12px;
            font-size: 15px;
            font-weight: bold;
        }
        .panel-title i {
            color: #0757c7;
            font-size: 20px;
        }
        .view-all {
            padding: 8px 14px;
            border: 1px solid #e3e7ed;
            border-radius: 6px;
            background: #ffffff;
            color: #18243e;
            text-decoration: none;
            font-size: 12px;
        }
        /* Table */
        .table-wrapper {
            padding: 10px 12px 15px;
            overflow-x: auto;
        }
        .assignment-table {
            width: 100%;
            border-collapse: collapse;
        }
        .assignment-table th {
            text-align: left;
            padding: 13px;
            font-size: 12px;
            color: #17223b;
            border-bottom: 1px solid #e5e9ef;
        }
        .assignment-table td {
            padding: 13px;
            font-size: 12px;
            border-bottom: 1px solid #e9edf2;
            vertical-align: middle;
        }
        .assignment-table tr:last-child td {
            border-bottom: none;
        }
        .employee-name {
            font-weight: 600;
            display: block;
        }
        .employee-id {
            color: #0757c7;
            font-size: 11px;
            display: block;
            margin-top: 4px;
        }
        .asset-number {
            font-weight: 600;
            display: block;
        }
        .asset-name {
            color: #667085;
            display: block;
            margin-top: 4px;
        }
        .status {
            background: #dff5e7;
            color: #087f3d;
            padding: 6px 12px;
            border-radius: 5px;
            font-size: 11px;
            font-weight: bold;
            display: inline-block;
        }
        /* Quick Access */
        .quick-actions {
            padding: 12px 15px 15px;
        }
        .action {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 15px;
            border-radius: 9px;
            margin-bottom: 10px;
            text-decoration: none;
            color: #101c38;
            transition: opacity 0.2s ease;
        }
        .action:hover {
            opacity: 0.85;
        }
        .action:last-child {
            margin-bottom: 0;
        }
        .action-content {
            display: flex;
            align-items: center;
            gap: 15px;
        }
        .action-icon {
            width: 38px;
            height: 38px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 8px;
            font-size: 21px;
        }
        .action-title {
            font-size: 13px;
            font-weight: bold;
        }
        .action-description {
            font-size: 11px;
            color: #68738a;
            margin-top: 5px;
        }
        .action-arrow {
            font-size: 18px;
        }
        .action-blue { background: #edf4ff; }
        .action-blue .action-icon { color: #0757c7; background: #dceaff; }
        .action-blue .action-arrow { color: #0757c7; }
        .action-green { background: #edf9f1; }
        .action-green .action-icon { color: #087f3d; background: #d8f2e0; }
        .action-green .action-arrow { color: #087f3d; }
        .action-orange { background: #fff6e8; }
        .action-orange .action-icon { color: #bd6c00; background: #ffe9bf; }
        .action-orange .action-arrow { color: #bd6c00; }
        .action-purple { background: #f5efff; }
        .action-purple .action-icon { color: #5e20b5; background: #eadcff; }
        .action-purple .action-arrow { color: #5e20b5; }
        .action-red { background: #fff0f2; }
        .action-red .action-icon { color: #b42334; background: #f9dce2; }
        .action-red .action-arrow { color: #b42334; }
        /* Bottom Grid */
        .bottom-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 25px;
            margin-top: 15px;
        }
        /* Asset Summary */
        .summary-content {
            padding: 20px;
        }
        .donut-section {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 30px;
        }
        .donut {
            width: 145px;
            height: 145px;
            border-radius: 50%;
            background: conic-gradient(
                #ffb321 0deg 296deg,
                #31ad66 296deg 345deg,
                #d75563 345deg 354deg,
                #9da3ad 354deg 360deg
            );
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .donut::after {
            content: "";
            width: 75px;
            height: 75px;
            border-radius: 50%;
            background: #ffffff;
        }
        .legend {
            font-size: 11px;
        }
        .legend-item {
            display: flex;
            align-items: center;
            gap: 8px;
            margin-bottom: 13px;
        }
        .legend-color {
            width: 10px;
            height: 10px;
            border-radius: 2px;
        }
        .legend-green { background: #31ad66; }
        .legend-orange { background: #ffb321; }
        .legend-red { background: #d75563; }
        .legend-gray { background: #9da3ad; }
        /* Documents */
        .documents {
            padding: 12px;
        }
        .documents-footer {
            text-align: center;
            padding: 10px;
        }
        .documents-footer a {
            color: #0757c7;
            font-size: 11px;
            text-decoration: none;
        }
        /* System Information */
        .system-info {
            padding: 20px;
        }
        .info-row {
            display: grid;
            grid-template-columns: 115px 1fr;
            margin-bottom: 18px;
            font-size: 11px;
        }
        .info-label {
            font-weight: bold;
        }
        .info-value {
            color: #26334e;
        }
        /* Footer */
        .footer {
            text-align: center;
            padding: 30px 0 15px;
            color: #59657b;
            font-size: 12px;
        }
        /* Responsive Design */
        @media (max-width: 1300px) {
            .stats-grid {
                grid-template-columns: repeat(3, 1fr);
            }
            .bottom-grid {
                grid-template-columns: 1fr 1fr;
            }
        }
        @media (max-width: 1000px) {
            .sidebar {
                width: 80px;
            }
            .logo-text,
            .nav-item span {
                display: none;
            }
            .logo, .nav-item {
                justify-content: center;
            }
            .main-content {
                margin-left: 80px;
                width: calc(100% - 80px);
            }
            .middle-grid {
                grid-template-columns: 1fr;
            }
        }
        @media (max-width: 700px) {
            .stats-grid,
            .bottom-grid {
                grid-template-columns: 1fr;
            }
            .content {
                padding: 15px;
            }
            .profile-info {
                display: none;
            }
        }
    </style>
</head>
<body>
<form id="form1" runat="server">
<div class="dashboard-container">
    <!-- SIDEBAR -->
    <aside class="sidebar">
        <div class="logo">
            <div class="logo-icon">
                <i class="bi bi-display"></i>
            </div>
            <div class="logo-text">
                IT Asset Management
                <span>System</span>
            </div>
        </div>
        <nav class="navigation">
            <a href="Dashboard.aspx" class="nav-item active">
                <i class="bi bi-grid"></i>
                <span>Dashboard</span>
            </a>
            <a href="Users.aspx" class="nav-item">
                <i class="bi bi-person"></i>
                <span>Users</span>
            </a>
            <a href="Assets.aspx" class="nav-item">
                <i class="bi bi-laptop"></i>
                <span>Assets</span>
            </a>
            <a href="AssetAssignments.aspx" class="nav-item">
                <i class="bi bi-person-check"></i>
                <span>Asset Assignments</span>
            </a>
            <a href="Returns.aspx" class="nav-item">
                <i class="bi bi-box-arrow-in-left"></i>
                <span>Returns</span>
            </a>
            <a href="Documents.aspx" class="nav-item">
                <i class="bi bi-file-earmark-text"></i>
                <span>Documents</span>
            </a>
            <a href="Reports.aspx" class="nav-item">
                <i class="bi bi-bar-chart"></i>
                <span>Reports</span>
            </a>
            <a href="AuditLogs.aspx" class="nav-item">
                <i class="bi bi-shield-check"></i>
                <span>Audit Logs</span>
            </a>
            <a href="ImportData.aspx" class="nav-item">
                <i class="bi bi-upload"></i>
                <span>Import Data</span>
            </a>
        </nav>
        <div class="logout">
            <a href="LoginPage.aspx" class="nav-item">
                <i class="bi bi-box-arrow-left"></i>
                <span>Logout</span>
            </a>
        </div>
    </aside>
    <!-- MAIN CONTENT -->
    <main class="main-content">
        <!-- TOP BAR -->
        <header class="topbar">
            <div class="topbar-left">
                <div class="menu-button">
                    <i class="bi bi-list"></i>
                </div>
                <div class="page-title">
                    Dashboard
                </div>
            </div>
            <div class="topbar-right">
                <div class="profile">
                    <div class="profile-icon">
                        <i class="bi bi-person-fill"></i>
                    </div>
                    <div class="profile-info">
                        <strong>
                            <asp:Label ID="lblAdminName" runat="server"></asp:Label>
                        </strong>
                        <span>
                            <asp:Label ID="lblAdminRole" runat="server"></asp:Label>
                        </span>
                    </div>
                    <div class="profile-arrow">
                        <i class="bi bi-chevron-down"></i>
                    </div>
                </div>
            </div>
        </header>
        <section class="content">
            <!-- STATISTICS -->
            <div class="stats-grid">
                <div class="stat-card blue">
                    <div class="stat-header">
                        <div class="stat-icon">
                            <i class="bi bi-laptop"></i>
                        </div>
                        <div class="stat-details">
                            <span class="stat-title">Total Assets</span>
                            <strong class="stat-number">
                                <asp:Label ID="lblTotalAssets" runat="server"></asp:Label>
                            </strong>
                        </div>
                    </div>
                    <a href="Assets.aspx" class="stat-link">View all assets →</a>
                </div>
                <div class="stat-card green">
                    <div class="stat-header">
                        <div class="stat-icon">
                            <i class="bi bi-check-circle"></i>
                        </div>
                        <div class="stat-details">
                            <span class="stat-title">Available Assets</span>
                            <strong class="stat-number">
                                <asp:Label ID="lblAvailableAssets" runat="server"></asp:Label>
                            </strong>
                        </div>
                    </div>
                    <a href="Assets.aspx" class="stat-link">View details →</a>
                </div>
                <div class="stat-card orange">
                    <div class="stat-header">
                        <div class="stat-icon">
                            <i class="bi bi-person"></i>
                        </div>
                        <div class="stat-details">
                            <span class="stat-title">Assigned Assets</span>
                            <strong class="stat-number">
                                <asp:Label ID="lblAssignedAssets" runat="server"></asp:Label>
                            </strong>
                        </div>
                    </div>
                    <a href="AssetAssignments.aspx" class="stat-link">View details →</a>
                </div>
                <div class="stat-card red">
                    <div class="stat-header">
                        <div class="stat-icon">
                            <i class="bi bi-wrench"></i>
                        </div>
                        <div class="stat-details">
                            <span class="stat-title">Under Maintenance</span>
                            <strong class="stat-number">
                                <asp:Label ID="lblMaintenanceAssets" runat="server"></asp:Label>
                            </strong>
                        </div>
                    </div>
                    <a href="Assets.aspx" class="stat-link">View details →</a>
                </div>
                <div class="stat-card gray">
                    <div class="stat-header">
                        <div class="stat-icon">
                            <i class="bi bi-archive"></i>
                        </div>
                        <div class="stat-details">
                            <span class="stat-title">Retired Assets</span>
                            <strong class="stat-number">
                                <asp:Label ID="lblRetiredAssets" runat="server"></asp:Label>
                            </strong>
                        </div>
                    </div>
                    <a href="Assets.aspx" class="stat-link">View details →</a>
                </div>
            </div>
            <!-- RECENT ASSIGNMENTS & QUICK ACTIONS -->
            <div class="middle-grid">
                <div class="panel">
                    <div class="panel-header">
                        <div class="panel-title">
                            <i class="bi bi-clipboard-check"></i>
                            Recent Asset Assignments
                        </div>
                        <a href="AssetAssignments.aspx" class="view-all">View all</a>
                    </div>
                    <div class="table-wrapper">
                        <table class="assignment-table">
                            <thead>
                                <tr>
                                    <th>Employee</th>
                                    <th>Asset</th>
                                    <th>Asset Type</th>
                                    <th>Date Assigned</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <asp:Repeater ID="rptRecentAssignments" runat="server">
                                    <ItemTemplate>
                                        <tr>
                                            <td>
                                                <span class="employee-name">
                                                    <%# Eval("FirstName") %> <%# Eval("LastName") %>
                                                </span>
                                                <span class="employee-id">
                                                    <%# Eval("EmployeeNumber") %>
                                                </span>
                                            </td>
                                            <td>
                                                <span class="asset-number">
                                                    <%# Eval("AssetTag") %>
                                                </span>
                                                <span class="asset-name">
                                                    <%# Eval("Make") %> <%# Eval("Model") %>
                                                </span>
                                            </td>
                                            <td>
                                                <%# Eval("AssetType") %>
                                            </td>
                                            <td>
                                                <%# Convert.ToDateTime(Eval("AllocationDate")).ToString("dd MMM yyyy") %>
                                            </td>
                                            <td>
                                                <span class="status">
                                                    <%# Eval("Status") %>
                                                </span>
                                            </td>
                                        </tr>
                                    </ItemTemplate>
                                </asp:Repeater>
                            </tbody>
                        </table>
                    </div>
                </div>
                <!-- QUICK ACTIONS -->
                <div class="panel">
                    <div class="panel-header">
                        <div class="panel-title">
                            <i class="bi bi-lightning-charge"></i>
                            Quick Actions
                        </div>
                    </div>
                    <div class="quick-actions">
                        <a href="Assets.aspx" class="action action-blue">
                            <div class="action-content">
                                <div class="action-icon">
                                    <i class="bi bi-laptop"></i>
                                </div>
                                <div>
                                    <div class="action-title">Register New Asset</div>
                                    <div class="action-description">Add a new asset to the system</div>
                                </div>
                            </div>
                            <div class="action-arrow">→</div>
                        </a>
                        <a href="AssetAssignments.aspx" class="action action-green">
                            <div class="action-content">
                                <div class="action-icon">
                                    <i class="bi bi-person-plus"></i>
                                </div>
                                <div>
                                    <div class="action-title">Issue Asset</div>
                                    <div class="action-description">Assign an asset to an employee</div>
                                </div>
                            </div>
                            <div class="action-arrow">→</div>
                        </a>
                        <a href="Returns.aspx" class="action action-orange">
                            <div class="action-content">
                                <div class="action-icon">
                                    <i class="bi bi-arrow-return-left"></i>
                                </div>
                                <div>
                                    <div class="action-title">Return Asset</div>
                                    <div class="action-description">Process returned assets</div>
                                </div>
                            </div>
                            <div class="action-arrow">→</div>
                        </a>
                        <a href="Documents.aspx" class="action action-purple">
                            <div class="action-content">
                                <div class="action-icon">
                                    <i class="bi bi-file-earmark-text"></i>
                                </div>
                                <div>
                                    <div class="action-title">Generate Documents</div>
                                    <div class="action-description">Generate and print forms (3)</div>
                                </div>
                            </div>
                            <div class="action-arrow">→</div>
                        </a>
                        <a href="Assets.aspx" class="action action-red">
                            <div class="action-content">
                                <div class="action-icon">
                                    <i class="bi bi-card-list"></i>
                                </div>
                                <div>
                                    <div class="action-title">View Asset Register</div>
                                    <div class="action-description">View all assets and status</div>
                                </div>
                            </div>
                            <div class="action-arrow">→</div>
                        </a>
                    </div>
                </div>
            </div>
            <!-- BOTTOM GRID -->
            <div class="bottom-grid">
                <div class="panel">
                    <div class="panel-header">
                        <div class="panel-title">
                            <i class="bi bi-pie-chart"></i>
                            Asset Summary
                        </div>
                    </div>
                    <div class="summary-content">
                        <div class="donut-section">
                            <div class="donut"></div>
                            <div class="legend">
                                <div class="legend-item">
                                    <span class="legend-color legend-green"></span>
                                    Available
                                    <strong>
                                        <asp:Label ID="lblAvailablePercentage" runat="server"></asp:Label>
                                    </strong>
                                </div>
                                <div class="legend-item">
                                    <span class="legend-color legend-orange"></span>
                                    Assigned
                                    <strong>
                                        <asp:Label ID="lblAssignedPercentage" runat="server"></asp:Label>
                                    </strong>
                                </div>
                                <div class="legend-item">
                                    <span class="legend-color legend-red"></span>
                                    Under Maintenance
                                    <strong>
                                        <asp:Label ID="lblMaintenancePercentage" runat="server"></asp:Label>
                                    </strong>
                                </div>
                                <div class="legend-item">
                                    <span class="legend-color legend-gray"></span>
                                    Retired
                                    <strong>
                                        <asp:Label ID="lblRetiredPercentage" runat="server"></asp:Label>
                                    </strong>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="panel">
                    <div class="panel-header">
                        <div class="panel-title">
                            <i class="bi bi-file-earmark-text"></i>
                            Recent Documents Generated
                        </div>
                    </div>
                    <div class="documents">
                        <p style="padding:15px;font-size:12px;color:#68738a;">
                            Document records will be connected when we create
                            the document/PDF table.
                        </p>
                    </div>
                    <div class="documents-footer">
                        <a href="Documents.aspx">View all documents →</a>
                    </div>
                </div>
                <div class="panel">
                    <div class="panel-header">
                        <div class="panel-title">
                            <i class="bi bi-info-circle"></i>
                            System Information
                        </div>
                    </div>
                    <div class="system-info">
                        <div class="info-row">
                            <div class="info-label">System Name:</div>
                            <div class="info-value">IT Asset Management System</div>
                        </div>
                        <div class="info-row">
                            <div class="info-label">Version:</div>
                            <div class="info-value">1.0.0</div>
                        </div>
                        <div class="info-row">
                            <div class="info-label">Environment:</div>
                            <div class="info-value">Development</div>
                        </div>
                        <div class="info-row">
                            <div class="info-label">Server Time:</div>
                            <div class="info-value">
                                <asp:Label ID="lblServerTime" runat="server"></asp:Label>
                            </div>
                        </div>
                        <div class="info-row">
                            <div class="info-label">Logged in as:</div>
                            <div class="info-value">
                                <asp:Label ID="lblLoggedInAs" runat="server"></asp:Label>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <footer class="footer">
                © <asp:Label ID="lblYear" runat="server"></asp:Label> IT Asset Management System. All rights reserved.
            </footer>
        </section>
    </main>
</div>
</form>
</body>
</html>