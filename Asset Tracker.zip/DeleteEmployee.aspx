﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="DeleteEmployee.aspx.cs" Inherits="Assets_Tracker.DeleteEmployee" %>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title>Delete Employee - IT Assets Management System</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" />
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, Helvetica, sans-serif;
        }
        body {
            background: #f4f6fb;
            color: #333;
        }
        .dashboard-container {
            display: flex;
            min-height: 100vh;
        }
        /* ================= SIDEBAR ================= */
        .sidebar {
            width: 260px;
            min-height: 100vh;
            background: linear-gradient(180deg, #0f5c4d, #123a5c);
            color: white;
            position: fixed;
            left: 0;
            top: 0;
            bottom: 0;
            padding: 20px 15px;
        }
        .logo {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 10px 8px 25px;
            border-bottom: 1px solid rgba(255,255,255,0.15);
        }
        .logo-icon {
            width: 45px;
            height: 45px;
            background: rgba(255,255,255,0.15);
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 22px;
        }
        .logo-text {
            font-size: 15px;
            font-weight: bold;
            line-height: 20px;
        }
        .logo-text span {
            display: block;
            font-size: 12px;
            font-weight: normal;
            opacity: 0.8;
        }
        .navigation {
            margin-top: 25px;
        }
        .nav-item {
            display: flex;
            align-items: center;
            gap: 13px;
            color: white;
            text-decoration: none;
            padding: 13px 15px;
            margin-bottom: 6px;
            border-radius: 8px;
            font-size: 14px;
        }
        .nav-item i {
            font-size: 18px;
        }
        .nav-item:hover {
            background: rgba(255,255,255,0.12);
        }
        .nav-item.active {
            background: linear-gradient(90deg, #2563c7, #3f7bd7);
        }
        .logout {
            position: absolute;
            bottom: 20px;
            left: 15px;
            right: 15px;
        }
        /* ================= MAIN ================= */
        .main-content {
            margin-left: 260px;
            width: calc(100% - 260px);
            min-height: 100vh;
        }
        /* ================= TOPBAR ================= */
        .topbar {
            height: 75px;
            background: white;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 30px;
            border-bottom: 1px solid #e5e7eb;
        }
        .topbar-left {
            display: flex;
            align-items: center;
            gap: 18px;
        }
        .menu-button {
            width: 40px;
            height: 40px;
            border-radius: 8px;
            background: #f1f5f9;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 22px;
            color: #334155;
        }
        .page-title {
            font-size: 20px;
            font-weight: bold;
            color: #1e293b;
        }
        .topbar-right {
            display: flex;
            align-items: center;
            gap: 25px;
        }
        .notifications {
            position: relative;
            font-size: 21px;
            color: #475569;
        }
        .notification-badge {
            position: absolute;
            top: -2px;
            right: -3px;
            width: 8px;
            height: 8px;
            background: #ef4444;
            border-radius: 50%;
        }
        .profile {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .profile-icon {
            width: 40px;
            height: 40px;
            background: #e8eef8;
            color: #2563c7;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .profile-info strong {
            display: block;
            font-size: 14px;
            color: #1e293b;
        }
        .profile-info span {
            display: block;
            font-size: 12px;
            color: #64748b;
            margin-top: 2px;
        }
        /* ================= CONTENT ================= */
        .content {
            padding: 30px;
        }
        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
        }
        .heading h1 {
            font-size: 27px;
            color: #1e293b;
            margin-bottom: 6px;
        }
        .heading p {
            color: #64748b;
            font-size: 14px;
        }
        .back-button {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 11px 18px;
            background: #64748b;
            color: white;
            text-decoration: none;
            border-radius: 7px;
            font-size: 14px;
        }
        .back-button:hover {
            background: #475569;
        }
        /* ================= DELETE CARD ================= */
        .delete-card {
            max-width: 850px;
            margin: 20px auto;
            background: white;
            border-radius: 12px;
            box-shadow: 0 3px 12px rgba(0,0,0,0.06);
            overflow: hidden;
        }
        .delete-header {
            background: #fff7ed;
            border-bottom: 1px solid #fed7aa;
            padding: 30px;
            text-align: center;
        }
        .warning-icon {
            width: 70px;
            height: 70px;
            margin: 0 auto 15px;
            background: #ffedd5;
            color: #ea580c;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 32px;
        }
        .delete-header h2 {
            color: #9a3412;
            font-size: 22px;
            margin-bottom: 8px;
        }
        .delete-header p {
            color: #7c2d12;
            font-size: 14px;
        }
        /* ================= EMPLOYEE INFO ================= */
        .employee-information {
            padding: 30px;
        }
        .section-title {
            display: flex;
            align-items: center;
            gap: 9px;
            color: #123a5c;
            font-size: 17px;
            font-weight: bold;
            padding-bottom: 12px;
            border-bottom: 1px solid #e5e7eb;
            margin-bottom: 22px;
        }
        .section-title i {
            color: #2563c7;
        }
        .employee-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 15px;
        }
        .detail-box {
            background: #f8fafc;
            border: 1px solid #e2e8f0;
            border-radius: 8px;
            padding: 15px;
        }
        .detail-label {
            display: block;
            color: #64748b;
            font-size: 11px;
            margin-bottom: 6px;
        }
        .detail-value {
            display: block;
            color: #1e293b;
            font-size: 14px;
            font-weight: bold;
        }
        /* ================= WARNING ================= */
        .warning-box {
            margin-top: 25px;
            background: #fff7ed;
            border: 1px solid #fed7aa;
            border-radius: 8px;
            padding: 17px;
            display: flex;
            gap: 12px;
        }
        .warning-box i {
            color: #ea580c;
            font-size: 20px;
        }
        .warning-box p {
            color: #7c2d12;
            font-size: 13px;
            line-height: 20px;
        }
        /* ================= MESSAGE ================= */
        .message {
            display: block;
            padding: 13px 16px;
            border-radius: 7px;
            margin-bottom: 20px;
            font-size: 13px;
        }
        .success-message {
            background: #dcfce7;
            color: #166534;
            border: 1px solid #bbf7d0;
        }
        .error-message {
            background: #fee2e2;
            color: #991b1b;
            border: 1px solid #fecaca;
        }
        /* ================= ACTIONS ================= */
        .actions {
            padding: 22px 30px;
            border-top: 1px solid #e5e7eb;
            display: flex;
            justify-content: flex-end;
            gap: 12px;
        }
        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            min-width: 130px;
            height: 43px;
            padding: 0 20px;
            border-radius: 7px;
            border: none;
            font-size: 13px;
            font-weight: bold;
            cursor: pointer;
            text-decoration: none;
        }
        .btn-cancel {
            background: #e2e8f0;
            color: #334155;
        }
        .btn-cancel:hover {
            background: #cbd5e1;
        }
        .btn-delete {
            background: #dc2626;
            color: white;
        }
        .btn-delete:hover {
            background: #b91c1c;
        }
        /* ================= FOOTER ================= */
        .footer {
            margin-top: 30px;
            padding: 20px 0;
            text-align: center;
            color: #94a3b8;
            font-size: 12px;
        }
        /* ================= RESPONSIVE ================= */
        @media(max-width: 900px) {
            .sidebar {
                width: 220px;
            }
            .main-content {
                margin-left: 220px;
                width: calc(100% - 220px);
            }
            .employee-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
<form id="form1" runat="server">
    <div class="dashboard-container">
        <!-- ================= SIDEBAR ================= -->
        <aside class="sidebar">
            <div class="logo">
                <div class="logo-icon">
                    <i class="bi bi-display"></i>
                </div>
                <div class="logo-text">
                    IT Assets Management System
                    <span>System</span>
                </div>
            </div>
            <nav class="navigation">
                <a href="Dashboard.aspx" class="nav-item">
                    <i class="bi bi-grid"></i>
                    Dashboard
                </a>
                <a href="Users.aspx" class="nav-item active">
                    <i class="bi bi-people"></i>
                    Users
                </a>
                <a href="Assets.aspx" class="nav-item">
                    <i class="bi bi-laptop"></i>
                    Assets
                </a>
                <a href="AssetAssignments.aspx" class="nav-item">
                    <i class="bi bi-person-check"></i>
                    Asset Assignments
                </a>
                <a href="Returns.aspx" class="nav-item">
                    <i class="bi bi-arrow-return-left"></i>
                    Returns
                </a>
                <a href="Documents.aspx" class="nav-item">
                    <i class="bi bi-file-earmark-text"></i>
                    Documents
                </a>
                <a href="Reports.aspx" class="nav-item">
                    <i class="bi bi-bar-chart"></i>
                    Reports
                </a>
                <a href="AuditLogs.aspx" class="nav-item">
                    <i class="bi bi-shield-check"></i>
                    Audit Logs
                </a>
            </nav>
            <div class="logout">
                <a href="LoginPage.aspx" class="nav-item">
                    <i class="bi bi-box-arrow-left"></i>
                    Logout
                </a>
            </div>
        </aside>
        <!-- ================= MAIN CONTENT ================= -->
        <main class="main-content">
            <!-- TOPBAR -->
            <header class="topbar">
                <div class="topbar-left">
                    <div class="menu-button">
                        <i class="bi bi-list"></i>
                    </div>
                    <div class="page-title">
                        Delete Employee
                    </div>
                </div>
                <div class="topbar-right">
                    <div class="notifications">
                        <i class="bi bi-bell"></i>
                        <span class="notification-badge"></span>
                    </div>
                    <div class="profile">
                        <div class="profile-icon">
                            <i class="bi bi-person-fill"></i>
                        </div>
                        <div class="profile-info">
                            <strong>
                                <asp:Label
                                    ID="lblAdminName"
                                    runat="server"
                                    Text="Administrator">
                                </asp:Label>
                            </strong>
                            <span>
                                <asp:Label
                                    ID="lblAdminRole"
                                    runat="server"
                                    Text="IT Administrator">
                                </asp:Label>
                            </span>
                        </div>
                        <i class="bi bi-chevron-down"></i>
                    </div>
                </div>
            </header>
            <!-- CONTENT -->
            <section class="content">
                <div class="page-header">
                    <div class="heading">
                        <h1>Delete Employee</h1>
                        <p>
                            Remove an employee from the IT Asset Management System
                        </p>
                    </div>
                    <a href="Users.aspx" class="back-button">
                        <i class="bi bi-arrow-left"></i>
                        Back to Users
                    </a>
                </div>
                <!-- MESSAGE -->
                <asp:Label
                    ID="lblMessage"
                    runat="server"
                    CssClass="message">
                </asp:Label>
                <!-- DELETE CARD -->
                <div class="delete-card">
                    <!-- WARNING HEADER -->
                    <div class="delete-header">
                        <div class="warning-icon">
                            <i class="bi bi-exclamation-triangle"></i>
                        </div>
                        <h2>Delete Employee?</h2>
                        <p>
                            You are about to remove the following employee.
                        </p>
                    </div>
                    <!-- EMPLOYEE INFORMATION -->
                    <div class="employee-information">
                        <div class="section-title">
                            <i class="bi bi-person-vcard"></i>
                            Employee Information
                        </div>
                        <div class="employee-grid">
                            <!-- EMPLOYEE NUMBER -->
                            <div class="detail-box">
                                <span class="detail-label">
                                    Employee Number
                                </span>
                                <asp:Label
                                    ID="lblEmployeeNumber"
                                    runat="server"
                                    CssClass="detail-value">
                                </asp:Label>
                            </div>
                            <!-- EMPLOYEE ID -->
                            <div class="detail-box">
                                <span class="detail-label">
                                    Employee ID
                                </span>
                                <asp:Label
                                    ID="lblEmployeeID"
                                    runat="server"
                                    CssClass="detail-value">
                                </asp:Label>
                            </div>
                            <!-- FIRST NAME -->
                            <div class="detail-box">
                                <span class="detail-label">
                                    First Name
                                </span>
                                <asp:Label
                                    ID="lblFirstName"
                                    runat="server"
                                    CssClass="detail-value">
                                </asp:Label>
                            </div>
                            <!-- LAST NAME -->
                            <div class="detail-box">
                                <span class="detail-label">
                                    Last Name
                                </span>
                                <asp:Label
                                    ID="lblLastName"
                                    runat="server"
                                    CssClass="detail-value">
                                </asp:Label>
                            </div>
                            <!-- EMAIL -->
                            <div class="detail-box">
                                <span class="detail-label">
                                    Email Address
                                </span>
                                <asp:Label
                                    ID="lblEmail"
                                    runat="server"
                                    CssClass="detail-value">
                                </asp:Label>
                            </div>
                            <!-- PHONE -->
                            <div class="detail-box">
                                <span class="detail-label">
                                    Phone Number
                                </span>
                                <asp:Label
                                    ID="lblPhoneNumber"
                                    runat="server"
                                    CssClass="detail-value">
                                </asp:Label>
                            </div>
                            <!-- JOB TITLE -->
                            <div class="detail-box">
                                <span class="detail-label">
                                    Job Title
                                </span>
                                <asp:Label
                                    ID="lblJobTitle"
                                    runat="server"
                                    CssClass="detail-value">
                                </asp:Label>
                            </div>
                        </div>
                        <!-- WARNING -->
                        <div class="warning-box">
                            <i class="bi bi-exclamation-circle"></i>
                            <p>
                                <strong>Important:</strong>
                                Deleting an employee may affect records connected
                                to this employee, including asset allocation records.
                                Please make sure that all assets currently assigned
                                to this employee have been returned before deleting
                                the employee.
                            </p>
                        </div>
                    </div>
                    <!-- ACTIONS -->
                    <div class="actions">
                        <asp:Button
                            ID="btnCancel"
                            runat="server"
                            Text="Cancel"
                            CssClass="btn btn-cancel"
                            OnClick="btnCancel_Click" />
                        <asp:Button
                            ID="btnDelete"
                            runat="server"
                            Text="Delete Employee"
                            CssClass="btn btn-delete"
                            OnClick="btnDelete_Click"
                            OnClientClick="return confirm('Are you sure you want to delete this employee? This action cannot be undone.');" />
                    </div>
                </div>
                <!-- FOOTER -->
                <div class="footer">
                    &copy; 2026 IT Assets Management System.
                    All rights reserved byS.N Nkuna.
                </div>
            </section>
        </main>
    </div>
</form>
</body>
</html>