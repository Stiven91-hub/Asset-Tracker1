﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="Assets.aspx.cs" Inherits="Assets_Tracker.Assets" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title>Assets - IT Assets Management System</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" />
    <style>
        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }

        body {
            font-family: Arial, Helvetica, sans-serif;
            background: #f4f7fb;
            color: #172033;
        }

        /* MAIN CONTAINER */
        .dashboard-container {
            display: flex;
            min-height: 100vh;
        }

        /* SIDEBAR */
        .sidebar {
            width: 260px;
            background: linear-gradient(180deg, #005b41 0%, #063455 100%);
            position: fixed;
            left: 0;
            top: 0;
            bottom: 0;
            display: flex;
            flex-direction: column;
        }

        /* LOGO SECTION */
        .logo {
            height: 80px;
            display: flex;
            align-items: center;
            padding: 0 24px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.12);
        }

        .logo-icon {
            width: 38px;
            height: 38px;
            border: 2px solid #ffffff;
            color: #ffffff;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
            margin-right: 12px;
        }

        .logo-text {
            font-size: 15px;
            font-weight: 600;
            color: #ffffff;
            line-height: 1.2;
        }

        .logo-text span {
            display: block;
            font-size: 12px;
            font-weight: 400;
            color: rgba(255, 255, 255, 0.7);
            margin-top: 2px;
        }

        /* NAVIGATION LINKS */
        .navigation {
            padding: 20px 14px;
            flex: 1;
        }

        .nav-item {
            display: flex;
            align-items: center;
            gap: 14px;
            color: rgba(255, 255, 255, 0.85);
            text-decoration: none;
            padding: 12px 14px;
            margin-bottom: 4px;
            border-radius: 6px;
            font-size: 14px;
            font-weight: 500;
            transition: background 0.2s ease, color 0.2s ease;
        }

        .nav-item i {
            font-size: 18px;
            width: 20px;
            text-align: center;
        }

        .nav-item:hover {
            background: rgba(255, 255, 255, 0.08);
            color: #ffffff;
        }

        .nav-item.active {
            background: #2563eb;
            color: #ffffff;
        }

        /* LOGOUT AT BOTTOM */
        .logout {
            padding: 16px 14px;
            border-top: 1px solid rgba(255, 255, 255, 0.12);
        }

        /* MAIN CONTENT */
        .main-content {
            margin-left: 260px;
            width: calc(100% - 260px);
        }

        /* TOP BAR */
        .topbar {
            height: 80px;
            background: white;
            border-bottom: 1px solid #e4e7ec;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 30px;
        }

        .topbar-left {
            display: flex;
            align-items: center;
            gap: 18px;
        }

        .menu-button {
            font-size: 21px;
            color: #344054;
            cursor: pointer;
        }

        .page-title {
            font-size: 21px;
            font-weight: 600;
        }

        /* PROFILE */
        .topbar-right {
            display: flex;
            align-items: center;
            gap: 25px;
        }

        .notification {
            position: relative;
            font-size: 21px;
            cursor: pointer;
        }

        .notification-badge {
            position: absolute;
            top: -7px;
            right: -7px;
            background: #dc2626;
            color: white;
            width: 17px;
            height: 17px;
            border-radius: 50%;
            font-size: 9px;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .profile {
            display: flex;
            align-items: center;
            gap: 10px;
            cursor: pointer;
        }

        .profile-icon {
            width: 40px;
            height: 40px;
            background: #eef3ff;
            color: #1d4ed8;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .profile-info strong {
            display: block;
            font-size: 13px;
        }

        .profile-info span {
            display: block;
            font-size: 11px;
            color: #667085;
            margin-top: 3px;
        }

        /* CONTENT */
        .content {
            padding: 30px;
        }

        /* PAGE HEADER */
        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
        }

        .heading h1 {
            font-size: 26px;
            margin-bottom: 7px;
        }

        .heading p {
            font-size: 13px;
            color: #667085;
        }

        /* ADD ASSET BUTTON */
        .add-button {
            background: #2875e8;
            color: white;
            border: none;
            padding: 10px 16px;
            border-radius: 7px;
            text-decoration: none;
            font-size: 13px;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 8px;
            cursor: pointer;
        }

        .add-button:hover {
            background: #1d5fc5;
        }

        /* STAT CARDS */
        .asset-stats {
            display: grid;
            grid-template-columns: repeat(5, 1fr);
            gap: 15px;
            margin-bottom: 25px;
        }

        .stat-card {
            background: white;
            border: 1px solid #e4e7ec;
            border-radius: 10px;
            padding: 18px;
            min-height: 125px;
        }

        .stat-icon {
            width: 40px;
            height: 40px;
            border-radius: 9px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 19px;
            margin-bottom: 13px;
        }

        .total .stat-icon {
            background: #e3edff;
            color: #155eef;
        }

        .available .stat-icon {
            background: #dff7e9;
            color: #079455;
        }

        .assigned .stat-icon {
            background: #fff0d5;
            color: #d97706;
        }

        .maintenance .stat-icon {
            background: #ffe2e6;
            color: #d92d20;
        }

        .retired .stat-icon {
            background: #eaecf0;
            color: #475467;
        }

        .stat-card p {
            font-size: 11px;
            color: #667085;
            margin-bottom: 5px;
        }

        .stat-card h2 {
            font-size: 22px;
        }

        /* ASSET TABLE PANEL */
        .panel {
            background: white;
            border: 1px solid #e4e7ec;
            border-radius: 10px;
            overflow: hidden;
        }

        .panel-header {
            padding: 19px 22px;
            border-bottom: 1px solid #e4e7ec;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        .panel-title {
            display: flex;
            align-items: center;
            gap: 9px;
            font-size: 15px;
            font-weight: 600;
        }

        .panel-title i {
            color: #155eef;
        }

        /* SEARCH */
        .search-container {
            display: flex;
            gap: 9px;
        }

        .search-box {
            position: relative;
        }

        .search-box i {
            position: absolute;
            left: 12px;
            top: 11px;
            color: #98a2b3;
        }

        .search-input {
            width: 270px;
            height: 38px;
            border: 1px solid #d0d5dd;
            border-radius: 7px;
            padding-left: 35px;
            font-size: 12px;
            outline: none;
        }

        .search-input:focus {
            border-color: #2875e8;
        }

        /* TABLE */
        .table-wrapper {
            overflow-x: auto;
        }

        .asset-table {
            width: 100%;
            border-collapse: collapse;
        }

        .asset-table th {
            background: #f8fafc;
            color: #667085;
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            text-align: left;
            padding: 14px 17px;
            border-bottom: 1px solid #e4e7ec;
            white-space: nowrap;
        }

        .asset-table td {
            padding: 15px 17px;
            font-size: 12px;
            border-bottom: 1px solid #edf0f4;
            color: #344054;
        }

        .asset-table tr:hover {
            background: #fafcff;
        }

        /* ASSET TAG */
        .asset-info {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .asset-icon {
            width: 36px;
            height: 36px;
            background: #eaf1ff;
            color: #155eef;
            border-radius: 7px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 17px;
        }

        .asset-tag {
            display: block;
            font-weight: 600;
            color: #172033;
        }

        .serial-number {
            display: block;
            color: #98a2b3;
            font-size: 10px;
            margin-top: 3px;
        }

        /* BADGES */
        .type-badge {
            background: #f2f4f7;
            color: #344054;
            padding: 5px 9px;
            border-radius: 5px;
            font-size: 10px;
            font-weight: 500;
        }

        .condition-good {
            background: #dcfae6;
            color: #067647;
            padding: 5px 9px;
            border-radius: 5px;
            font-size: 10px;
            font-weight: 500;
        }

        .condition-fair {
            background: #fff1d6;
            color: #b54708;
            padding: 5px 9px;
            border-radius: 5px;
            font-size: 10px;
            font-weight: 500;
        }

        .condition-poor {
            background: #fee4e2;
            color: #b42318;
            padding: 5px 9px;
            border-radius: 5px;
            font-size: 10px;
            font-weight: 500;
        }

        /* ACTION BUTTONS */
        .actions {
            display: flex;
            gap: 7px;
        }

        .action-button {
            width: 31px;
            height: 31px;
            border: none;
            border-radius: 6px;
            display: flex;
            align-items: center;
            justify-content: center;
            text-decoration: none;
            cursor: pointer;
        }

        .view-button {
            background: #eaf1ff;
            color: #155eef;
        }

        .edit-button {
            background: #fff1df;
            color: #d97706;
        }

        .delete-button {
            background: #fee4e2;
            color: #d92d20;
        }

        .action-button:hover {
            opacity: 0.75;
        }

        /* FOOTER */
        .footer {
            text-align: center;
            color: #98a2b3;
            font-size: 11px;
            padding: 25px 0 10px;
        }

        /* RESPONSIVE */
        @media(max-width: 1200px) {
            .asset-stats {
                grid-template-columns: repeat(3, 1fr);
            }
        }

        @media(max-width: 900px) {
            .sidebar {
                width: 220px;
            }

            .main-content {
                margin-left: 220px;
                width: calc(100% - 220px);
            }

            .asset-stats {
                grid-template-columns: repeat(2, 1fr);
            }
        }
    </style>
</head>
<body>
    <form id="form1" runat="server">
        <div class="dashboard-container">
            <!--======================Sidebar========================-->
            <aside class="sidebar">
                <div class="logo">
                    <div class="logo-icon">
                        <i class="bi bi-display"></i>
                    </div>
                    <div class="logo-text">
                        IT Assets Management
                        <span>System</span>
                    </div>
                </div>
                <nav class="navigation">
                    <a href="Dashboard.aspx" class="nav-item">
                        <i class="bi bi-grid"></i> Dashboard
                    </a>
                    <a href="Users.aspx" class="nav-item">
                        <i class="bi bi-person"></i> Users
                    </a>
                    <a href="Assets.aspx" class="nav-item active">
                        <i class="bi bi-laptop"></i> Assets
                    </a>
                    <a href="AssetAssignments.aspx" class="nav-item">
                        <i class="bi bi-person-check"></i> Asset Assignments
                    </a>
                    <a href="Returns.aspx" class="nav-item">
                        <i class="bi bi-arrow-in-left"></i> Returns
                    </a>
                    <a href="Documents.aspx" class="nav-item">
                        <i class="bi bi-file-earmark-text"></i> Documents
                    </a>
                    <a href="Reports.aspx" class="nav-item">
                        <i class="bi bi-bar-chart"></i> Reports
                    </a>
                    <a href="AuditLogs.aspx" class="nav-item">
                        <i class="bi bi-shield-check"></i> Audit Logs
                    </a>
                    <a href="ImportData.aspx" class="nav-item">
                        <i class="bi bi-upload"></i> Import Data
                    </a>
                </nav>
                <div class="logout">
                    <a href="Login.aspx" class="nav-item">
                        <i class="bi bi-box-arrow-left"></i> Logout
                    </a>
                </div>
            </aside>

            <!--======================Main Content========================-->
            <main class="main-content">
                <!--Topbar-->
                <header class="topbar">
                    <div class="topbar-left">
                        <div class="menu-button">
                            <i class="bi bi-list"></i>
                        </div>
                        <div class="page-title">Assets</div>
                    </div>
                    <div class="topbar-right">
                        <div class="profile">
                            <div class="profile-icon">
                                <i class="bi bi-person-fill"></i>
                            </div>
                            <div class="profile-info">
                                <strong>
                                    <asp:Label ID="lblAdminName" runat="server">Administrator</asp:Label>
                                </strong>
                                <span>
                                    <asp:Label ID="lblAdminRole" runat="server">IT Administrator</asp:Label>
                                </span>
                            </div>
                            <i class="bi bi-chevron-down"></i>
                        </div>
                    </div>
                </header>

                <!--======================Content Area========================-->
                <section class="content">
                    <!--Page Header-->
                    <div class="page-header">
                        <div class="heading">
                            <h1>Assets Management</h1>
                            <p>Manage all your assets in one place</p>
                        </div>
                        <a href="AddAsset.aspx" class="add-button">
                            <i class="bi bi-plus-lg"></i> Add New Asset
                        </a>
                    </div>

                    <!--Stat Cards-->
                    <div class="asset-stats">
                        <div class="stat-card total">
                            <div class="stat-icon"><i class="bi bi-laptop"></i></div>
                            <p>Total Assets</p>
                            <h2><asp:Label ID="lblTotalAssets" runat="server">0</asp:Label></h2>
                        </div>
                        <div class="stat-card available">
                            <div class="stat-icon"><i class="bi bi-check-circle"></i></div>
                            <p>Available Assets</p>
                            <h2><asp:Label ID="lblAvailableAssets" runat="server">0</asp:Label></h2>
                        </div>
                        <div class="stat-card assigned">
                            <div class="stat-icon"><i class="bi bi-person-check"></i></div>
                            <p>Assigned Assets</p>
                            <h2><asp:Label ID="lblAssignedAssets" runat="server">0</asp:Label></h2>
                        </div>
                        <div class="stat-card maintenance">
                            <div class="stat-icon"><i class="bi bi-tools"></i></div>
                            <p>Under Maintenance</p>
                            <h2><asp:Label ID="lblMaintenanceAssets" runat="server">0</asp:Label></h2>
                        </div>
                        <div class="stat-card retired">
                            <div class="stat-icon"><i class="bi bi-arrow-return-left"></i></div>
                            <p>Returned Assets</p>
                            <h2><asp:Label ID="lblRetiredAssets" runat="server">0</asp:Label></h2>
                        </div>
                    </div>

                    <!--Assets Table Panel-->
                    <div class="panel">
                        <div class="panel-header">
                            <div class="panel-title">
                                <i class="bi bi-laptop"></i> Assets List
                            </div>
                            <div class="search-container">
                                <div class="search-box">
                                    <i class="bi bi-search"></i>
                                    <asp:TextBox ID="txtSearch" runat="server" CssClass="search-input" placeholder="Search assets..."></asp:TextBox>
                                </div>
                                <asp:Button ID="btnSearch" runat="server" Text="Search" CssClass="add-button" OnClick="btnSearch_Click"></asp:Button>
                            </div>
                        </div>

                        <div class="table-wrapper">
                            <table class="asset-table">
                                <thead>
                                    <tr>
                                        <th>Asset</th>
                                        <th>Asset Type</th>
                                        <th>Make</th>
                                        <th>Model</th>
                                        <th>Condition</th>
                                        <th>Warranty Expiration</th>
                                        <th>Received Date</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <asp:Repeater ID="rptAssets" runat="server">
                                        <ItemTemplate>
                                            <tr>
                                                <td>
                                                    <div class="asset-info">
                                                        <div class="asset-icon">
                                                            <i class="bi bi-laptop"></i>
                                                        </div>
                                                        <div>
                                                            <span class="asset-tag"><%# Eval("AssetTag") %></span>
                                                            <span class="serial-number">S/N: <%# Eval("SerialNumber") %></span>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td>
                                                    <span class="type-badge"><%# Eval("AssetType") %></span>
                                                </td>
                                                <td><%# Eval("Make") %></td>
                                                <td><%# Eval("Model") %></td>
                                                <td>
                                                    <span class='<%# "condition-" + Convert.ToString(Eval("Condition")).ToLower() %>'>
                                                        <%# Eval("Condition") %>
                                                    </span>
                                                </td>
                                                <td><%# Eval("WarrantyExpirationDate", "{0:yyyy-MM-dd}") %></td>
                                                <td><%# Eval("ReceiveDate", "{0:yyyy-MM-dd}") %></td>
                                                <td>
                                                    <div class="actions">
                                                        <a class="action-button view-button" title="View Asset" href='<%# "AssetDetails.aspx?id=" + Eval("AssetTag") %>'>
                                                            <i class="bi bi-eye"></i>
                                                        </a>
                                                        <a class="action-button edit-button" title="Edit Asset" href='<%# "EditAsset.aspx?id=" + Eval("AssetTag") %>'>
                                                            <i class="bi bi-pencil-square"></i>
                                                        </a>
                                                        <a class="action-button delete-button" title="Delete Asset" href='<%# "DeleteAsset.aspx?id=" + Eval("AssetTag") %>' onclick="return confirm('Are you sure you want to delete this asset?');">
                                                            <i class="bi bi-trash"></i>
                                                        </a>
                                                    </div>
                                                </td>
                                            </tr>
                                        </ItemTemplate>
                                    </asp:Repeater>
                                </tbody>
                            </table>
                        </div>
                    </div>

                    <footer class="footer">
                        &copy; 2026 IT Assets Management System. All rights reserved by S.N Nkuna.
                    </footer>
                </section>
            </main>
        </div>
    </form>
</body>
</html>