﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="Reports.aspx.cs" Inherits="Assets_Tracker.Reports" %>
<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title>Reports - IT Assets Management System</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" />

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, Helvetica, sans-serif;
        }

        body {
            background: #f4f6fb;
            color: #1f2937;
        }

        /* =========================================
           MAIN LAYOUT
        ========================================= */
        .dashboard-container {
            display: flex;
            min-height: 100vh;
        }

        /* =========================================
           SIDEBAR
        ========================================= */
        .sidebar {
            width: 260px;
            background: linear-gradient(180deg, #0f5c4d, #123a5c);
            color: white;
            display: flex;
            flex-direction: column;
            position: fixed;
            height: 100vh;
            left: 0;
            top: 0;
            z-index: 100;
            transition: width 0.3s ease;
        }

        /* LOGO */
        .logo {
            display: flex;
            align-items: center;
            gap: 15px;
            padding: 22px 20px;
            border-bottom: 1px solid rgba(255,255,255,0.12);
        }

        .logo-icon {
            width: 48px;
            height: 48px;
            border: 2px solid rgba(255,255,255,0.8);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 25px;
            flex-shrink: 0;
        }

        .logo-text {
            font-size: 18px;
            font-weight: 700;
            line-height: 1.2;
            white-space: nowrap;
        }

        .logo-text span {
            display: block;
            font-size: 14px;
            font-weight: 400;
            margin-top: 5px;
        }

        /* NAVIGATION */
        .navigation {
            padding: 20px 12px;
            flex: 1;
            overflow-y: auto;
        }

        .nav-item {
            display: flex;
            align-items: center;
            gap: 16px;
            padding: 15px 16px;
            margin-bottom: 7px;
            text-decoration: none;
            color: #e5e7eb;
            border-radius: 9px;
            font-size: 16px;
            font-weight: 600;
            transition: background 0.3s, color 0.3s;
            white-space: nowrap;
        }

        .nav-item i {
            font-size: 20px;
            flex-shrink: 0;
        }

        .nav-item:hover {
            background: rgba(255,255,255,0.1);
            color: #ffffff;
        }

        .nav-item.active {
            background: linear-gradient(135deg, #2563c7, #3f7bd7);
            color: white;
        }

        /* LOGOUT */
        .logout {
            padding: 15px 12px;
            border-top: 1px solid rgba(255,255,255,0.12);
        }

        /* =========================================
           MAIN CONTENT
        ========================================= */
        .main-content {
            margin-left: 260px;
            width: calc(100% - 260px);
            transition: margin-left 0.3s ease, width 0.3s ease;
        }

        /* =========================================
           TOPBAR
        ========================================= */
        .topbar {
            height: 90px;
            background: white;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0 35px;
            border-bottom: 1px solid #e5e7eb;
        }

        .topbar-left {
            display: flex;
            align-items: center;
            gap: 25px;
        }

        .menu-button {
            font-size: 25px;
            cursor: pointer;
            display: flex;
            align-items: center;
        }

        .page-title {
            font-size: 26px;
            font-weight: 700;
        }

        /* TOPBAR RIGHT */
        .topbar-right {
            display: flex;
            align-items: center;
            gap: 28px;
        }

        .notifications {
            position: relative;
            font-size: 22px;
            cursor: pointer;
        }

        .notification-badge {
            position: absolute;
            width: 10px;
            height: 10px;
            background: #ef4444;
            border-radius: 50%;
            top: -2px;
            right: -3px;
        }

        /* PROFILE */
        .profile {
            display: flex;
            align-items: center;
            gap: 12px;
            cursor: pointer;
        }

        .profile-icon {
            width: 48px;
            height: 48px;
            border-radius: 50%;
            background: #e8eef9;
            color: #1f5eb8;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
        }

        .profile-info {
            display: flex;
            flex-direction: column;
        }

        .profile-info strong {
            font-size: 15px;
        }

        .profile-info span {
            font-size: 13px;
            color: #64748b;
            margin-top: 4px;
        }

        /* =========================================
           CONTENT
        ========================================= */
        .content {
            padding: 35px;
        }

        /* PAGE HEADER */
        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            flex-wrap: wrap;
            gap: 15px;
        }

        .heading h1 {
            font-size: 32px;
            margin-bottom: 8px;
        }

        .heading p {
            color: #64748b;
            font-size: 16px;
        }

        /* GENERATE BUTTON */
        .generate-button {
            background: linear-gradient(135deg, #2563c7, #3b82f6);
            color: white;
            border: none;
            border-radius: 9px;
            padding: 14px 22px;
            font-size: 15px;
            font-weight: 600;
            cursor: pointer;
            text-decoration: none;
            transition: opacity 0.3s;
        }

        .generate-button:hover {
            opacity: 0.9;
        }

        /* =========================================
           STAT CARDS
        ========================================= */
        .report-stats {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 20px;
            margin-bottom: 25px;
        }

        .stat-card {
            background: white;
            border: 1px solid #e2e8f0;
            border-radius: 14px;
            padding: 22px;
            display: flex;
            align-items: center;
            gap: 18px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.03);
        }

        .stat-icon {
            width: 58px;
            height: 58px;
            border-radius: 14px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 26px;
            flex-shrink: 0;
        }

        .stat-card p {
            color: #64748b;
            font-size: 14px;
            margin-bottom: 7px;
        }

        .stat-card h2 {
            font-size: 27px;
        }

        /* CARD COLOURS */
        .blue .stat-icon {
            background: #e8f0ff;
            color: #2563eb;
        }

        .green .stat-icon {
            background: #e6f7ef;
            color: #16814d;
        }

        .orange .stat-icon {
            background: #fff3df;
            color: #d97706;
        }

        .purple .stat-icon {
            background: #f0eaff;
            color: #7c3aed;
        }

        /* =========================================
           REPORT CATEGORY CARDS
        ========================================= */
        .section-title {
            font-size: 20px;
            font-weight: 700;
            margin-bottom: 20px;
        }

        .report-types {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 18px;
            margin-bottom: 25px;
        }

        .report-type-card {
            background: white;
            border: 1px solid #e2e8f0;
            border-radius: 12px;
            padding: 20px;
            cursor: pointer;
            transition: transform 0.3s, box-shadow 0.3s;
        }

        .report-type-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 20px rgba(0,0,0,0.08);
        }

        .report-type-icon {
            width: 48px;
            height: 48px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 22px;
            margin-bottom: 15px;
        }

        .report-type-card h3 {
            font-size: 16px;
            margin-bottom: 8px;
        }

        .report-type-card p {
            color: #64748b;
            font-size: 13px;
            line-height: 1.5;
        }

        .asset-report {
            background: #e8f0ff;
            color: #2563eb;
        }

        .allocation-report {
            background: #e6f7ef;
            color: #16814d;
        }

        .employee-report {
            background: #fff3df;
            color: #d97706;
        }

        .maintenance-report {
            background: #f0eaff;
            color: #7c3aed;
        }

        /* =========================================
           LOWER GRID
        ========================================= */
        .reports-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 25px;
        }

        /* PANEL */
        .panel {
            background: white;
            border: 1px solid #e2e8f0;
            border-radius: 14px;
            overflow: hidden;
            box-shadow: 0 4px 15px rgba(0,0,0,0.03);
        }

        .panel-header {
            padding: 20px 22px;
            border-bottom: 1px solid #e5e7eb;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .panel-title {
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 18px;
            font-weight: 700;
        }

        .panel-title i {
            color: #2563c7;
        }

        /* ASSET SUMMARY */
        .summary-content {
            padding: 25px;
        }

        .summary-row {
            margin-bottom: 22px;
        }

        .summary-row:last-child {
            margin-bottom: 0;
        }

        .summary-info {
            display: flex;
            justify-content: space-between;
            margin-bottom: 8px;
            font-size: 14px;
        }

        .summary-bar {
            height: 10px;
            background: #edf2f7;
            border-radius: 10px;
            overflow: hidden;
        }

        .progress {
            height: 100%;
            border-radius: 10px;
        }

        .available-progress {
            width: 75%;
            background: #22c55e;
        }

        .assigned-progress {
            width: 85%;
            background: #f59e0b;
        }

        .maintenance-progress {
            width: 35%;
            background: #ef4444;
        }

        .retired-progress {
            width: 20%;
            background: #64748b;
        }

        /* RECENT ACTIVITY */
        .activity-list {
            padding: 10px 20px 20px 20px;
        }

        .activity-item {
            display: flex;
            align-items: center;
            gap: 15px;
            padding: 15px 0;
            border-bottom: 1px solid #edf2f7;
        }

        .activity-item:last-child {
            border-bottom: none;
        }

        .activity-icon {
            width: 42px;
            height: 42px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-shrink: 0;
        }

        .activity-icon.assign {
            background: #e8f0ff;
            color: #2563eb;
        }

        .activity-icon.return {
            background: #e6f7ef;
            color: #16a34a;
        }

        .activity-icon.asset {
            background: #fff3df;
            color: #d97706;
        }

        .activity-info {
            flex: 1;
        }

        .activity-info strong {
            display: block;
            font-size: 14px;
            margin-bottom: 4px;
        }

        .activity-info span {
            color: #64748b;
            font-size: 13px;
        }

        .activity-date {
            color: #94a3b8;
            font-size: 12px;
            white-space: nowrap;
        }

        /* =========================================
           REPORT ACTIONS
        ========================================= */
        .report-actions {
            margin-top: 25px;
            background: white;
            border: 1px solid #e2e8f0;
            border-radius: 14px;
            padding: 22px;
        }

        .action-buttons {
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
            margin-top: 18px;
        }

        .report-button {
            padding: 13px 18px;
            border: 1px solid #dbe3ef;
            background: white;
            border-radius: 9px;
            text-decoration: none;
            color: #334155;
            font-weight: 600;
            cursor: pointer;
            transition: background 0.3s;
        }

        .report-button i {
            margin-right: 8px;
        }

        .report-button:hover {
            background: #f1f5f9;
        }

        /* =========================================
           FOOTER
        ========================================= */
        .footer {
            text-align: center;
            color: #94a3b8;
            padding: 35px 0 10px 0;
            font-size: 14px;
        }

        /* =========================================
           RESPONSIVE
        ========================================= */
        @media(max-width: 1200px) {
            .report-stats {
                grid-template-columns: repeat(2, 1fr);
            }

            .report-types {
                grid-template-columns: repeat(2, 1fr);
            }
        }

        @media(max-width: 900px) {
            .sidebar {
                width: 80px;
            }

            .logo-text,
            .nav-item span {
                display: none;
            }

            .main-content {
                margin-left: 80px;
                width: calc(100% - 80px);
            }

            .reports-grid {
                grid-template-columns: 1fr;
            }
        }

        @media(max-width: 600px) {
            .report-stats,
            .report-types {
                grid-template-columns: 1fr;
            }

            .topbar {
                padding: 0 15px;
            }

            .content {
                padding: 20px 15px;
            }
        }
    </style>
</head>

<body>
<form id="form1" runat="server">
<div class="dashboard-container">

    <!-- ======= SIDEBAR ============= -->
    <aside class="sidebar">
        <!-- LOGO -->
        <div class="logo">
            <div class="logo-icon">
                <i class="bi bi-display"></i>
            </div>
            <div class="logo-text">
                IT Assets Management
                <span>System</span>
            </div>
        </div>
        <!-- NAVIGATION -->
        <nav class="navigation">
            <a href="Dashboard.aspx" class="nav-item">
                <i class="bi bi-grid"></i>
                <span>Dashboard</span>
            </a>
            <a href="Users.aspx" class="nav-item">
                <i class="bi bi-person"></i>
                <span>Users</span>
            </a>
            <a href="Assets.aspx" class="nav-item">
                <i class="bi bi-laptop"></i>
                <span>Assets</span>
            </a>
            <a href="AssetAssignments.aspx" class="nav-item">
                <i class="bi bi-person-check"></i>
                <span>Asset Assignments</span>
            </a>
            <a href="Returns.aspx" class="nav-item">
                <i class="bi bi-arrow-return-left"></i>
                <span>Returns</span>
            </a>
            <a href="Documents.aspx" class="nav-item">
                <i class="bi bi-file-earmark-text"></i>
                <span>Documents</span>
            </a>
            <a href="Reports.aspx" class="nav-item active">
                <i class="bi bi-bar-chart"></i>
                <span>Reports</span>
            </a>
            <a href="AuditLogs.aspx" class="nav-item">
                <i class="bi bi-shield-check"></i>
                <span>Audit Logs</span>
            </a>
            <a href="ImportData.aspx" class="nav-item">
                <i class="bi bi-upload"></i>
                <span>Import Data</span>
            </a>
        </nav>
        <!-- LOGOUT -->
        <div class="logout">
            <a href="LoginPage.aspx" class="nav-item">
                <i class="bi bi-box-arrow-left"></i>
                <span>Logout</span>
            </a>
        </div>
    </aside>

    <!-- =========== MAIN CONTENT ============== -->
    <main class="main-content">
        <!-- TOPBAR -->
        <header class="topbar">
            <div class="topbar-left">
                <div class="menu-button">
                    <i class="bi bi-list"></i>
                </div>
                <div class="page-title">
                    Reports
                </div>
            </div>
            <div class="topbar-right">
                <div class="profile">
                    <div class="profile-icon">
                        <i class="bi bi-person-fill"></i>
                    </div>
                    <div class="profile-info">
                        <strong>
                            <asp:Label ID="lblAdminName" runat="server" Text="Administrator"></asp:Label>
                        </strong>
                        <span>
                            <asp:Label ID="lblAdminRole" runat="server" Text="IT Administrator"></asp:Label>
                        </span>
                    </div>
                    <i class="bi bi-chevron-down"></i>
                </div>
            </div>
        </header>

        <!-- ======== CONTENT =============== -->
        <section class="content">
            <!-- PAGE HEADER -->
            <div class="page-header">
                <div class="heading">
                    <h1>Reports & Analytics</h1>
                    <p>View, analyse and generate reports for your IT assets.</p>
                </div>
                <asp:Button ID="btnGenerateReport" runat="server" Text="Generate Report" CssClass="generate-button" OnClick="btnGenerateReport_Click" />
            </div>

            <!-- ================ STATISTICS ==================== -->
            <div class="report-stats">
                <!-- TOTAL ASSETS -->
                <div class="stat-card blue">
                    <div class="stat-icon">
                        <i class="bi bi-laptop"></i>
                    </div>
                    <div>
                        <p>Total Assets</p>
                        <h2>
                            <asp:Label ID="lblTotalAssets" runat="server" Text="0"></asp:Label>
                        </h2>
                    </div>
                </div>
                <!-- TOTAL EMPLOYEES -->
                <div class="stat-card green">
                    <div class="stat-icon">
                        <i class="bi bi-people"></i>
                    </div>
                    <div>
                        <p>Total Employees</p>
                        <h2>
                            <asp:Label ID="lblTotalEmployees" runat="server" Text="0"></asp:Label>
                        </h2>
                    </div>
                </div>
                <!-- ACTIVE ASSIGNMENTS -->
                <div class="stat-card orange">
                    <div class="stat-icon">
                        <i class="bi bi-person-check"></i>
                    </div>
                    <div>
                        <p>Active Assignments</p>
                        <h2>
                            <asp:Label ID="lblActiveAssignments" runat="server" Text="0"></asp:Label>
                        </h2>
                    </div>
                </div>
                <!-- RETURNED ASSETS -->
                <div class="stat-card purple">
                    <div class="stat-icon">
                        <i class="bi bi-arrow-return-left"></i>
                    </div>
                    <div>
                        <p>Returned Assets</p>
                        <h2>
                            <asp:Label ID="lblReturnedAssets" runat="server" Text="0"></asp:Label>
                        </h2>
                    </div>
                </div>
            </div>

            <!-- ========== REPORT TYPES ================= -->
            <h2 class="section-title">Available Reports</h2>
            <div class="report-types">
                <!-- ASSET REPORT -->
                <div class="report-type-card">
                    <div class="report-type-icon asset-report">
                        <i class="bi bi-laptop"></i>
                    </div>
                    <h3>Asset Report</h3>
                    <p>View a complete report of all registered IT assets.</p>
                </div>
                <!-- ALLOCATION REPORT -->
                <div class="report-type-card">
                    <div class="report-type-icon allocation-report">
                        <i class="bi bi-person-check"></i>
                    </div>
                    <h3>Allocation Report</h3>
                    <p>View all current and previous asset assignments.</p>
                </div>
                <!-- EMPLOYEE REPORT -->
                <div class="report-type-card">
                    <div class="report-type-icon employee-report">
                        <i class="bi bi-people"></i>
                    </div>
                    <h3>Employee Report</h3>
                    <p>View employees and the assets assigned to them.</p>
                </div>
                <!-- MAINTENANCE REPORT -->
                <div class="report-type-card">
                    <div class="report-type-icon maintenance-report">
                        <i class="bi bi-tools"></i>
                    </div>
                    <h3>Maintenance Report</h3>
                    <p>View all assets currently under maintenance.</p>
                </div>
            </div>

            <!-- ======================= REPORT SUMMARY + ACTIVITY ===================== -->
            <div class="reports-grid">
                <!-- ASSET SUMMARY -->
                <div class="panel">
                    <div class="panel-header">
                        <div class="panel-title">
                            <i class="bi bi-pie-chart"></i>
                            Asset Status Summary
                        </div>
                    </div>
                    <div class="summary-content">
                        <!-- AVAILABLE -->
                        <div class="summary-row">
                            <div class="summary-info">
                                <span>Available Assets</span>
                                <strong>
                                    <asp:Label ID="lblAvailableAssets" runat="server" Text="0"></asp:Label>
                                </strong>
                            </div>
                            <div class="summary-bar">
                                <div class="progress available-progress"></div>
                            </div>
                        </div>
                        <!-- ASSIGNED -->
                        <div class="summary-row">
                            <div class="summary-info">
                                <span>Assigned Assets</span>
                                <strong>
                                    <asp:Label ID="lblAssignedAssets" runat="server" Text="0"></asp:Label>
                                </strong>
                            </div>
                            <div class="summary-bar">
                                <div class="progress assigned-progress"></div>
                            </div>
                        </div>
                        <!-- MAINTENANCE -->
                        <div class="summary-row">
                            <div class="summary-info">
                                <span>Under Maintenance</span>
                                <strong>
                                    <asp:Label ID="lblMaintenanceAssets" runat="server" Text="0"></asp:Label>
                                </strong>
                            </div>
                            <div class="summary-bar">
                                <div class="progress maintenance-progress"></div>
                            </div>
                        </div>
                        <!-- RETIRED -->
                        <div class="summary-row">
                            <div class="summary-info">
                                <span>Retired Assets</span>
                                <strong>
                                    <asp:Label ID="lblRetiredAssets" runat="server" Text="0"></asp:Label>
                                </strong>
                            </div>
                            <div class="summary-bar">
                                <div class="progress retired-progress"></div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- RECENT ACTIVITY -->
                <div class="panel">
                    <div class="panel-header">
                        <div class="panel-title">
                            <i class="bi bi-clock-history"></i>
                            Recent Activity
                        </div>
                    </div>
                    <div class="activity-list">
                        <asp:Repeater ID="rptRecentActivity" runat="server">
                            <ItemTemplate>
                                <div class="activity-item">
                                    <div class="activity-icon assign">
                                        <i class="bi bi-person-check"></i>
                                    </div>
                                    <div class="activity-info">
                                        <strong><%# Eval("ActivityTitle") %></strong>
                                        <span><%# Eval("ActivityDescription") %></span>
                                    </div>
                                    <div class="activity-date">
                                        <%# Eval("ActivityDate", "{0:dd MMM yyyy}") %>
                                    </div>
                                </div>
                            </ItemTemplate>
                        </asp:Repeater>
                    </div>
                </div>
            </div>

            <!-- =================== QUICK REPORT ACTION ================= -->
            <div class="report-actions">
                <h2 class="section-title">Quick Report Generation</h2>
                <div class="action-buttons">
                    <asp:Button ID="btnAssetReport" runat="server" Text="📊 Generate Asset Report" CssClass="report-button" OnClick="btnAssetReport_Click" />
                    <asp:Button ID="btnEmployeeReport" runat="server" Text="👥 Generate Employee Report" CssClass="report-button" OnClick="btnEmployeeReport_Click" />
                    <asp:Button ID="btnAllocationReport" runat="server" Text="📋 Generate Allocation Report" CssClass="report-button" OnClick="btnAllocationReport_Click" />
                    <asp:Button ID="btnReturnReport" runat="server" Text="↩ Generate Return Report" CssClass="report-button" OnClick="btnReturnReport_Click" />
                </div>
            </div>

            <!-- FOOTER -->
            <footer class="footer">
                &copy; 2026 IT Assets Management System. All rights reserved by S.N Nkuna.
            </footer>
        </section>
    </main>
</div>
</form>
</body>
</html>