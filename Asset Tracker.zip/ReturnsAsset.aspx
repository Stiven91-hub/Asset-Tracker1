﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="ReturnsAsset.aspx.cs" Inherits="Assets_Tracker.ReturnsAsset" %>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title>Return Asset - IT Assets Management System</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" />
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, Helvetica, sans-serif;
        }
        body {
            background: #f4f6fb;
            color: #333;
        }
        .dashboard-container {
            display: flex;
            min-height: 100vh;
        }
        /* ================= SIDEBAR ================= */
        .sidebar {
            width: 260px;
            min-height: 100vh;
            background: linear-gradient(180deg, #0f5c4d, #123a5c);
            color: white;
            position: fixed;
            left: 0;
            top: 0;
            bottom: 0;
            padding: 20px 15px;
        }
        .logo {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 10px 8px 25px;
            border-bottom: 1px solid rgba(255,255,255,0.15);
        }
        .logo-icon {
            width: 45px;
            height: 45px;
            background: rgba(255,255,255,0.15);
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 22px;
        }
        .logo-text {
            font-size: 15px;
            font-weight: bold;
            line-height: 20px;
        }
        .logo-text span {
            display: block;
            font-size: 12px;
            font-weight: normal;
            opacity: 0.8;
        }
        .navigation {
            margin-top: 25px;
        }
        .nav-item {
            display: flex;
            align-items: center;
            gap: 13px;
            color: white;
            text-decoration: none;
            padding: 13px 15px;
            margin-bottom: 6px;
            border-radius: 8px;
            font-size: 14px;
            transition: 0.2s;
        }
        .nav-item i {
            font-size: 18px;
        }
        .nav-item:hover {
            background: rgba(255,255,255,0.12);
        }
        .nav-item.active {
            background: linear-gradient(90deg, #2563c7, #3f7bd7);
        }
        .logout {
            position: absolute;
            bottom: 20px;
            left: 15px;
            right: 15px;
        }
        /* ================= MAIN CONTENT ================= */
        .main-content {
            margin-left: 260px;
            width: calc(100% - 260px);
            min-height: 100vh;
        }
        /* ================= TOPBAR ================= */
        .topbar {
            height: 75px;
            background: white;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 30px;
            border-bottom: 1px solid #e5e7eb;
        }
        .topbar-left {
            display: flex;
            align-items: center;
            gap: 18px;
        }
        .menu-button {
            width: 40px;
            height: 40px;
            border-radius: 8px;
            background: #f1f5f9;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 22px;
            color: #334155;
        }
        .page-title {
            font-size: 20px;
            font-weight: bold;
            color: #1e293b;
        }
        .topbar-right {
            display: flex;
            align-items: center;
            gap: 25px;
        }
        .notifications {
            position: relative;
            font-size: 21px;
            color: #475569;
        }
        .notification-badge {
            position: absolute;
            top: -2px;
            right: -3px;
            width: 8px;
            height: 8px;
            background: #ef4444;
            border-radius: 50%;
        }
        .profile {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .profile-icon {
            width: 40px;
            height: 40px;
            background: #e8eef8;
            color: #2563c7;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .profile-info strong {
            display: block;
            font-size: 14px;
            color: #1e293b;
        }
        .profile-info span {
            display: block;
            font-size: 12px;
            color: #64748b;
            margin-top: 2px;
        }
        /* ================= CONTENT ================= */
        .content {
            padding: 30px;
        }
        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
        }
        .heading h1 {
            font-size: 27px;
            color: #1e293b;
            margin-bottom: 6px;
        }
        .heading p {
            color: #64748b;
            font-size: 14px;
        }
        .back-button {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 11px 18px;
            background: #64748b;
            color: white;
            text-decoration: none;
            border-radius: 7px;
            font-size: 14px;
        }
        .back-button:hover {
            background: #475569;
        }
        /* ================= FORM PANEL ================= */
        .form-panel {
            background: white;
            border-radius: 12px;
            box-shadow: 0 3px 12px rgba(0,0,0,0.06);
            overflow: hidden;
            max-width: 1000px;
        }
        .panel-header {
            padding: 20px 25px;
            border-bottom: 1px solid #e5e7eb;
            display: flex;
            align-items: center;
            gap: 12px;
        }
        .panel-header i {
            width: 40px;
            height: 40px;
            background: #e8f0ff;
            color: #2563c7;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
        }
        .panel-header h2 {
            font-size: 18px;
            color: #1e293b;
        }
        .panel-header p {
            color: #64748b;
            font-size: 13px;
            margin-top: 3px;
        }
        .form-body {
            padding: 28px;
        }
        .section-title {
            font-size: 16px;
            font-weight: bold;
            color: #123a5c;
            margin-bottom: 18px;
            padding-bottom: 10px;
            border-bottom: 1px solid #e5e7eb;
        }
        .form-row {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 20px;
            margin-bottom: 20px;
        }
        .form-group {
            display: flex;
            flex-direction: column;
        }
        .form-group.full {
            grid-column: 1 / -1;
        }
        .form-group label {
            font-size: 13px;
            font-weight: bold;
            color: #334155;
            margin-bottom: 7px;
        }
        .required {
            color: #dc2626;
        }
        .form-control {
            width: 100%;
            height: 43px;
            border: 1px solid #d1d5db;
            border-radius: 7px;
            padding: 0 12px;
            font-size: 14px;
            color: #334155;
            background: white;
            outline: none;
        }
        .form-control:focus {
            border-color: #2563c7;
            box-shadow: 0 0 0 3px rgba(37,99,199,0.10);
        }
        textarea.form-control {
            height: 100px;
            padding-top: 10px;
            resize: vertical;
        }
        /* ================= EMPLOYEE INFORMATION ================= */
        .employee-card {
            background: #f8fafc;
            border: 1px solid #e2e8f0;
            border-radius: 9px;
            padding: 18px;
            margin-top: 5px;
            margin-bottom: 25px;
        }
        .employee-card-title {
            font-size: 13px;
            font-weight: bold;
            color: #123a5c;
            margin-bottom: 12px;
        }
        .employee-details {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 15px;
        }
        .detail-item span {
            display: block;
            font-size: 11px;
            color: #64748b;
            margin-bottom: 4px;
        }
        .detail-item strong {
            font-size: 13px;
            color: #1e293b;
        }
        /* ================= ASSET INFORMATION ================= */
        .asset-card {
            background: #f8fafc;
            border: 1px solid #e2e8f0;
            border-radius: 9px;
            padding: 18px;
            margin-top: 5px;
            margin-bottom: 25px;
        }
        .asset-details {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 15px;
        }
        /* ================= MESSAGE ================= */
        .message {
            display: block;
            padding: 12px 15px;
            border-radius: 7px;
            margin-bottom: 20px;
            font-size: 13px;
        }
        /* ================= BUTTONS ================= */
        .form-actions {
            display: flex;
            justify-content: flex-end;
            gap: 12px;
            padding-top: 20px;
            border-top: 1px solid #e5e7eb;
            margin-top: 10px;
        }
        .btn {
            border: none;
            border-radius: 7px;
            padding: 12px 22px;
            font-size: 14px;
            font-weight: bold;
            cursor: pointer;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }
        .btn-return {
            background: linear-gradient(90deg, #2563c7, #3b82f6);
            color: white;
        }
        .btn-return:hover {
            opacity: 0.9;
        }
        .btn-cancel {
            background: #e2e8f0;
            color: #334155;
        }
        .btn-cancel:hover {
            background: #cbd5e1;
        }
        /* ================= FOOTER ================= */
        .footer {
            margin-top: 30px;
            padding: 20px 0;
            text-align: center;
            color: #94a3b8;
            font-size: 12px;
        }
        @media(max-width: 900px) {
            .sidebar {
                width: 220px;
            }
            .main-content {
                margin-left: 220px;
                width: calc(100% - 220px);
            }
            .form-row {
                grid-template-columns: 1fr;
            }
            .employee-details,
            .asset-details {
                grid-template-columns: repeat(2, 1fr);
            }
        }
    </style>
</head>
<body>
<form id="form1" runat="server">
<div class="dashboard-container">
    <!-- ====================== SIDEBAR ====================== -->
    <aside class="sidebar">
        <div class="logo">
            <div class="logo-icon">
                <i class="bi bi-display"></i>
            </div>
            <div class="logo-text">
                IT Assets Management System
                <span>System</span>
            </div>
        </div>
        <nav class="navigation">
            <a href="Dashboard.aspx" class="nav-item">
                <i class="bi bi-grid"></i>
                Dashboard
            </a>
            <a href="Users.aspx" class="nav-item">
                <i class="bi bi-person"></i>
                Users
            </a>
            <a href="Assets.aspx" class="nav-item">
                <i class="bi bi-laptop"></i>
                Assets
            </a>
            <a href="AssetAssignments.aspx" class="nav-item">
                <i class="bi bi-person-check"></i>
                Asset Assignments
            </a>
            <a href="Returns.aspx" class="nav-item active">
                <i class="bi bi-arrow-return-left"></i>
                Returns
            </a>
            <a href="Documents.aspx" class="nav-item">
                <i class="bi bi-file-earmark-text"></i>
                Documents
            </a>
            <a href="Reports.aspx" class="nav-item">
                <i class="bi bi-bar-chart"></i>
                Reports
            </a>
            <a href="AditLogs.aspx" class="nav-item">
                <i class="bi bi-shield-check"></i>
                Audit Logs
            </a>
        </nav>
        <div class="logout">
            <a href="Login.aspx" class="nav-item">
                <i class="bi bi-box-arrow-left"></i>
                Logout
            </a>
        </div>
    </aside>
    <!-- ====================== MAIN CONTENT ====================== -->
    <main class="main-content">
        <!-- TOPBAR -->
        <header class="topbar">
            <div class="topbar-left">
                <div class="menu-button">
                    <i class="bi bi-list"></i>
                </div>
                <div class="page-title">
                    Return Asset
                </div>
            </div>
            <div class="topbar-right">
                <div class="notifications">
                    <i class="bi bi-bell"></i>
                    <span class="notification-badge"></span>
                </div>
                <div class="profile">
                    <div class="profile-icon">
                        <i class="bi bi-person-fill"></i>
                    </div>
                    <div class="profile-info">
                        <strong>
                            <asp:Label ID="lblAdminName" runat="server" Text="Administrator"></asp:Label>
                        </strong>
                        <span>
                            <asp:Label ID="lblAdminRole" runat="server" Text="IT Administrator"></asp:Label>
                        </span>
                    </div>
                    <i class="bi bi-chevron-down"></i>
                </div>
            </div>
        </header>
        <!-- CONTENT -->
        <section class="content">
            <div class="page-header">
                <div class="heading">
                    <h1>Return Asset</h1>
                    <p>Record the return of an IT asset from an employee</p>
                </div>
                <a href="Returns.aspx" class="back-button">
                    <i class="bi bi-arrow-left"></i>
                    Back to Returns
                </a>
            </div>
            <!-- FORM PANEL -->
            <div class="form-panel">
                <div class="panel-header">
                    <i class="bi bi-arrow-return-left"></i>
                    <div>
                        <h2>Asset Return Details</h2>
                        <p>Select the employee and asset being returned</p>
                    </div>
                </div>
                <div class="form-body">
                    <asp:Label ID="lblMessage" runat="server" CssClass="message"></asp:Label>
                    <!-- EMPLOYEE -->
                    <div class="section-title">
                        <i class="bi bi-person"></i>
                        Employee Information
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label>Employee <span class="required">*</span></label>
                            <asp:DropDownList ID="ddlEmployee" runat="server" CssClass="form-control" AutoPostBack="true" OnSelectedIndexChanged="ddlEmployee_SelectedIndexChanged">
                                <asp:ListItem Text="-- Select Employee --" Value=""></asp:ListItem>
                            </asp:DropDownList>
                        </div>
                        <div class="form-group">
                            <label>Employee Number</label>
                            <asp:TextBox ID="txtEmployeeNumber" runat="server" CssClass="form-control" ReadOnly="true"></asp:TextBox>
                        </div>
                    </div>
                    <!-- EMPLOYEE DETAILS -->
                    <asp:Panel ID="pnlEmployeeDetails" runat="server" CssClass="employee-card" Visible="false">
                        <div class="employee-card-title">Employee Details</div>
                        <div class="employee-details">
                            <div class="detail-item">
                                <span>Full Name</span>
                                <strong><asp:Label ID="lblEmployeeName" runat="server"></asp:Label></strong>
                            </div>
                            <div class="detail-item">
                                <span>Job Title</span>
                                <strong><asp:Label ID="lblJobTitle" runat="server"></asp:Label></strong>
                            </div>
                            <div class="detail-item">
                                <span>Contact Number</span>
                                <strong><asp:Label ID="lblPhoneNumber" runat="server"></asp:Label></strong>
                            </div>
                        </div>
                    </asp:Panel>
                    <!-- ASSET -->
                    <div class="section-title">
                        <i class="bi bi-laptop"></i>
                        Asset Information
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label>Assigned Asset <span class="required">*</span></label>
                            <asp:DropDownList ID="ddlAsset" runat="server" CssClass="form-control" AutoPostBack="true" OnSelectedIndexChanged="ddlAsset_SelectedIndexChanged">
                                <asp:ListItem Text="-- Select Asset --" Value=""></asp:ListItem>
                            </asp:DropDownList>
                        </div>
                        <div class="form-group">
                            <label>Asset Tag</label>
                            <asp:TextBox ID="txtAssetTag" runat="server" CssClass="form-control" ReadOnly="true"></asp:TextBox>
                        </div>
                    </div>
                    <!-- ASSET DETAILS -->
                    <asp:Panel ID="pnlAssetDetails" runat="server" CssClass="asset-card" Visible="false">
                        <div class="employee-card-title">Asset Details</div>
                        <div class="asset-details">
                            <div class="detail-item">
                                <span>Asset Type</span>
                                <strong><asp:Label ID="lblAssetType" runat="server"></asp:Label></strong>
                            </div>
                            <div class="detail-item">
                                <span>Make</span>
                                <strong><asp:Label ID="lblMake" runat="server"></asp:Label></strong>
                            </div>
                            <div class="detail-item">
                                <span>Model</span>
                                <strong><asp:Label ID="lblModel" runat="server"></asp:Label></strong>
                            </div>
                            <div class="detail-item">
                                <span>Serial Number</span>
                                <strong><asp:Label ID="lblSerialNumber" runat="server"></asp:Label></strong>
                            </div>
                        </div>
                    </asp:Panel>
                    <!-- RETURN DETAILS -->
                    <div class="section-title">
                        <i class="bi bi-clipboard-check"></i>
                        Return Details
                    </div>
                    <div class="form-row">
                        <div class="form-group">
                            <label>Return Date <span class="required">*</span></label>
                            <asp:TextBox ID="txtReturnDate" runat="server" CssClass="form-control" TextMode="Date"></asp:TextBox>
                        </div>
                        <div class="form-group">
                            <label>Asset Condition <span class="required">*</span></label>
                            <asp:DropDownList ID="ddlCondition" runat="server" CssClass="form-control">
                                <asp:ListItem Text="-- Select Condition --" Value=""></asp:ListItem>
                                <asp:ListItem Text="Good" Value="Good"></asp:ListItem>
                                <asp:ListItem Text="Fair" Value="Fair"></asp:ListItem>
                                <asp:ListItem Text="Damaged" Value="Damaged"></asp:ListItem>
                                <asp:ListItem Text="Under Maintenance" Value="Under Maintenance"></asp:ListItem>
                            </asp:DropDownList>
                        </div>
                        <div class="form-group full">
                            <label>Return Notes</label>
                            <asp:TextBox ID="txtReturnNotes" runat="server" CssClass="form-control" TextMode="MultiLine" placeholder="Enter any notes about the returned asset..."></asp:TextBox>
                        </div>
                    </div>
                    <!-- BUTTONS -->
                    <div class="form-actions">
                        <asp:Button ID="btnCancel" runat="server" Text="Cancel" CssClass="btn btn-cancel" OnClick="btnCancel_Click" />
                        <asp:Button ID="btnReturnAsset" runat="server" Text="Return Asset" CssClass="btn btn-return" OnClick="btnReturnAsset_Click" OnClientClick="return confirm('Are you sure you want to record this asset as returned?');" />
                    </div>
                </div>
            </div>
            <!-- FOOTER -->
            <footer class="footer">
                &copy; 2026 IT Assets Management System.
                All rights reserved.
            </footer>
        </section>
    </main>
</div>
</form>
</body>
</html>