IT ASSET MANAGEMENT SYSTEM - DEPLOYMENT PACKAGE

This package contains the supplied ASP.NET Web Forms application and its compiled
bin folder.

IMPORTANT:
The supplied database file is a SQL Server backup. It is NOT an .mdf file.
Restore Tracker_Database.bak into your hosted MSSQL database before starting
the website.

The Web.config connection string has intentionally been changed to:
__MONSTERASP_CONNECTION_STRING__

Replace that value with the connection string supplied by your hosting control
panel. Do not upload local Integrated Security=True settings to the hosted site.

The application expects the connection string name:
ITAssetDB

DATABASE:
Tracker_Database.bak is supplied separately with this package.

MONSTERASP:
1. Create an MSSQL database in the control panel.
2. Restore Tracker_Database.bak using the database Backups/Restore function.
3. Copy the hosted database connection string into Web.config under ITAssetDB.
4. Upload/publish the contents of this website package.
5. Test LoginPage.aspx.

NOTE:
The website cannot be fully connected to the hosted database until the hosting
provider's server/database/login details are entered. Those details are unique
to your account, so they cannot be generated in advance.
