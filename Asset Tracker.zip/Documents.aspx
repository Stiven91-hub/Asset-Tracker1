﻿<%@ Page Language="C#" AutoEventWireup="true"
    CodeBehind="Documents.aspx.cs"
    Inherits="Assets_Tracker.Documents" %>

<!DOCTYPE html>

<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title>Documents - IT Assets Management System</title>
    <link rel="stylesheet"
        href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" />

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, Helvetica, sans-serif;
        }

        body {
            background: #f4f6fb;
            color: #1f2d3d;
        }

        .dashboard-container {
            display: flex;
            min-height: 100vh;
        }

        /*=============== Sidebar ============*/

        .sidebar {
            width: 260px;
            min-height: 100vh;
            background: linear-gradient(180deg, #0b4f46 0%, #12345c 100%);
            color: white;
            position: fixed;
            left: 0;
            top: 0;
            bottom: 0;
            display: flex;
            flex-direction: column;
            z-index: 100;
        }

        .logo {
            display: flex;
            align-items: center;
            gap: 15px;
            padding: 22px 18px;
            border-bottom: 1px solid rgba(255,255,255,0.12);
        }

        .logo-icon {
            width: 48px;
            height: 48px;
            border: 2px solid rgba(255,255,255,0.8);
            border-radius: 10px;
            display: flex;
            justify-content: center;
            align-items: center;
            font-size: 24px;
        }

        .logo-text {
            font-size: 18px;
            font-weight: 700;
            line-height: 1.3;
        }

        .logo-text span {
            display: block;
            font-size: 14px;
            font-weight: 400;
            margin-top: 2px;
        }

        .navigation {
            padding: 18px 10px;
            overflow-y: auto;
        }

        .nav-item {
            display: flex;
            align-items: center;
            gap: 18px;
            color: #e7edf5;
            text-decoration: none;
            padding: 15px 16px;
            margin-bottom: 7px;
            border-radius: 9px;
            font-size: 16px;
            font-weight: 600;
            transition: 0.3s;
        }

        .nav-item i {
            font-size: 21px;
        }

        .nav-item:hover {
            background: rgba(255,255,255,0.10);
        }

        .nav-item.active {
            background: linear-gradient(90deg, #285fc0, #3975d5);
            color: white;
        }

        .logout {
            margin-top: auto;
            padding: 15px 10px;
            border-top: 1px solid rgba(255,255,255,0.12);
        }

        /* ============ MAIN CONTENT ============== */

        .main-content {
            margin-left: 260px;
            width: calc(100% - 260px);
            min-height: 100vh;
        }

        /* ================ TOPBAR =================== */

        .topbar {
            height: 80px;
            background: #ffffff;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0 30px;
            border-bottom: 1px solid #e1e5ec;
        }

        .topbar-left {
            display: flex;
            align-items: center;
            gap: 25px;
        }

        .menu-button {
            font-size: 25px;
            cursor: pointer;
        }

        .page-title {
            font-size: 24px;
            font-weight: 700;
            color: #1d2b3c;
        }

        .topbar-right {
            display: flex;
            align-items: center;
            gap: 25px;
        }

        .profile {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .profile-icon {
            width: 48px;
            height: 48px;
            background: #edf2f8;
            border-radius: 50%;
            display: flex;
            justify-content: center;
            align-items: center;
            color: #1e4eaa;
            font-size: 22px;
        }

        .profile-info {
            display: flex;
            flex-direction: column;
        }

        .profile-info strong {
            font-size: 15px;
        }

        .profile-info span {
            font-size: 13px;
            color: #687385;
            margin-top: 4px;
        }

        /* ============== CONTENT ====================== */

        .content {
            padding: 30px;
        }

        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
        }

        .heading h1 {
            font-size: 27px;
            color: #223247;
            margin-bottom: 8px;
        }

        .heading p {
            color: #657184;
            font-size: 15px;
        }

        /* =============== BUTTONS & INPUTS ==================== */

        .header-buttons {
            display: flex;
            gap: 12px;
        }

        .upload-button {
            background: white;
            border: 1px solid #d7dce5;
            color: #2b3c50;
            padding: 12px 20px;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: 0.2s;
        }

        .create-button {
            background: linear-gradient(90deg, #285fc0, #3675d3);
            border: none;
            color: white;
            padding: 12px 20px;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: 0.2s;
        }

        .search-btn {
            background: #285fc0;
            color: white;
            border: none;
            padding: 0 16px;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: 0.2s;
        }

        .reset-btn {
            background: #f4f6fb;
            color: #4f5d6e;
            border: 1px solid #d6dce5;
            padding: 0 16px;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            transition: 0.2s;
        }

        .upload-button:hover,
        .create-button:hover,
        .search-btn:hover,
        .reset-btn:hover {
            opacity: 0.9;
        }

        /* ================ STATISTICS ========================== */

        .document-stats {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 16px;
            margin-bottom: 24px;
        }

        .stat-card {
            background: white;
            border: 1px solid #dce2ea;
            border-radius: 12px;
            padding: 20px;
            display: flex;
            align-items: center;
            gap: 17px;
            min-height: 110px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.03);
        }

        .stat-icon {
            width: 60px;
            height: 60px;
            border-radius: 14px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 28px;
            flex-shrink: 0;
        }

        .stat-card p {
            font-size: 14px;
            color: #4f5d6e;
            margin-bottom: 4px;
        }

        .stat-card h2 {
            font-size: 26px;
            color: #1f2d3d;
        }

        .blue-icon { background: #eaf1ff; color: #2362bf; }
        .green-icon { background: #e8f6ee; color: #23824d; }
        .orange-icon { background: #fff4df; color: #dc8a00; }
        .red-icon { background: #ffeaea; color: #d62828; }

        /* ================= REQUIRED DOCUMENTS SECTION ================= */

        .documents-panel {
            background: white;
            border: 1px solid #dce2ea;
            border-radius: 12px;
            padding: 20px;
            margin-bottom: 24px;
        }

        .section-title {
            font-size: 18px;
            font-weight: 700;
            color: #27364a;
            margin-bottom: 18px;
        }

        .required-documents {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 18px;
        }

        .required-document-card {
            border: 1px solid #dde3eb;
            border-radius: 10px;
            padding: 20px;
            background: #ffffff;
            transition: transform 0.2s, box-shadow 0.2s;
        }

        .required-document-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(0,0,0,0.07);
        }

        .document-card-icon {
            width: 48px;
            height: 48px;
            border-radius: 12px;
            background: #eaf1ff;
            color: #2362bf;
            display: flex;
            justify-content: center;
            align-items: center;
            font-size: 24px;
            margin-bottom: 15px;
        }

        .required-document-card h3 {
            font-size: 16px;
            margin-bottom: 8px;
            color: #28374a;
        }

        .required-document-card p {
            color: #748093;
            font-size: 13px;
            margin-bottom: 18px;
            line-height: 1.4;
        }

        .document-actions {
            display: flex;
            gap: 10px;
        }

        .fill-form-button {
            background: #2f68c4;
            color: white;
            border: none;
            padding: 9px 14px;
            border-radius: 6px;
            cursor: pointer;
            font-size: 13px;
            font-weight: 600;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 6px;
        }

        .preview-button {
            background: #f5f7fa;
            color: #46566b;
            border: 1px solid #dce2ea;
            padding: 9px 14px;
            border-radius: 6px;
            cursor: pointer;
            font-size: 13px;
            font-weight: 600;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 6px;
        }

        /* ================= RECENT DOCUMENTS TABLE ================= */

        .panel {
            background: white;
            border: 1px solid #dce2ea;
            border-radius: 12px;
            overflow: hidden;
        }

        .panel-header {
            padding: 17px 20px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            border-bottom: 1px solid #e4e8ee;
            flex-wrap: wrap;
            gap: 15px;
        }

        .panel-title {
            display: flex;
            align-items: center;
            gap: 12px;
            font-size: 18px;
            font-weight: 700;
            color: #2a394d;
        }

        .panel-title i {
            color: #2b63be;
            font-size: 21px;
        }

        .search-container {
            display: flex;
            gap: 10px;
        }

        .search-box {
            display: flex;
            align-items: center;
            border: 1px solid #d6dce5;
            border-radius: 8px;
            padding: 0 13px;
            width: 320px;
            background: white;
        }

        .search-box i {
            color: #758196;
            font-size: 18px;
        }

        .search-input {
            border: none;
            outline: none;
            padding: 10px;
            width: 100%;
            font-size: 14px;
            background: transparent;
        }

        /* TABLE */

        .table-wrapper {
            width: 100%;
            overflow-x: auto;
        }

        .document-table {
            width: 100%;
            border-collapse: collapse;
        }

        .document-table th {
            background: #f8f9fb;
            padding: 14px 18px;
            text-align: left;
            color: #667387;
            font-size: 12px;
            text-transform: uppercase;
            font-weight: 700;
        }

        .document-table td {
            padding: 14px 18px;
            border-top: 1px solid #edf0f4;
            font-size: 14px;
            color: #344257;
            vertical-align: middle;
        }

        .document-name {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .pdf-icon { color: #e63946; font-size: 22px; }
        .word-icon { color: #2563c8; font-size: 22px; }
        .excel-icon { color: #198754; font-size: 22px; }

        /* ACTION BUTTONS */

        .actions {
            display: flex;
            gap: 8px;
        }

        .action-button {
            width: 34px;
            height: 34px;
            border: 1px solid #dce2ea;
            border-radius: 7px;
            background: white;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            text-decoration: none;
            transition: 0.2s;
        }

        .view-button { color: #2362bf; }
        .download-button { color: #16856c; }
        .delete-button { color: #dc3545; }

        .view-button:hover { background: #eaf1ff; }
        .download-button:hover { background: #e8f6ee; }
        .delete-button:hover { background: #ffeaea; }

        /* ================ FOOTER ====================== */

        .footer {
            text-align: center;
            padding: 25px 0 10px;
            color: #7b8797;
            font-size: 14px;
        }

        /* =========== RESPONSIVE ===================== */

        @media(max-width: 1200px) {
            .document-stats {
                grid-template-columns: repeat(2, 1fr);
            }

            .required-documents {
                grid-template-columns: 1fr;
            }
        }

        @media(max-width: 850px) {
            .sidebar {
                width: 75px;
            }

            .logo-text,
            .nav-item span {
                display: none;
            }

            .nav-item {
                justify-content: center;
            }

            .main-content {
                margin-left: 75px;
                width: calc(100% - 75px);
            }

            .document-stats {
                grid-template-columns: 1fr;
            }

            .search-box {
                width: 200px;
            }
        }
    </style>
</head>

<body>
    <form id="form1" runat="server">
        <div class="dashboard-container">
            <!--======== Sidebar ====-->
            <aside class="sidebar">
                <div class="logo">
                    <div class="logo-icon">
                        <i class="bi bi-display"></i>
                    </div>
                    <div class="logo-text">
                        IT Assets Management
                        <span>System</span>
                    </div>
                </div>

                <!--========= Navigation ======-->
                <nav class="navigation">
                    <a href="Dashboard.aspx" class="nav-item">
                        <i class="bi bi-grid"></i>
                        <span>Dashboard</span>
                    </a>
                    <a href="Users.aspx" class="nav-item">
                        <i class="bi bi-person"></i>
                        <span>Users</span>
                    </a>
                    <a href="Assets.aspx" class="nav-item">
                        <i class="bi bi-laptop"></i>
                        <span>Assets</span>
                    </a>
                    <a href="AssetAssignments.aspx" class="nav-item">
                        <i class="bi bi-person-check"></i>
                        <span>Asset Assignments</span>
                    </a>
                    <a href="Returns.aspx" class="nav-item">
                        <i class="bi bi-arrow-return-left"></i>
                        <span>Returns</span>
                    </a>
                    <a href="Documents.aspx" class="nav-item active">
                        <i class="bi bi-file-earmark-text"></i>
                        <span>Documents</span>
                    </a>
                    <a href="Reports.aspx" class="nav-item">
                        <i class="bi bi-bar-chart"></i>
                        <span>Reports</span>
                    </a>
                    <a href="AuditLogs.aspx" class="nav-item">
                        <i class="bi bi-shield-check"></i>
                        <span>Audit Logs</span>
                    </a>
                    <a href="ImportData.aspx" class="nav-item">
                        <i class="bi bi-upload"></i>
                        <span>Import Data</span>
                    </a>
                </nav>

                <!-- Logout -->
                <div class="logout">
                    <a href="LoginPage.aspx" class="nav-item">
                        <i class="bi bi-box-arrow-left"></i>
                        <span>Logout</span>
                    </a>
                </div>
            </aside>

            <!--======== Main Content ====-->
            <main class="main-content">
                <!-- TOPBAR -->
                <header class="topbar">
                    <div class="topbar-left">
                        <div class="menu-button">
                            <i class="bi bi-list"></i>
                        </div>
                        <div class="page-title">
                            Documents
                        </div>
                    </div>
                    <div class="topbar-right">
                        <div class="profile">
                            <div class="profile-icon">
                                <i class="bi bi-person-fill"></i>
                            </div>
                            <div class="profile-info">
                                <strong>
                                    <asp:Label ID="lblAdminName" runat="server" Text="Administrator"></asp:Label>
                                </strong>
                                <span>
                                    <asp:Label ID="lblAdminRole" runat="server" Text="IT Administrator"></asp:Label>
                                </span>
                            </div>
                            <i class="bi bi-chevron-down"></i>
                        </div>
                    </div>
                </header>

                <!--============ Content Area ============-->
                <section class="content">
                    <!-- PAGE HEADER -->
                    <div class="page-header">
                        <div class="heading">
                            <h1>Document Management</h1>
                            <p>Manage, upload, and generate IT asset related documents.</p>
                        </div>
                        <div class="header-buttons">
                            <asp:Button ID="btnUploadDocument" runat="server" Text="⇧ Upload Document" CssClass="upload-button" />
                            <asp:Button ID="btnCreateTemplate" runat="server" Text="+ Create Template" CssClass="create-button" />
                        </div>
                    </div>

                    <!--========== Stat ======-->
                    <div class="document-stats">
                        <!-- TOTAL DOCUMENTS -->
                        <div class="stat-card">
                            <div class="stat-icon blue-icon">
                                <i class="bi bi-file-earmark-text"></i>
                            </div>
                            <div>
                                <p>Total Documents</p>
                                <h2><asp:Label ID="lblTotalDocuments" runat="server" Text="0"></asp:Label></h2>
                            </div>
                        </div>
                        <!-- TEMPLATES -->
                        <div class="stat-card">
                            <div class="stat-icon green-icon">
                                <i class="bi bi-file-earmark-plus"></i>
                            </div>
                            <div>
                                <p>Templates</p>
                                <h2><asp:Label ID="lblTemplates" runat="server" Text="0"></asp:Label></h2>
                            </div>
                        </div>
                        <!-- GENERATED TODAY -->
                        <div class="stat-card">
                            <div class="stat-icon orange-icon">
                                <i class="bi bi-cloud-arrow-up"></i>
                            </div>
                            <div>
                                <p>Generated Today</p>
                                <h2><asp:Label ID="lblGeneratedToday" runat="server" Text="0"></asp:Label></h2>
                            </div>
                        </div>
                        <!-- EXPIRING DOCUMENTS -->
                        <div class="stat-card">
                            <div class="stat-icon red-icon">
                                <i class="bi bi-file-earmark-x"></i>
                            </div>
                            <div>
                                <p>Expiring Soon</p>
                                <h2><asp:Label ID="lblExpiringDocuments" runat="server" Text="0"></asp:Label></h2>
                            </div>
                        </div>
                    </div>

                    <!--========= Required Documents ======-->
                    <div class="documents-panel">
                        <div class="section-title">Required Asset Documents</div>
                        <div class="required-documents">
                            <!-- DOCUMENT 1 -->
                            <div class="required-document-card">
                                <div class="document-card-icon">
                                    <i class="bi bi-file-earmark-text"></i>
                                </div>
                                <h3>Asset Issue Form</h3>
                                <p>Complete this form when assigning an asset to an employee.</p>
                                <div class="document-actions">
                                    <a href="FillDocument.aspx?document=1" class="fill-form-button">
                                        <i class="bi bi-pencil-square"></i> Fill Form
                                    </a>
                                    <a href="#" class="preview-button">
                                        <i class="bi bi-eye"></i> Preview
                                    </a>
                                </div>
                            </div>
                            <!-- DOCUMENT 2 -->
                            <div class="required-document-card">
                                <div class="document-card-icon">
                                    <i class="bi bi-file-earmark-check"></i>
                                </div>
                                <h3>Asset Agreement Form</h3>
                                <p>Agreement document for employees receiving IT equipment.</p>
                                <div class="document-actions">
                                    <a href="FillDocument.aspx?document=2" class="fill-form-button">
                                        <i class="bi bi-pencil-square"></i> Fill Form
                                    </a>
                                    <a href="#" class="preview-button">
                                        <i class="bi bi-eye"></i> Preview
                                    </a>
                                </div>
                            </div>
                            <!-- DOCUMENT 3 -->
                            <div class="required-document-card">
                                <div class="document-card-icon">
                                    <i class="bi bi-clipboard-check"></i>
                                </div>
                                <h3>Asset Tracking Form</h3>
                                <p>Record and track all asset allocation information.</p>
                                <div class="document-actions">
                                    <a href="FillDocument.aspx?document=3" class="fill-form-button">
                                        <i class="bi bi-pencil-square"></i> Fill Form
                                    </a>
                                    <a href="#" class="preview-button">
                                        <i class="bi bi-eye"></i> Preview
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!--========== Recent Documents ======-->
                    <div class="panel">
                        <!-- PANEL HEADER -->
                        <div class="panel-header">
                            <div class="panel-title">
                                <i class="bi bi-file-earmark-text"></i>
                                Recent Documents
                            </div>
                            <div class="search-container">
                                <div class="search-box">
                                    <i class="bi bi-search"></i>
                                    <asp:TextBox ID="txtSearch" runat="server" CssClass="search-input" Placeholder="Search documents..."></asp:TextBox>
                                </div>
                                <asp:Button ID="btnSearch" runat="server" Text="Search" CssClass="search-btn" OnClick="btnSearch_Click" />
                                <asp:Button ID="btnRefresh" runat="server" Text="Reset" CssClass="reset-btn" OnClick="btnRefresh_Click" />
                            </div>
                        </div>

                        <!-- DOCUMENT TABLE -->
                        <div class="table-wrapper">
                            <table class="document-table">
                                <thead>
                                    <tr>
                                        <th>Document Name</th>
                                        <th>Employee</th>
                                        <th>Asset Tag</th>
                                        <th>Generated By</th>
                                        <th>Date</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <asp:Repeater ID="rptDocuments" runat="server">
                                        <ItemTemplate>
                                            <tr>
                                                <!-- DOCUMENT NAME -->
                                                <td>
                                                    <div class="document-name">
                                                        <i class="bi bi-file-earmark-pdf pdf-icon"></i>
                                                        <span><%# Eval("DocumentName") %></span>
                                                    </div>
                                                </td>
                                                <!-- EMPLOYEE -->
                                                <td><%# Eval("EmployeeName") != DBNull.Value ? Eval("EmployeeName") : "-" %></td>
                                                <!-- ASSET -->
                                                <td><%# Eval("AssetTag") != DBNull.Value ? Eval("AssetTag") : "-" %></td>
                                                <!-- GENERATED BY -->
                                                <td><%# Eval("GeneratedByName") != DBNull.Value ? Eval("GeneratedByName") : "System" %></td>
                                                <!-- DATE -->
                                                <td><%# Eval("GeneratedDate", "{0:dd MMM yyyy}") %></td>
                                                <!-- ACTIONS -->
                                                <td>
                                                    <div class="actions">
                                                        <a href='<%# Eval("FilePath") %>' target="_blank" class="action-button view-button" title="View Document">
                                                            <i class="bi bi-eye"></i>
                                                        </a>
                                                        <a href='<%# Eval("FilePath") %>' download class="action-button download-button" title="Download Document">
                                                            <i class="bi bi-download"></i>
                                                        </a>
                                                        <asp:LinkButton ID="btnDelete" runat="server" CommandArgument='<%# Eval("DocumentID") %>' CssClass="action-button delete-button" OnClick="btnDelete_Click" OnClientClick="return confirm('Are you sure you want to delete this document?');" ToolTip="Delete Document">
                                                            <i class="bi bi-trash"></i>
                                                        </asp:LinkButton>
                                                    </div>
                                                </td>
                                            </tr>
                                        </ItemTemplate>
                                        <FooterTemplate>
                                            <tr id="trEmpty" runat="server" visible='<%# ((System.Data.DataTable)rptDocuments.DataSource)?.Rows.Count == 0 %>'>
                                                <td colspan="6" style="text-align: center; padding: 20px; color: #758196;">
                                                    No documents found.
                                                </td>
                                            </tr>
                                        </FooterTemplate>
                                    </asp:Repeater>
                                </tbody>
                            </table>
                        </div>
                    </div>

                    <!-- FOOTER -->
                    <footer class="footer">
                        &copy; 2026 IT Assets Management System. All rights reserved by S.N Nkuna.
                    </footer>
                </section>
            </main>
        </div>
    </form>
</body>
</html>