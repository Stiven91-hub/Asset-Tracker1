﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="AssignmentDetails.aspx.cs" Inherits="Assets_Tracker.AssignmentDetails" %>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head runat="server">
    <title>Assignment Details - IT Asset Management System</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet" />
    <style>
        * {
            box-sizing: border-box;
        }
        body {
            margin: 0;
            font-family: Arial, Helvetica, sans-serif;
            background: #f4f6fb;
            color: #1f2937;
        }
        .sidebar {
            position: fixed;
            left: 0;
            top: 0;
            width: 260px;
            height: 100vh;
            background: linear-gradient(180deg, #0f5c4d 0%, #123a5c 100%);
            color: white;
            padding: 25px 15px;
            overflow-y: auto;
        }
        .logo {
            text-align: center;
            padding: 10px 5px 30px;
            border-bottom: 1px solid rgba(255,255,255,0.15);
            margin-bottom: 20px;
        }
        .logo i {
            font-size: 35px;
            display: block;
            margin-bottom: 10px;
        }
        .logo h2 {
            font-size: 18px;
            margin: 0;
            line-height: 1.4;
        }
        .nav-menu {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        .nav-menu li {
            margin-bottom: 7px;
        }
        .nav-menu a {
            display: flex;
            align-items: center;
            gap: 13px;
            color: white;
            text-decoration: none;
            padding: 13px 15px;
            border-radius: 8px;
            font-size: 14px;
            transition: 0.2s;
        }
        .nav-menu a:hover {
            background: rgba(255,255,255,0.12);
        }
        .nav-menu a.active {
            background: linear-gradient(90deg, #2563c7, #3f7bd7);
        }
        .nav-menu i {
            font-size: 18px;
        }
        .main {
            margin-left: 260px;
            min-height: 100vh;
        }
        .topbar {
            height: 75px;
            background: white;
            border-bottom: 1px solid #e5e7eb;
            display: flex;
            justify-content: flex-end;
            align-items: center;
            padding: 0 30px;
        }
        .admin-info {
            display: flex;
            align-items: center;
            gap: 12px;
        }
        .admin-icon {
            width: 42px;
            height: 42px;
            border-radius: 50%;
            background: #2563c7;
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 19px;
        }
        .admin-details {
            text-align: right;
        }
        .admin-name {
            display: block;
            font-size: 14px;
            font-weight: 600;
            color: #1f2937;
        }
        .admin-role {
            display: block;
            font-size: 12px;
            color: #6b7280;
            margin-top: 3px;
        }
        .content {
            padding: 30px;
        }
        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
        }
        .page-header h1 {
            margin: 0;
            font-size: 27px;
            color: #1f2937;
        }
        .page-header p {
            margin: 7px 0 0;
            color: #6b7280;
            font-size: 14px;
        }
        .header-icon {
            width: 50px;
            height: 50px;
            background: #eaf1ff;
            color: #2563c7;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
        }
        .message {
            display: block;
            margin-bottom: 20px;
            padding: 12px 15px;
            border-radius: 7px;
            font-size: 14px;
        }
        .details-card {
            background: white;
            border-radius: 12px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.06);
            padding: 25px;
            margin-bottom: 20px;
        }
        .card-title {
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 18px;
            font-weight: 600;
            color: #1f2937;
            margin-bottom: 22px;
            padding-bottom: 15px;
            border-bottom: 1px solid #e5e7eb;
        }
        .card-title i {
            color: #2563c7;
            font-size: 20px;
        }
        .details-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 20px 30px;
        }
        .detail-item {
            display: flex;
            flex-direction: column;
            gap: 7px;
        }
        .detail-label {
            font-size: 12px;
            font-weight: 600;
            color: #6b7280;
            text-transform: uppercase;
            letter-spacing: 0.4px;
        }
        .detail-value {
            font-size: 15px;
            color: #1f2937;
            font-weight: 500;
            min-height: 20px;
        }
        .status {
            display: inline-block;
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            width: fit-content;
        }
        .status-active {
            background: #dcfce7;
            color: #166534;
        }
        .status-returned {
            background: #e0e7ff;
            color: #3730a3;
        }
        .status-other {
            background: #f3f4f6;
            color: #374151;
        }
        .notes {
            background: #f8fafc;
            border: 1px solid #e5e7eb;
            border-radius: 8px;
            padding: 15px;
            min-height: 70px;
            white-space: pre-wrap;
            line-height: 1.6;
        }
        .button-row {
            display: flex;
            justify-content: space-between;
            gap: 12px;
            margin-top: 25px;
        }
        .button-group {
            display: flex;
            gap: 10px;
        }
        .btn {
            border: none;
            border-radius: 7px;
            padding: 11px 18px;
            font-size: 14px;
            font-weight: 600;
            cursor: pointer;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }
        .btn-primary {
            background: #2563c7;
            color: white;
        }
        .btn-primary:hover {
            background: #1d4fa3;
        }
        .btn-secondary {
            background: #e5e7eb;
            color: #374151;
        }
        .btn-secondary:hover {
            background: #d1d5db;
        }
        .info-box {
            background: #eff6ff;
            border: 1px solid #bfdbfe;
            color: #1e40af;
            padding: 13px 15px;
            border-radius: 8px;
            font-size: 13px;
            line-height: 1.5;
        }
        @media (max-width: 900px) {
            .sidebar {
                width: 220px;
            }
            .main {
                margin-left: 220px;
            }
            .details-grid {
                grid-template-columns: 1fr;
            }
        }
        @media (max-width: 700px) {
            .sidebar {
                display: none;
            }
            .main {
                margin-left: 0;
            }
            .content {
                padding: 20px;
            }
            .button-row {
                flex-direction: column;
            }
            .button-group {
                width: 100%;
            }
            .button-group .btn {
                flex: 1;
                justify-content: center;
            }
        }
    </style>
</head>
<body>
    <form id="form1" runat="server">
        <!-- SIDEBAR -->
        <aside class="sidebar">
            <div class="logo">
                <i class="bi bi-pc-display"></i>
                <h2>IT Assets Management System</h2>
            </div>
            <ul class="nav-menu">
                <li>
                    <a href="Dashboard.aspx">
                        <i class="bi bi-grid"></i>
                        <span>Dashboard</span>
                    </a>
                </li>
                <li>
                    <a href="Users.aspx">
                        <i class="bi bi-people"></i>
                        <span>Employees</span>
                    </a>
                </li>
                <li>
                    <a href="Assets.aspx">
                        <i class="bi bi-laptop"></i>
                        <span>Assets</span>
                    </a>
                </li>
                <li>
                    <a href="AssetAssignments.aspx">
                        <i class="bi bi-person-check"></i>
                        <span>Assignments</span>
                    </a>
                </li>
                <li>
                    <a href="Returns.aspx" class="active">
                        <i class="bi bi-arrow-return-left"></i>
                        <span>Returns</span>
                    </a>
                </li>
                <li>
                    <a href="Documents.aspx">
                        <i class="bi bi-file-earmark-text"></i>
                        <span>Documents</span>
                    </a>
                </li>
                <li>
                    <a href="Reports.aspx">
                        <i class="bi bi-bar-chart"></i>
                        <span>Reports</span>
                    </a>
                </li>
                <li>
                    <a href="AuditLogs.aspx">
                        <i class="bi bi-shield-check"></i>
                        <span>Audit Logs</span>
                    </a>
                </li>
            </ul>
        </aside>
        <!-- MAIN -->
        <main class="main">
            <!-- TOPBAR -->
            <div class="topbar">
                <div class="admin-info">
                    <div class="admin-details">
                        <asp:Label ID="lblAdminName" runat="server" CssClass="admin-name"></asp:Label>
                        <asp:Label ID="lblAdminRole" runat="server" CssClass="admin-role"></asp:Label>
                    </div>
                    <div class="admin-icon">
                        <i class="bi bi-person-fill"></i>
                    </div>
                </div>
            </div>
            <!-- CONTENT -->
            <div class="content">
                <div class="page-header">
                    <div>
                        <h1>Assignment Details</h1>
                        <p>View complete information about this asset assignment.</p>
                    </div>
                    <div class="header-icon">
                        <i class="bi bi-arrow-left-right"></i>
                    </div>
                </div>
                <asp:Label ID="lblMessage" runat="server" CssClass="message"></asp:Label>
                <!-- ASSIGNMENT INFORMATION -->
                <div class="details-card">
                    <div class="card-title">
                        <i class="bi bi-clipboard-data"></i>
                        Assignment Information
                    </div>
                    <div class="details-grid">
                        <div class="detail-item">
                            <span class="detail-label">Assignment ID</span>
                            <asp:Label ID="lblAllocationID" runat="server" CssClass="detail-value"></asp:Label>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Assignment Status</span>
                            <asp:Label ID="lblStatus" runat="server" CssClass="detail-value"></asp:Label>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Allocation Date</span>
                            <asp:Label ID="lblAllocationDate" runat="server" CssClass="detail-value"></asp:Label>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Return Date</span>
                            <asp:Label ID="lblReturnDate" runat="server" CssClass="detail-value"></asp:Label>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Condition at Issue</span>
                            <asp:Label ID="lblConditionAtIssue" runat="server" CssClass="detail-value"></asp:Label>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Condition at Return</span>
                            <asp:Label ID="lblConditionAtReturn" runat="server" CssClass="detail-value"></asp:Label>
                        </div>
                    </div>
                </div>
                <!-- EMPLOYEE INFORMATION -->
                <div class="details-card">
                    <div class="card-title">
                        <i class="bi bi-person-badge"></i>
                        Employee Information
                    </div>
                    <div class="details-grid">
                        <div class="detail-item">
                            <span class="detail-label">Employee Number</span>
                            <asp:Label ID="lblEmployeeNumber" runat="server" CssClass="detail-value"></asp:Label>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Employee ID</span>
                            <asp:Label ID="lblEmployeeID" runat="server" CssClass="detail-value"></asp:Label>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Employee Name</span>
                            <asp:Label ID="lblEmployeeName" runat="server" CssClass="detail-value"></asp:Label>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Job Title</span>
                            <asp:Label ID="lblJobTitle" runat="server" CssClass="detail-value"></asp:Label>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Email</span>
                            <asp:Label ID="lblEmployeeEmail" runat="server" CssClass="detail-value"></asp:Label>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Phone Number</span>
                            <asp:Label ID="lblPhoneNumber" runat="server" CssClass="detail-value"></asp:Label>
                        </div>
                    </div>
                </div>
                <!-- ASSET INFORMATION -->
                <div class="details-card">
                    <div class="card-title">
                        <i class="bi bi-laptop"></i>
                        Asset Information
                    </div>
                    <div class="details-grid">
                        <div class="detail-item">
                            <span class="detail-label">Asset Tag</span>
                            <asp:Label ID="lblAssetTag" runat="server" CssClass="detail-value"></asp:Label>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Asset Type</span>
                            <asp:Label ID="lblAssetType" runat="server" CssClass="detail-value"></asp:Label>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Serial Number</span>
                            <asp:Label ID="lblSerialNumber" runat="server" CssClass="detail-value"></asp:Label>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Make</span>
                            <asp:Label ID="lblMake" runat="server" CssClass="detail-value"></asp:Label>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Model</span>
                            <asp:Label ID="lblModel" runat="server" CssClass="detail-value"></asp:Label>
                        </div>
                    </div>
                </div>
                <!-- ADMIN INFORMATION -->
                <div class="details-card">
                    <div class="card-title">
                        <i class="bi bi-person-gear"></i>
                        Assignment Administrator
                    </div>
                    <div class="details-grid">
                        <div class="detail-item">
                            <span class="detail-label">Admin ID</span>
                            <asp:Label ID="lblAdminID" runat="server" CssClass="detail-value"></asp:Label>
                        </div>
                        <div class="detail-item">
                            <span class="detail-label">Administrator Name</span>
                            <asp:Label ID="lblAssignmentAdminName" runat="server" CssClass="detail-value"></asp:Label>
                        </div>
                    </div>
                </div>
                <!-- NOTES -->
                <div class="details-card">
                    <div class="card-title">
                        <i class="bi bi-journal-text"></i>
                        Assignment Notes
                    </div>
                    <asp:Label ID="lblNotes" runat="server" CssClass="notes"></asp:Label>
                </div>
                <!-- INFORMATION -->
                <div class="info-box">
                    <i class="bi bi-info-circle"></i>
                    This page displays the assignment history recorded in the
                    <strong>dbo.Allocation</strong> table. Returned assignments
                    remain in the system so that the asset's allocation history
                    can be preserved.
                </div>
                <!-- BUTTONS -->
                <div class="button-row">
                    <asp:Button ID="btnBack" runat="server" Text="Back to Assignments" CssClass="btn btn-secondary" OnClick="btnBack_Click" />
                    <div class="button-group">
                        <asp:Button ID="btnEditAssignment" runat="server" Text="Edit Assignment" CssClass="btn btn-primary" OnClick="btnEditAssignment_Click" />
                    </div>
                </div>
            </div>
        </main>
    </form>
</body>
</html>